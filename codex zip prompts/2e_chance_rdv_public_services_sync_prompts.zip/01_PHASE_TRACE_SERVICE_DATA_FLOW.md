# 01 — Phase Trace Service Data Flow

## Role

You are a senior problem analyst, senior data analyst, senior full-stack software engineer, senior Supabase engineer, and senior systems architect.

You are working only on **Phase 1: tracing the real data flow from merchant service creation to public QR/signup display**.

Do not implement the fix yet unless the root cause is trivial and fully verified. This phase is primarily diagnostic.

## Problem

The merchant added active services in the dashboard, but the public signup page still says no service options are configured.

The main risk is fixing the wrong layer: UI, RLS, slug resolution, cache, mock data, service creation, and public data loading are all possible causes.

## Goal

Identify exactly why active merchant services are not appearing on the public waitlist form.

## Files to Read First

Read these before editing:

- public QR/waitlist route files, likely under `src/app/join/**`, `src/app/waitlist/**`, `src/app/w/**`, or similar;
- dashboard services page files;
- service server actions/helpers;
- service query helpers;
- public signup server actions/helpers;
- `src/lib/organization/current.ts`;
- `src/lib/supabase/server.ts`;
- Supabase migrations defining `organizations`, `services`, `waitlist_entries`, and service-interest joins if any;
- tests;
- `package.json`.

## Required Investigation

Find and document:

1. Where services are created in the dashboard.
2. Which table stores services.
3. Whether services are saved in Supabase or only local/mock data.
4. Whether each service has `organization_id`.
5. Whether each service has `active` or equivalent.
6. Whether the public page resolves organization by slug, ID, name, or token.
7. Whether the public page uses the same organization as the dashboard.
8. Whether the public page queries services at all.
9. Whether that query is server-side or client-side.
10. Whether the query filters by `active = true`.
11. Whether RLS blocks public reads.
12. Whether the fallback message is shown because the query returned empty, errored, or was skipped.
13. Whether static caching/revalidation prevents newly added services from appearing.
14. Whether the current code is committed to Git or only exists locally.

## Diagnostic Output Required Before Fixing

Write a short diagnosis with one of these root causes:

- services are not persisted;
- services persisted to the wrong table;
- services belong to a different organization;
- public route resolves the wrong organization;
- public service query is missing;
- public service query is blocked by RLS;
- public service query filters incorrectly;
- page is cached/stale;
- UI ignores loaded services;
- selected branch/local code mismatch.

## Safety Rules

Do not:

- hardcode the services to make them appear;
- bypass organization scoping;
- disable RLS;
- expose private organization/customer data;
- add broad anon policies;
- change the schema before proving it is necessary.

## Validation Commands

If only diagnostic changes are made, run at least:

```bash
npm run lint
npm run typecheck
```

If tests or code are changed, run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Manual Verification

Use the current merchant organization, then verify:

1. Services exist in dashboard.
2. Services exist in database.
3. Public route resolves the same organization.
4. Public service query returns or fails with a known reason.

## Final Report for This Phase

Report:

1. Confirmed root cause.
2. Files inspected.
3. Data path found.
4. Whether services are persisted.
5. Whether RLS is involved.
6. Whether caching is involved.
7. Recommended fix phase.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
