# 02 — Phase Public Service Loader and Organization Resolution

## Role

You are a senior Next.js App Router engineer, senior Supabase/PostgreSQL engineer, senior backend engineer, senior security engineer, and senior data architect.

You are working only on **Phase 2: creating/fixing the public service loader and organization resolution**.

## Problem

The public waitlist form must load active services for the same organization that the QR/public link represents. It currently displays the fallback message even though active services exist.

## Goal

Build or fix a server-side public data loader that returns the public organization profile and its active services.

## Preferred Architecture

Create or fix a helper such as:

```text
src/lib/public-waitlist/get-public-waitlist-signup-data.ts
```

It should accept:

```ts
organizationSlug: string
```

It should return:

```ts
type PublicWaitlistSignupData = {
  organization: {
    id: string;
    name: string;
    slug: string;
  };
  services: Array<{
    id: string;
    name: string;
    description: string | null;
    durationMinutes: number | null;
    normalPriceCents: number | null;
  }>;
};
```

## Requirements

The loader must:

1. Resolve organization by slug safely.
2. Query services by `organization_id`.
3. Return only `active = true` services.
4. Sort services predictably, preferably by created date or name.
5. Return only fields needed for the public form.
6. Never expose customers, waitlist entries, SMS logs, audit logs, billing, or private membership data.
7. Handle missing organization with a proper not-found state.
8. Handle zero active services with an intentional empty array.
9. Avoid swallowing query errors as “no services configured”.

## Cache/Revalidation Requirements

Check whether the public route is static.

If service changes are not reflected:

- use dynamic rendering for the public waitlist route; or
- use targeted `revalidatePath` after service create/update/deactivate; or
- use `no-store` only for the public data loader if necessary.

Do not globally disable caching without reason.

## Security Requirements

Do not trust `organization_id` from public form input.

The public route should resolve organization from a slug or safe public token.

If this route uses Supabase anon client, confirm RLS allows only safe public service reads. If not, defer RLS change to Phase 3.

## Tests Required

Add tests for the loader if feasible:

1. Correct organization slug returns correct organization.
2. Active services for organization are returned.
3. Inactive services are excluded.
4. Services from another organization are excluded.
5. Missing organization is handled.
6. Query error is not silently converted to “no services configured”.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Manual Test

1. Add active services in merchant dashboard.
2. Open public waitlist link.
3. Confirm loader returns those services.
4. Deactivate one service.
5. Confirm it disappears.
6. Add service from another organization.
7. Confirm it never appears.

## Final Report

Report:

1. Loader created/changed.
2. Organization resolution strategy.
3. Service query strategy.
4. Caching/revalidation decision.
5. Tests added.
6. Validation results.
7. Remaining RLS/security items for Phase 3.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
