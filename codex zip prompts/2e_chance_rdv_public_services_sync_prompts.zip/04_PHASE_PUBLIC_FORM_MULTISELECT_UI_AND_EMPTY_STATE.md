# 04 — Phase Public Form Multi-Select UI and Empty State

## Role

You are a senior React/TypeScript engineer, senior UX engineer, senior accessibility reviewer, and senior QA lead.

You are working only on **Phase 4: rendering active services as clickable multi-select options on the public signup form**.

## Problem

The public form currently shows a fallback message instead of active services. Once the loader works, the UI must display service choices properly and accessibly.

## Goal

Replace the fallback-only service section with a clean multi-select UI that supports one or multiple services.

## UI Requirements

The public form must show:

- Name;
- Mobile phone;
- Preferred language;
- service interest multi-select;
- required SMS consent checkbox;
- submit button.

The service section copy:

```text
Which services are you interested in? Select all that apply.
```

French equivalent if the form is French:

```text
Quels services vous intéressent ? Choisissez un ou plusieurs services.
```

## Multi-Select Requirements

Each active service should render as a clickable option:

- chip;
- card;
- checkbox-style button;
- accessible selection state;
- clear selected styling.

The customer can select:

- zero services if general waitlist is allowed;
- one service;
- multiple services.

If zero services are active, show fallback only then:

```text
This business has not configured service options yet. You can still join the general waitlist.
```

Do not show this fallback when services exist.

## Accessibility Requirements

Use one of:

- real checkboxes with styled labels; or
- buttons with `aria-pressed`; or
- a fieldset/legend with checkbox inputs.

Prefer real checkboxes for form reliability.

Must support:

- keyboard navigation;
- visible focus state;
- screen reader label;
- mobile tapping.

## Submission Requirements

Selected services must submit as service IDs, not names.

Example:

```html
<input type="checkbox" name="serviceIds" value="service-uuid" />
```

or equivalent safe form state.

## Removed Fields

Ensure these are not present:

- `Preferred days`;
- “I am open to last-minute offers or discounts.”

Keep SMS consent checkbox.

## Tests Required

Add tests or component assertions for:

1. services render when passed to form;
2. fallback renders only when services array is empty;
3. multiple selected service IDs can be submitted;
4. preferred days field is absent;
5. discount/offers checkbox is absent;
6. SMS consent checkbox remains present and required.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Manual Test

1. Open public form with active services.
2. Confirm services display as chips/checkboxes.
3. Select both services.
4. Confirm selected styling.
5. Confirm no preferred days field.
6. Confirm no discount checkbox.
7. Confirm consent checkbox remains.

## Final Report

Report:

1. UI files changed.
2. Multi-select behavior.
3. Accessibility approach.
4. Removed fields.
5. Tests added.
6. Validation results.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
