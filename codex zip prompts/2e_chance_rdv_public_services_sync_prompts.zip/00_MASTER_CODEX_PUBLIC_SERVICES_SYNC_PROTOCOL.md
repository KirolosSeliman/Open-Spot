# 00 — Master Codex Protocol: Public Services Sync + QR Waitlist Form

## Role

You are a senior problem analyst, senior data analyst, senior product-minded software engineer, senior full-stack software engineer, senior systems architect, senior Supabase/PostgreSQL engineer, senior Next.js App Router engineer, senior React/TypeScript engineer, senior UX engineer, senior security engineer, senior SMS consent/compliance-aware engineer, and senior QA lead.

You are working on **2e Chance RDV**, a B2B SaaS that helps local appointment-based businesses recover last-minute cancellations through SMS waitlists.

Your mission is to fix the current problem where services created by the merchant in the dashboard do **not** appear on the public QR/waitlist signup page.

## Product Context

The merchant configures services such as:

- Coupe régulière
- Coupe régulière + barbe
- Coloration
- Pose gel
- Manucure

A customer who scans the merchant’s QR code should be able to select one or multiple services they are interested in. Those selected services must later help the merchant target the correct clients when a last-minute appointment opens.

## Current User-Visible Problem

The dashboard shows active services, but the public signup page still displays:

```text
This business has not configured service options yet. You can still join the general waitlist.
```

That means the public page is not reading, resolving, or displaying the merchant’s active services correctly.

## Global Goal

Make active merchant services appear on the public QR/waitlist signup page as safe, clickable, multi-select options.

The implementation must be:

- safe;
- secure;
- efficient;
- tested;
- production-ready;
- organization-scoped;
- compatible with Supabase RLS;
- clear for the customer;
- useful for future cancellation targeting.

## Critical Product Boundaries

2e Chance RDV is not:

- a CRM;
- a full booking platform;
- a marketplace;
- a generic SMS marketing tool;
- a Calendly clone;
- a Square clone;
- part of Vistaire.

Do not overbuild. Do not add real SMS sending in this task. Do not create complex CRM abstractions.

## Mandatory Phase Discipline

Work on **one phase at a time**.

You may automatically move to the next phase **only when the current phase is fully complete, safe, tested, build-clean, and factually verified**.

For each phase:

1. Read the relevant files before modifying anything.
2. Identify the exact root cause.
3. Separate confirmed facts from assumptions.
4. Make the smallest safe durable change.
5. Add or update tests.
6. Run validations.
7. Report results.
8. Only then move to the next phase.

## Required Phase Order

Use these phase prompts in order:

1. `01_PHASE_TRACE_SERVICE_DATA_FLOW.md`
2. `02_PHASE_PUBLIC_SERVICE_LOADER_AND_ORG_RESOLUTION.md`
3. `03_PHASE_RLS_SECURITY_AND_PUBLIC_READ_POLICY.md`
4. `04_PHASE_PUBLIC_FORM_MULTISELECT_UI_AND_EMPTY_STATE.md`
5. `05_PHASE_SIGNUP_SUBMISSION_SERVICE_INTEREST_INTEGRATION.md`
6. `06_PHASE_DASHBOARD_WAITLIST_VISIBILITY_AND_TARGETING_PREP.md`
7. `07_PHASE_FINAL_QA_DEPLOYMENT_AUDIT.md`

## Mandatory Validation Commands

After each code phase, run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If migrations or RLS policies are added, also run when possible:

```bash
supabase migration list --linked
supabase db push
```

If Supabase CLI is unavailable, say so clearly and provide the exact command the user must run.

## Global Security Rules

Never:

- hardcode service names;
- use mock services on the public signup page;
- trust `organization_id` from the browser;
- expose service-role keys to client components;
- expose customer data publicly;
- expose waitlist data publicly;
- expose SMS logs publicly;
- show services from another organization;
- weaken RLS broadly;
- bypass auth on merchant dashboard pages;
- add real SMS sending in this flow;
- delete production data.

## Global Data Rules

Active services shown on the public form must:

- belong to the resolved organization;
- be active;
- be read from the real database, not mock data;
- be validated again on submit;
- support one or many selected services.

## Final Report Required After All Phases

At the end, report:

1. Root cause.
2. Exact files changed.
3. Whether RLS/policies/migrations changed.
4. Public service loading strategy.
5. Public form behavior.
6. Service interest storage behavior.
7. Dashboard visibility of selected services.
8. Tests added.
9. Validation results.
10. Manual QA results.
11. Remaining risks.
12. Exact commands the user must run.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
