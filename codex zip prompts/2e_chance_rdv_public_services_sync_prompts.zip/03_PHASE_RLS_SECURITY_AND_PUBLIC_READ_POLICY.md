# 03 — Phase RLS Security and Public Read Policy

## Role

You are a senior Supabase/PostgreSQL security engineer, senior backend engineer, senior systems architect, and senior QA lead.

You are working only on **Phase 3: fixing RLS/security so the public waitlist page can safely read active services**.

## Problem

The public QR/waitlist page may not be able to read active services because `services` is organization-scoped and protected by RLS.

The fix must not expose sensitive organization data or customer data.

## Goal

Allow the public signup flow to display only safe, active service options for the resolved organization.

## Decision Tree

First determine how public data is loaded:

1. Server-side trusted loader with service role?  
   Ensure no service role reaches client. Use carefully.

2. Supabase anon/public client?  
   Add a narrow RLS policy for active public service reads if required.

3. Existing RPC?  
   Ensure the RPC returns only safe fields.

Choose the safest architecture already aligned with the codebase.

## RLS Policy Requirements If Needed

A public read policy on `services` must be narrow.

It may allow reading only:

- id;
- organization_id if needed internally;
- name;
- description;
- duration_minutes;
- normal_price_cents;
- active.

It must only expose:

```sql
active = true
```

Do not expose:

- customers;
- waitlist entries;
- sms messages;
- audit logs;
- organization members;
- private billing data;
- inactive/internal services if not intended.

If Supabase policies cannot restrict columns, then route access through a safe server-side loader or RPC that returns only allowed fields.

## Migration Requirements

If adding policies/functions:

- create a new additive migration;
- do not edit old applied migrations only;
- no destructive SQL;
- no broad grants;
- no production resets.

## Tests Required

Add migration/security tests verifying:

1. No broad anon select on sensitive tables.
2. Public service access only applies to active services, or is controlled by a safe function.
3. Customers/waitlist/SMS/audit tables are not exposed.
4. service-role is not used client-side.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If migration added:

```bash
supabase migration list --linked
supabase db push
```

## Manual Test

1. Logged-out public page can see active services.
2. Logged-out public page cannot see inactive services.
3. Logged-out user cannot read customer list.
4. Logged-out user cannot read waitlist entries.
5. Dashboard auth still works.

## Final Report

Report:

1. Whether RLS was the root cause.
2. Policy/function added.
3. Why the change is safe.
4. Tables still protected.
5. Tests added.
6. Validation results.
7. Manual QA result.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
