# 05 — Phase Signup Submission and Service Interest Integration

## Role

You are a senior backend engineer, senior full-stack engineer, senior Supabase/PostgreSQL engineer, senior security engineer, and senior QA lead.

You are working only on **Phase 5: validating and storing selected service interests from the public signup form**.

## Problem

Rendering services is not enough. The selected service IDs must be validated and stored in a normalized, organization-safe way.

## Goal

When a customer submits the public waitlist form, selected service IDs must be saved and linked to the customer/waitlist entry safely.

## Files to Read First

Read:

- public signup server action/RPC;
- `customers` schema;
- `sms_consents` schema;
- `waitlist_entries` schema;
- multi-service join table if exists;
- service migrations;
- tests.

## Storage Requirements

Preferred normalized model:

```text
waitlist_entry_services
```

Columns:

- id;
- organization_id;
- waitlist_entry_id;
- service_id;
- created_at.

Constraints:

- unique(waitlist_entry_id, service_id);
- FK to waitlist_entries;
- FK to services;
- organization-scoped index.

If a similar table already exists, reuse it.

If `waitlist_entries.service_id` already exists:

- keep it for backward compatibility;
- optionally store the first selected service there;
- use the join table as source of truth for multiple selections.

## Backend Validation Requirements

On submit:

1. Resolve organization from public route slug/token.
2. Normalize phone.
3. Validate consent.
4. Validate selected service IDs:
   - must exist;
   - must belong to organization;
   - must be active.
5. Reject or ignore invalid service IDs safely.
6. Create/update customer.
7. Create/update consent.
8. Create waitlist entry.
9. Insert selected service links.
10. Avoid duplicates.

Do not trust service IDs blindly.

## Security Requirements

Never:

- trust organization_id from browser;
- expose service role to client;
- allow cross-organization service linking;
- mark SMS consent as opted_in without checkbox;
- allow invalid service IDs to create broken references.

## Tests Required

Add tests for:

1. valid service IDs are stored;
2. multiple services are stored;
3. duplicate service IDs are deduped;
4. inactive services are rejected/ignored;
5. services from another organization are rejected;
6. submission still works with zero selected services if general waitlist is allowed;
7. consent remains required;
8. phone normalization still works.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If migration added:

```bash
supabase migration list --linked
supabase db push
```

## Manual Test

1. Public form shows two services.
2. Select both.
3. Submit valid client.
4. Confirm customer created/updated.
5. Confirm waitlist entry created.
6. Confirm selected services are linked.
7. Try tampering with another organization service ID.
8. Confirm it is rejected or ignored safely.

## Final Report

Report:

1. Backend files changed.
2. Migration added if any.
3. Validation strategy.
4. Storage strategy.
5. Tests added.
6. Validation results.
7. Manual QA result.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
