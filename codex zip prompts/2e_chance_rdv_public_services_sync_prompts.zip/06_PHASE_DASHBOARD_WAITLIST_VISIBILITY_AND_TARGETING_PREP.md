# 06 — Phase Dashboard Waitlist Visibility and Targeting Prep

## Role

You are a senior product engineer, senior data analyst, senior dashboard UX engineer, senior Supabase engineer, and senior QA lead.

You are working only on **Phase 6: showing selected service interests in the dashboard and preparing future cancellation targeting**.

## Problem

Once customers select services on the public signup page, the merchant must see those interests in the dashboard. Future cancellation targeting depends on this data.

## Goal

Update dashboard waitlist/client views so selected services appear clearly and can later be used to filter eligible clients.

## Requirements

Dashboard should show for each waitlist/customer row:

- customer name;
- phone;
- consent status;
- source;
- selected service interests as chips;
- created date;
- SMS eligibility status.

## Targeting Prep Helper

Create or update a helper such as:

```text
src/lib/waitlist/eligible-clients.ts
```

It should support future query logic:

- given organization_id;
- given service_id;
- return customers/waitlist entries interested in that service;
- include only opted-in clients;
- exclude opted-out / needs-consent;
- exclude inactive waitlist entries.

Do not send SMS in this phase.

## Security Requirements

- organization-scoped queries only;
- no service role in client;
- no data from other organizations;
- no public access to private waitlist.

## Tests Required

Add tests for:

1. service interest chips rendering data shape.
2. eligible-client helper includes matching service interests.
3. opted-out clients excluded.
4. needs-consent clients excluded.
5. inactive services/entries excluded if applicable.
6. organization scoping.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Manual Test

1. Public signup selects two services.
2. Merchant opens dashboard waitlist/clients.
3. Confirm selected services appear as chips.
4. Confirm consent status appears.
5. Confirm eligible-client helper or UI filter can find clients by selected service.

## Final Report

Report:

1. Dashboard updates.
2. Data query strategy.
3. Targeting prep helper.
4. Tests added.
5. Validation results.
6. Remaining targeting limitations.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
