# 07 — Phase Final QA and Deployment Audit

## Role

You are a senior release engineer, senior QA lead, senior security reviewer, senior data integrity analyst, and senior production-readiness architect.

You are working only on **Phase 7: final QA and deployment audit for public service sync and service interest selection**.

Do not add features. Verify that the full flow works safely.

## Audit Scope

Audit the full flow:

1. Merchant creates services.
2. Services are saved as organization-scoped active services.
3. Public QR/waitlist page loads those active services.
4. Customer selects one or multiple services.
5. Submission validates and stores selected service interests.
6. Dashboard displays selected service interests.
7. Future targeting helpers can use selected services.

## Required Checks

### Data Checks

Confirm:

- services exist in DB;
- services have correct organization_id;
- active services appear publicly;
- inactive services do not appear;
- other organization services do not appear;
- selected service IDs are stored safely.

### Security Checks

Confirm:

- no service role in client;
- organization_id is not trusted from browser;
- public page cannot read customers;
- public page cannot read waitlist entries;
- public page cannot read SMS logs;
- RLS remains safe.

### UX Checks

Confirm:

- services appear as selectable UI;
- multiple selections work;
- fallback appears only when zero active services exist;
- preferred days removed;
- discount/offers checkbox removed;
- consent checkbox remains required;
- mobile layout works.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If migrations were added:

```bash
supabase migration list --linked
supabase db push
```

## Manual End-to-End QA

1. Login as merchant.
2. Add services:
   - Coupe régulière
   - Coupe régulière + barbe
3. Ensure both are active.
4. Open public signup link in incognito.
5. Confirm both services appear.
6. Select both.
7. Submit name, phone, language, consent.
8. Confirm success.
9. Open dashboard waitlist.
10. Confirm customer exists.
11. Confirm both service interests are visible.
12. Deactivate one service.
13. Reopen public link.
14. Confirm deactivated service is hidden.
15. Confirm no cross-organization service appears.

## Deployment Checklist

Before deploy:

- tests pass;
- build passes;
- migrations pushed;
- RLS checked;
- manual QA done;
- no real SMS accidentally added;
- fallback behavior correct;
- public route tested logged out.

## Rollback Strategy

If frontend issue:
- revert UI changes.

If DB/migration issue:
- do not reset production;
- create forward-fix migration.

If public route leaks data:
- disable route or revert public loader immediately;
- patch RLS/server loader.

## Final Report

Report:

1. Release readiness verdict.
2. What works.
3. What was changed.
4. Migrations added.
5. RLS/security findings.
6. Validation results.
7. Manual QA result.
8. Deployment commands.
9. Rollback plan.
10. Remaining risks.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
