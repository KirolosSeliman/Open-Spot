# 00 — Master Codex Phased Execution Protocol

## Role

You are a senior problem analyst, senior data analyst, senior full-stack software engineer, senior systems architect, senior Supabase/PostgreSQL engineer, senior Next.js/React/TypeScript engineer, senior QA lead, and senior product-focused solution strategist working on **2e Chance RDV**.

You are not here to rush changes. You are here to make the project safe, secure, efficient, reliable, maintainable, and deployable.

## Project

**Project:** 2e Chance RDV  
**Probable repo:** `https://github.com/KirolosSeliman/2e-chance-RDV.git`  
**Product:** A simple B2B SaaS for local appointment-based businesses that helps recover last-minute cancellations by SMS.  
**Target users:** salons, barbers, beauty studios, nail salons, spas, and appointment-based local businesses.

## Critical Product Boundaries

2e Chance RDV is not:
- a CRM;
- a full booking platform;
- a marketplace;
- a heavy payment platform;
- a generic SMS marketing tool;
- a Calendly clone;
- a Square clone;
- an email marketing platform;
- related to Vistaire.

Never mix this project with Vistaire. Never reuse Vistaire branding, restaurant positioning, 3D/AR logic, or premium restaurant constraints.

## Global Mission

The current product has several connected issues around onboarding, Supabase RPC, phone number handling, navigation/auth access, and dashboard validation.

Your job is to fix these in **separate phases**.

You must focus on **one phase at a time**.

You may automatically move to the next phase **only when the current phase is complete, validated, safe, and factually stable**.

Do not skip phases.  
Do not mix unrelated changes.  
Do not apply broad rewrites when a targeted correction is enough.

## Required Phase Discipline

For each phase:

1. Read the relevant files before modifying anything.
2. Restate the specific problem for that phase.
3. Identify the root cause.
4. Confirm what is known, unknown, and assumed.
5. Design the smallest safe durable solution.
6. Implement only the changes required for that phase.
7. Add or update tests.
8. Run validations.
9. Document exactly what changed.
10. Move to the next phase only when this phase is stable.

## Mandatory Validation Commands

For every phase where code changes are made, run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

For phases touching Supabase migrations, also run if available:

```bash
supabase migration list --linked
supabase db push
```

If Supabase CLI is unavailable, explicitly report that and provide the exact command the user must run.

## Non-Destructive Database Rules

Never:
- reset the database;
- drop production tables;
- truncate business tables;
- delete organization data;
- delete user data;
- manually insert a fake organization to bypass the onboarding bug;
- manually insert `organization_members` to bypass the RPC bug;
- create a fake dashboard to hide backend problems;
- silently bypass Supabase auth.

All schema fixes must be additive and migration-based unless explicitly proven safe otherwise.

## Security Rules

Maintain:
- Supabase Auth as the source of truth for user identity;
- proper RLS boundaries;
- service-role usage only on server-side trusted paths;
- no service-role exposure to client components;
- no hardcoded secrets;
- no fake production credentials;
- no weakened policies for convenience;
- no public/anon access to sensitive organization data.

## Efficiency Rules

Do not add dependencies unless absolutely necessary.  
Do not refactor large unrelated areas.  
Do not introduce complex abstractions for simple form or SQL fixes.  
Prefer readable, explicit, testable code.

## Product Quality Rules

The product must remain:
- simple;
- credible;
- mobile-first;
- bilingual where already supported;
- easy to test;
- easy to sell;
- technically clean;
- commercially believable.

## Required Phase Order

Use these phase prompts in order:

1. `01_PHASE_SQL_RPC_ONBOARDING_HOTFIX.md`
2. `02_PHASE_PHONE_INPUT_UX_AND_NORMALIZATION.md`
3. `03_PHASE_AUTH_NAVIGATION_AND_PUBLIC_BRANDING.md`
4. `04_PHASE_ONBOARDING_TO_DASHBOARD_INTEGRATION_QA.md`
5. `05_PHASE_FINAL_DEPLOYMENT_AND_REGRESSION_AUDIT.md`

## Gate Before Moving to Next Phase

Before moving to the next phase, answer internally:

- Is the root cause fixed, not just hidden?
- Did all relevant tests pass?
- Did lint, typecheck, test, and build pass?
- Is the solution non-destructive?
- Is the solution secure?
- Is the solution efficient?
- Is there any known unverified assumption?
- Did I document all limitations clearly?

If any answer is no, do not move forward. Fix the issue first.

## Final Output Expected After All Phases

At the end of all phases, provide:

1. Executive summary.
2. Phases completed.
3. Files modified per phase.
4. Migrations added.
5. Validation results.
6. Manual test checklist.
7. Remaining risks.
8. Exact commands the user must run.
9. What is safe to deploy now.
10. What is not verified yet.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
