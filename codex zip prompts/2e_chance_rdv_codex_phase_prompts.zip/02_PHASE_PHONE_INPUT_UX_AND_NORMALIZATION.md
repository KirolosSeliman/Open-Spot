# 02 — Phase Phone Input UX and Normalization

## Role

You are a senior frontend engineer, senior UX engineer, senior TypeScript engineer, senior validation engineer, and senior QA lead.

You are working only on **Phase 2: fixing phone input UX and backend normalization**.

Do not touch SQL/RPC unless Phase 1 revealed a phone-related database constraint that must be handled. Do not work on marketing navigation or dashboard UI in this phase.

## Problem Restatement

The user wants to enter a business phone number without manually typing `+1`.

Expected UX:
- User types `5142494425`.
- Input automatically displays `514-249-4425`.
- User does not type `+1`.
- User does not type dashes manually.
- Backend stores/sends the normalized phone value as E.164:
  - `+15142494425`

Current symptom:
- The form may show:

```text
Phone number must be a valid E.164 number.
```

The app must make the phone field easy, forgiving, and reliable.

## Files to Read First

Read:

- `src/app/onboarding/page.tsx`
- `src/lib/customers/phone.ts`
- `src/lib/organization/onboarding.ts`
- `src/lib/organization/actions.ts`
- existing tests under `tests/unit`
- `package.json`

## Root Cause Analysis Required

Before changing code, answer internally:

1. Is phone optional or required for organization onboarding?
2. If phone is empty, should it become `null`?
3. Does `normalizePhoneToE164` already accept 10-digit numbers?
4. Does it accept numbers with dashes?
5. Does it accept numbers with parentheses?
6. Does the form input submit an unformatted, formatted, empty, or unexpected value?
7. Is there any frontend masking logic already present?
8. Are there tests proving these cases?

## UX Requirements

The phone field must support:

| Input | Display | Backend normalized value |
|---|---|---|
| `5142494425` | `514-249-4425` | `+15142494425` |
| `514-249-4425` | `514-249-4425` | `+15142494425` |
| `(514) 249-4425` | `514-249-4425` | `+15142494425` |
| `+15142494425` | `514-249-4425` | `+15142494425` |
| `1-514-249-4425` | `514-249-4425` | `+15142494425` |

The field must:
- use `inputMode="tel"`;
- use `autoComplete="tel"`;
- use placeholder `514-249-4425`;
- keep `name="phone"` so `FormData` still works;
- not require user to type `+1`;
- not require user to type dashes;
- not show technical jargon like E.164 to normal users.

Add helper copy:

```text
Le +1 sera ajouté automatiquement.
```

or in English if the page is English:

```text
+1 will be added automatically.
```

Use the language currently supported by the page; do not overbuild a full i18n rewrite if not necessary.

## Implementation Requirements

Create a pure utility, for example:

```text
src/lib/customers/phone-format.ts
```

Functions:

```ts
extractPhoneDigits(input: string): string
formatNorthAmericanPhoneForDisplay(input: string): string
```

Expected formatting:
- `""` -> `""`
- `"5"` -> `"5"`
- `"514"` -> `"514"`
- `"5142"` -> `"514-2"`
- `"514249"` -> `"514-249"`
- `"5142494425"` -> `"514-249-4425"`
- `"514-249-4425"` -> `"514-249-4425"`
- `"(514) 249-4425"` -> `"514-249-4425"`
- `"+15142494425"` -> `"514-249-4425"`
- `"1-514-249-4425"` -> `"514-249-4425"`

Create a client component, for example:

```text
src/components/forms/phone-input.tsx
```

Requirements:
- `"use client"`;
- use `useState`;
- render a real `<input>`;
- support `id`, `name`, `defaultValue`, `className`, `placeholder`;
- use `formatNorthAmericanPhoneForDisplay` on change;
- preserve form submission;
- avoid external dependencies;
- avoid complex masking libraries.

Then replace the phone `<input>` in `/onboarding` with this component.

## Backend Normalization Requirements

Verify `normalizePhoneToE164` accepts:
- `5142494425`
- `514-249-4425`
- `(514) 249-4425`
- `1-514-249-4425`
- `+15142494425`

If phone is optional:
- `buildOrganizationCreateInput({ phone: "" })` must be valid.
- It must return `phone: null`.

If phone is provided but invalid:
- it must return a clear user-facing error.

Avoid exposing "E.164" in the user-facing form error if possible. Prefer:

```text
Enter a valid 10-digit Canadian or US phone number.
```

or French equivalent if the page is French.

## Tests Required

Add tests for display formatting:

```ts
formatNorthAmericanPhoneForDisplay("")
formatNorthAmericanPhoneForDisplay("5142494425")
formatNorthAmericanPhoneForDisplay("514-249-4425")
formatNorthAmericanPhoneForDisplay("(514) 249-4425")
formatNorthAmericanPhoneForDisplay("+15142494425")
formatNorthAmericanPhoneForDisplay("1-514-249-4425")
```

Add tests for backend normalization:

```ts
normalizePhoneToE164("5142494425")
normalizePhoneToE164("514-249-4425")
normalizePhoneToE164("(514) 249-4425")
normalizePhoneToE164("1-514-249-4425")
normalizePhoneToE164("+15142494425")
normalizePhoneToE164("514") // reject
normalizePhoneToE164("12345678901234567890") // reject
```

Add tests for onboarding input builder:

```ts
buildOrganizationCreateInput({ phone: "" }) -> ok, phone null
buildOrganizationCreateInput({ phone: "5142494425" }) -> ok, phone "+15142494425"
buildOrganizationCreateInput({ phone: "514-249-4425" }) -> ok, phone "+15142494425"
```

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Manual Test

1. Start the app.
2. Open `/onboarding`.
3. Type `5142494425`.
4. Confirm the field displays `514-249-4425`.
5. Confirm no `+1` typing is needed.
6. Submit the form after Phase 1 SQL is applied.
7. Confirm no phone validation error appears.
8. Confirm dashboard redirect works if all other phases are complete.

## Rollback Strategy

Rollback is safe:
- revert the component and utility changes;
- restore the plain input;
- no DB data is affected by this phase.

## Final Report for This Phase

Report:

1. Root cause.
2. Files changed.
3. Phone behavior before/after.
4. Tests added.
5. Validation results.
6. Any remaining phone limitations.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
