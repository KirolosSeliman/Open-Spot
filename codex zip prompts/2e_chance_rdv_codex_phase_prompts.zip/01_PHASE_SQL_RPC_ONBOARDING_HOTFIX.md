# 01 — Phase SQL/RPC Onboarding Hotfix

## Role

You are a senior Supabase/PostgreSQL engineer, senior backend engineer, senior data analyst, senior problem analyst, and senior security-focused systems architect.

You are working only on **Phase 1: fixing the SQL/RPC onboarding failure**.

Do not touch unrelated UI, dashboard, marketing, or styling in this phase unless a file is strictly required to understand the RPC call.

## Problem Restatement

The user cannot create an organization from `/onboarding`.

Known symptoms:
- `function pg_catalog.coalesce(text, unknown) does not exist`
- sometimes the user also sees phone-related validation errors, but this phase focuses only on the SQL/RPC failure.

The onboarding flow should be:

```text
signup -> onboarding -> create_organization_with_owner RPC -> dashboard
```

The flow is currently blocked because the Supabase RPC function used to create the organization is broken.

## Confirmed Context

The app calls:

```ts
supabase.rpc("create_organization_with_owner", ...)
```

The SQL migrations may contain invalid calls such as:

```sql
pg_catalog.coalesce(...)
pg_catalog.nullif(...)
```

In PostgreSQL, `COALESCE` and `NULLIF` are special SQL expressions and must not be schema-qualified as `pg_catalog.coalesce` or `pg_catalog.nullif`.

Use:

```sql
coalesce(...)
nullif(...)
```

Do not replace valid `pg_catalog` functions such as:
- `pg_catalog.btrim`
- `pg_catalog.lower`
- `pg_catalog.length`
- `pg_catalog.now`
- `pg_catalog.jsonb_build_object`

## Files to Read First

Read these before editing:

- `src/lib/organization/actions.ts`
- `src/lib/organization/onboarding.ts`
- `src/lib/organization/current.ts`
- `src/lib/supabase/server.ts`
- `src/app/onboarding/page.tsx`
- `supabase/migrations/*.sql`
- `tests/unit/*.test.ts`
- `package.json`

## Root Cause Analysis Required

Before changing code, identify:

1. Which function currently handles organization creation.
2. Which migration originally defines `private.create_organization_with_owner`.
3. Which migration defines `public.create_organization_with_owner`.
4. Whether a previous hotfix only fixed permissions and not invalid `pg_catalog.coalesce` usage.
5. Every occurrence of:
   - `pg_catalog.coalesce`
   - `pg_catalog.nullif`
6. Whether the live DB likely needs a new additive migration because older migrations were already applied.

## Solution Requirements

Create a **new additive migration**. Do not rely only on modifying old migrations.

Recommended migration name:

```text
supabase/migrations/20260526008000_fix_onboarding_rpc_conditional_expressions.sql
```

The migration must:

1. Redefine with `create or replace function`:
   - `private.create_organization_with_owner`
   - `public.create_organization_with_owner`

2. Fix invalid expressions:
   - `pg_catalog.coalesce(...)` -> `coalesce(...)`
   - `pg_catalog.nullif(...)` -> `nullif(...)`

3. Check and fix all other RPCs if they contain the same invalid patterns:
   - `public.register_waitlist_signup`
   - `public.validate_opening_offer`
   - any other function in migrations.

4. Preserve security:
   - keep `set search_path = ''`;
   - keep `security definer` only where needed for trusted bootstrap logic;
   - keep public wrapper as `security invoker` if that is the current architecture;
   - do not grant broad anon/public access;
   - do not expose service-role behavior to client code.

5. Preserve data:
   - no `drop table`;
   - no `truncate`;
   - no destructive `delete`;
   - no manual organization insert;
   - no manual membership insert.

## Required SQL Safety Tests

Update or add migration tests so they:

1. Load all `supabase/migrations/*.sql`.
2. Assert no migration contains:
   - `pg_catalog.coalesce`
   - `pg_catalog.nullif`

3. Assert the new hotfix migration contains:
   - `create or replace function private.create_organization_with_owner`
   - `create or replace function public.create_organization_with_owner`
   - `coalesce(`
   - `nullif(`
   - `set search_path = ''`

4. Assert the new migration does not contain:
   - `drop table`
   - `truncate`
   - `delete from public.organizations`
   - `delete from public.organization_members`

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If Supabase CLI is available:

```bash
supabase migration list --linked
supabase db push
```

If unavailable, report that clearly and provide the command for the user.

## Manual Test After This Phase

After applying the migration:

1. Go to `/onboarding`.
2. Enter a valid organization name.
3. Leave slug empty.
4. Leave phone empty for this phase or enter a known valid normalized value.
5. Submit.
6. Confirm the error is gone:

```text
function pg_catalog.coalesce(text, unknown) does not exist
```

7. Confirm the flow reaches `/dashboard` or reaches the next legitimate validation issue.

## Rollback Strategy

Because this is additive and uses `create or replace function`, rollback is:

1. Revert the migration commit if not applied.
2. If applied, create a new migration restoring the previous known-good function definitions.
3. Do not drop business data.

## Final Report for This Phase

Report:

1. Root cause.
2. Exact invalid SQL patterns found.
3. New migration file name.
4. Functions redefined.
5. Why the fix is non-destructive.
6. Commands run and results.
7. Supabase CLI push status.
8. Remaining risks before Phase 2.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
