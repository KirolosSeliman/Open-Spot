# 05 — Phase Final Deployment and Regression Audit

## Role

You are a senior release engineer, senior QA lead, senior security reviewer, senior data integrity analyst, and senior production-readiness architect.

You are working only on **Phase 5: final audit, deployment readiness, and regression protection**.

Do not add new features. Do not redesign. Do not refactor broadly. Verify that previous phases are safe to deploy.

## Problem Restatement

The project had multiple related issues:
- broken onboarding RPC;
- invalid PostgreSQL conditional expressions;
- phone input UX/normalization problems;
- missing auth navigation;
- visible legacy branding;
- incomplete dashboard access testing.

This phase ensures the final result is stable, secure, efficient, and deployable.

## Files and Areas to Audit

Review:

- changed files from all previous phases
- `supabase/migrations/*.sql`
- `tests/unit/*.test.ts`
- `src/app/onboarding/page.tsx`
- `src/lib/organization/actions.ts`
- `src/lib/organization/onboarding.ts`
- `src/lib/customers/phone.ts`
- `src/lib/customers/phone-format.ts` if created
- `src/components/forms/phone-input.tsx` if created
- `src/components/marketing/open-spot-funnel.tsx`
- `src/components/layout/site-header.tsx`
- `src/app/sign-in/page.tsx`
- `src/app/signup/page.tsx`
- `src/app/dashboard/**`
- `package.json`

## Audit Checklist

### SQL and Migration Safety

Confirm:
- no `pg_catalog.coalesce`;
- no `pg_catalog.nullif`;
- no destructive SQL in hotfix migrations;
- migration filenames are ordered correctly;
- new migration is additive;
- functions keep `set search_path = ''`;
- service-role is not over-granted;
- anon/public do not get sensitive access.

### Auth and Security

Confirm:
- no service-role key in client components;
- no secrets committed;
- sign-in works;
- sign-up works;
- sign-out works;
- onboarding requires auth;
- dashboard requires auth when Supabase is configured;
- organization access remains scoped.

### Phone UX and Data

Confirm:
- phone can be blank if optional;
- phone can be typed as `5142494425`;
- display becomes `514-249-4425`;
- backend normalized value becomes `+15142494425`;
- invalid phone gives a clear error;
- no E.164 jargon appears unnecessarily in UI.

### Navigation and Branding

Confirm:
- landing header exposes auth access;
- mobile header exposes auth access;
- CTA call still exists;
- public logo uses `2e Chance RDV`;
- no prominent public `Open Spot` remains unless intentionally documented as debt.

### Build Quality

Confirm:
- no TypeScript errors;
- no lint errors;
- tests pass;
- build passes;
- no hydration warnings introduced by client/server mismatch if locally testable.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If Supabase CLI available:

```bash
supabase migration list --linked
supabase db push
```

Optionally if local Supabase is available:

```bash
supabase db reset
```

Only run local reset on a disposable local database. Never run destructive reset on linked production/staging.

## Required Final Manual QA Script

1. Open `/`.
2. Confirm public nav:
   - `2e Chance RDV`
   - `Connexion`
   - `Créer un compte`
   - `Réserver un appel`
3. Click `Créer un compte`.
4. Create test user.
5. Confirm email if needed.
6. Complete onboarding:
   - name: `Kiro`
   - slug: blank
   - phone: `5142494425`
7. Confirm phone displays `514-249-4425`.
8. Submit.
9. Confirm no SQL error.
10. Confirm no phone error.
11. Confirm redirect to `/dashboard`.
12. Sign out.
13. Sign in.
14. Confirm dashboard loads.
15. Test mobile layout.
16. Test language toggle.
17. Test call booking route.

## Deployment Readiness Report

Produce:

1. Release summary.
2. Commits/changes grouped by phase.
3. Migrations added.
4. Commands run and results.
5. Manual QA result.
6. Security findings.
7. Remaining risks.
8. Exact commands for the user:

```bash
git pull
npm install
supabase db push
npm run dev
```

9. If deployed on Vercel:
   - confirm environment variables required;
   - confirm Supabase URL/key availability;
   - remind not to expose service-role key publicly.

## Rollback Strategy

If deployment fails:

1. Do not delete data.
2. Revert frontend commit if only UI broke.
3. For migration issues, create a forward-fix migration.
4. Do not run production reset.
5. Document exact failed command/log.

## Final Acceptance Criteria

The work is complete only if:

- onboarding works;
- phone input works;
- dashboard access works;
- auth navigation is visible;
- SQL errors are gone;
- tests pass;
- build passes;
- migrations are safe;
- no destructive operations were used;
- remaining limitations are explicitly documented.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
