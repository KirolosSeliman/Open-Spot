# 03 — Phase Auth Navigation and Public Branding

## Role

You are a senior UX/UI engineer, senior frontend engineer, senior Next.js App Router engineer, senior accessibility reviewer, and senior product strategist.

You are working only on **Phase 3: fixing visible auth navigation and public branding**.

Do not touch SQL/RPC or phone normalization in this phase unless needed to avoid conflicts.

## Problem Restatement

The landing page still does not clearly expose authentication access.

Known symptom:
- The visible header still shows:
  - `Open Spot`
  - `Comment ça marche`
  - `Pourquoi Open Spot`
  - `Prix`
  - `Réserver un appel`
  - `FR / EN`
- There is no obvious `Connexion`, `Créer un compte`, or `Dashboard` button.

The user needs to test the dashboard without manually typing URLs.

## Files to Read First

Read:

- `src/app/page.tsx`
- `src/components/marketing/open-spot-funnel.tsx`
- `src/components/layout/site-header.tsx`
- `src/components/layout/page-shell.tsx`
- `src/app/sign-in/page.tsx`
- `src/app/signup/page.tsx`
- `src/app/dashboard/page.tsx`
- `src/lib/auth/actions.ts`
- `src/lib/organization/current.ts`

## Root Cause Analysis Required

Before editing, identify:

1. Which header is actually rendered on `/`.
2. Whether `/` uses `PageShell`.
3. Whether `SiteHeader` affects the landing page.
4. Whether `MarketingHeader` contains auth links.
5. Whether auth links are hidden on mobile.
6. Whether public branding still says `Open Spot`.
7. Which links/routes already exist:
   - `/sign-in`
   - `/signup`
   - `/dashboard`
   - `/book-call/questions`

## Required UX Outcome

On `/`, the user must clearly see or access:

Desktop:
- `2e Chance RDV` logo
- `Comment ça marche`
- `Pourquoi 2e Chance RDV`
- `Prix`
- `Connexion`
- `Créer un compte`
- `Réserver un appel`
- language toggle

Mobile:
- `2e Chance RDV`
- `Connexion`
- `Créer un compte`
- access to commercial CTA or menu
- no hidden auth links without alternative

## Implementation Requirements

### MarketingHeader

Update the real landing page header in:

```text
src/components/marketing/open-spot-funnel.tsx
```

Add:
- `Connexion` / `Sign in` -> `/sign-in`
- `Créer un compte` / `Sign up` -> `/signup`
- optional `Dashboard` -> `/dashboard` if auth state is easy and safe to know

Keep:
- `Réserver un appel` / `Book a call` -> `/book-call/questions`
- language toggle

Do not let `Réserver un appel` replace auth access.

### SiteHeader

Also update:

```text
src/components/layout/site-header.tsx
```

When not signed in:
- show `Connexion` -> `/sign-in`
- show `Créer un compte` -> `/signup`

When signed in:
- show `Dashboard` -> `/dashboard`
- show `Déconnexion`

Do not break `signOutAction`.

### Sign In Page

Add a clear link under the form:

```text
Pas encore de compte ? Créer un compte
```

to `/signup`.

### Signup Page

Add a clear link under the form:

```text
Déjà un compte ? Se connecter
```

to `/sign-in`.

## Branding Requirements

Public-facing text should use:

```text
2e Chance RDV
```

Replace visible public text:
- `Open Spot` -> `2e Chance RDV`
- `Pourquoi Open Spot` -> `Pourquoi 2e Chance RDV`

Do not rename files/components in this phase unless safe and minimal. If internal names like `OpenSpotFunnel` remain, report as technical debt.

## Accessibility Requirements

- Use real `Link` components for navigation.
- Use real `button` for language toggle/menu.
- Keep keyboard focus styles.
- Use clear labels.
- Avoid clickable `div`.
- Ensure mobile auth links are not inaccessible.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Manual Test

1. Open `/`.
2. Confirm header shows `2e Chance RDV`.
3. Confirm `Connexion` is visible or accessible.
4. Confirm `Créer un compte` is visible or accessible.
5. Click `Connexion`; verify `/sign-in`.
6. Click `Créer un compte`; verify `/signup`.
7. Confirm `/sign-in` links to `/signup`.
8. Confirm `/signup` links to `/sign-in`.
9. Test mobile width.
10. Confirm language toggle still works.
11. Confirm `Réserver un appel` still works.

## Rollback Strategy

Revert only the header/auth-link files. No DB changes are involved.

## Final Report for This Phase

Report:

1. Root cause.
2. Real header modified.
3. Auth links added.
4. Branding changes.
5. Desktop/mobile behavior.
6. Tests and build results.
7. Remaining technical debt.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
