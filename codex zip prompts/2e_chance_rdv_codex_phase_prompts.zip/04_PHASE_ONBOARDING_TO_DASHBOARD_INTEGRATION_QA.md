# 04 — Phase Onboarding to Dashboard Integration QA

## Role

You are a senior full-stack engineer, senior QA lead, senior systems integration engineer, senior Supabase Auth engineer, and senior product reliability analyst.

You are working only on **Phase 4: verifying and hardening the full onboarding-to-dashboard integration**.

Do not add new product features. Do not redesign the dashboard. Focus on the complete flow working reliably.

## Problem Restatement

Even if SQL, phone input, and navigation are fixed separately, the full user journey must work end-to-end:

```text
landing page -> signup -> onboarding -> create organization -> dashboard -> sign out -> sign in -> dashboard
```

This phase ensures all previous fixes integrate correctly.

## Files to Read First

Read:

- `src/app/sign-in/page.tsx`
- `src/app/signup/page.tsx`
- `src/app/onboarding/page.tsx`
- `src/app/dashboard/page.tsx`
- `src/lib/auth/actions.ts`
- `src/lib/organization/actions.ts`
- `src/lib/organization/current.ts`
- `src/lib/organization/onboarding.ts`
- `src/lib/supabase/server.ts`
- `src/components/layout/site-header.tsx`
- `src/components/marketing/open-spot-funnel.tsx`
- relevant Supabase migrations
- tests

## Root Cause Analysis Required

Identify whether any of these can still break the flow:

1. User created but email confirmation blocks login.
2. User logged in but no organization membership exists.
3. Organization creation RPC succeeds but membership is missing.
4. Organization creation succeeds but billing settings missing.
5. Dashboard expects membership and redirects incorrectly.
6. Header auth state is stale.
7. Supabase env not configured.
8. Local and linked Supabase DB are out of sync.
9. Migrations exist locally but were not pushed.

## Integration Requirements

The system must support:

1. New user signs up.
2. User reaches onboarding.
3. User creates organization.
4. RPC creates:
   - organization
   - organization_members row with role `owner`
   - billing settings if architecture expects it
   - audit log if architecture expects it
5. User redirects to `/dashboard`.
6. Dashboard loads without crashing.
7. Sign out works.
8. Sign in works.
9. Returning user goes to dashboard, not onboarding.

## Data Integrity Requirements

Do not manually insert data.

Verify the RPC itself handles:
- organization creation;
- owner membership creation;
- related required records;
- slug uniqueness;
- single-org mode if currently enforced.

If any related required record is missing from RPC, fix through additive migration or server action only if architecturally justified.

## Error Handling Requirements

User-facing errors should be understandable.

Avoid exposing:
- raw PostgreSQL internal errors;
- stack traces;
- `E.164` jargon if avoidable;
- security-sensitive details.

Keep detailed error logging server-side only if existing logging patterns allow it.

## Tests Required

Add/update tests for:

1. `decideWorkspaceRedirect`
2. `redirectAuthenticatedUserByWorkspace` behavior if already testable
3. organization input builder:
   - slug auto-generation
   - optional phone
   - phone normalization
   - invalid phone
   - default language
   - timezone validation

If integration tests are not available, document manual QA.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If Supabase CLI is available:

```bash
supabase migration list --linked
supabase db push
```

## Manual End-to-End Test

Perform or describe:

1. Open `/`.
2. Click `Créer un compte`.
3. Create a new test user.
4. Confirm email if Supabase requires it.
5. Go to `/onboarding`.
6. Create organization:
   - name: `Kiro`
   - slug: blank
   - email: blank or valid email
   - phone: `5142494425`
   - timezone: `America/Toronto`
   - language: `Francais`
7. Confirm redirect to `/dashboard`.
8. Confirm dashboard displays the organization or stable demo state.
9. Sign out.
10. Sign in again.
11. Confirm redirect to `/dashboard`.
12. Confirm user is not stuck in onboarding.

## Rollback Strategy

Rollback should not delete data. If integration hardening requires a migration, create a new forward migration to restore prior function behavior if needed.

## Final Report for This Phase

Report:

1. Full flow status.
2. Files changed.
3. Any migration changes.
4. Auth behavior.
5. Dashboard behavior.
6. Manual test result.
7. Validation command results.
8. Remaining deployment risks.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
