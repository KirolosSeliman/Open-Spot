# Phase 1 — Product and Branding Coherence

## Target problem

The product must be publicly coherent as **Open Spot** before deeper SaaS implementation continues.

The repository likely contains mixed naming between `2e Chance RDV`, `Open Spot`, and possibly legacy variants. Some documentation may still describe the repo as documentation-only even though application code already exists. The landing page may also contain AI-related promises even though AI is not part of the current MVP.

This creates credibility risk, implementation confusion, and sales risk.

## Target solution

Make Open Spot the clear public brand across the product, marketing copy, metadata, and documentation.

Preserve historical context only where useful and non-destructive. Do not perform risky filesystem/repo renames unless they are clearly safe and necessary.

Remove or de-emphasize unsupported AI claims from the public product until an actual, secure, testable AI feature exists.

## Scope

Implement only branding/product coherence.

Do not implement auth, database, RLS, onboarding, SMS, dashboard, billing, AI, integrations, or analytics in this phase.

## Files to inspect first

Read and understand:

- `README.md`
- `package.json`
- `docs/product-requirements.md`
- `docs/architecture.md`
- `docs/roadmap.md`
- `docs/design-direction.md`
- `docs/security-and-privacy.md`
- `docs/sms-compliance-notes.md`
- `src/app/layout.tsx`
- `src/app/page.tsx`
- `src/components/marketing/open-spot-funnel.tsx`
- `src/components/marketing/open-spot-booking-page.tsx`
- all other files containing:
  - `2e Chance RDV`
  - `2e chance`
  - `2ie`
  - `Deuxième`
  - `Open Spot`
  - `Vistaire`
  - `AI`
  - `IA`
  - `smart targeting`
  - `ciblage intelligent`

Use repository search before editing.

## Required changes

### 1. Public product name

Use **Open Spot** as the public product name.

Update public-facing copy where appropriate:

- page metadata;
- landing page header;
- hero copy if needed;
- CTA pages;
- docs title/definition;
- README project title.

### 2. Legacy naming

If useful, keep a single short note in documentation such as:

> Earlier working name: 2e Chance RDV. Public brand moving forward: Open Spot.

Do not scatter legacy names throughout public product copy.

Do not break routes, package names, or repository names just to rename everything. If package/repo names remain legacy for now, document that this is non-public technical history and not a product problem.

### 3. Remove unsupported AI claims

The MVP must not publicly promise AI if the actual implementation is not present.

Find and adjust copy such as:

- `Ciblage intelligent par IA`
- `AI smart targeting`
- `Open Spot utilise un agent IA`
- AI-based prioritization claims
- any fake AI workflow visual

Replace with honest MVP language:

- eligible opted-in customers;
- service preferences;
- merchant-controlled contact selection;
- rules-based filtering later if implemented;
- no automatic booking.

Avoid promising advanced targeting.

### 4. Fix outdated documentation

Update `docs/architecture.md` if it still says the repo has documentation only.

It should reflect the real current state after inspection, for example:

- Next.js App Router exists;
- TypeScript exists;
- marketing landing exists;
- booking call page exists;
- Supabase dependencies exist;
- secure SaaS backend foundation is still pending;
- Supabase migrations/RLS/auth/onboarding are next.

### 5. Keep Vistaire separated

Search for `Vistaire`.

If present, ensure it only appears in a short separation note if necessary.

Never describe Open Spot as a Vistaire extension.

## Security and quality constraints

- Do not change secrets or env values.
- Do not add third-party scripts.
- Do not add analytics/tracking.
- Do not add AI dependencies.
- Do not make false claims in public copy.
- Do not remove compliance warnings.
- Keep bilingual copy coherent in French and English.
- Preserve accessibility basics: labels, semantic structure, readable CTA text.

## Acceptance criteria

This phase is complete only if:

- Public brand is consistently **Open Spot**.
- Legacy names are cleaned or explained without breaking the repo.
- Public landing no longer claims AI functionality that is not implemented.
- Documentation reflects the actual repo state.
- The product remains clearly about SMS cancellation recovery.
- The manual merchant validation rule is preserved everywhere.
- No Vistaire confusion remains.
- Lint/typecheck/build pass or failures are clearly unrelated and documented.

## Validation commands

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

If any command is unavailable or fails, explain why and whether the failure is caused by your changes.

## Required final report

Report:

- every file changed;
- every naming inconsistency fixed;
- every AI claim removed or rewritten;
- any legacy naming intentionally left and why;
- validation command results;
- remaining risks.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
