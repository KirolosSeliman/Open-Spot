# Phase 4 — Supabase Auth Helpers and Auth Pages

## Target problem

Open Spot needs a secure authentication layer before merchants can access private SaaS pages.

The repo has Supabase dependencies, but the app must have safe server/client Supabase helpers, auth pages, protected routes, session handling, and environment documentation.

## Target solution

Implement Supabase Auth integration for Next.js App Router:

1. server-side Supabase client helper;
2. browser/client Supabase client helper where needed;
3. middleware/session refresh if appropriate for the current Supabase SSR pattern;
4. sign-up page;
5. sign-in page;
6. sign-out action;
7. protected dashboard route shell;
8. redirect logic for signed-in users without an organization.

## Scope

Implement auth foundation only.

Do not implement:

- full dashboard features;
- SMS;
- waitlist;
- customers;
- services;
- billing;
- AI;
- complex member invites.

## Files to inspect first

Read:

- `package.json`
- existing `src/lib/`
- existing `src/app/`
- existing `middleware.ts`
- existing auth-related files
- Supabase docs/comments already in repo
- `.env.example` if present
- `README.md`
- `docs/architecture.md`
- `docs/security-and-privacy.md`

## Required implementation

### 1. Environment variables

Document required variables in `.env.example` or equivalent documentation:

```env
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
```

Rules:

- `NEXT_PUBLIC_` variables may be used in browser.
- `SUPABASE_SERVICE_ROLE_KEY` must never be imported into client components.
- Do not commit `.env.local`.
- Do not invent real values.

### 2. Supabase clients

Create helpers with clear separation:

```text
src/lib/supabase/server.ts
src/lib/supabase/client.ts
src/lib/supabase/admin.ts
```

Adjust names to match existing repo conventions.

Rules:

- `server.ts`: server component/actions client using cookies/session.
- `client.ts`: browser client for client components if needed.
- `admin.ts`: service role client, server-only, guarded to prevent client import.
- Do not expose service role to frontend bundles.

### 3. Auth pages

Add simple, professional pages:

```text
src/app/(auth)/sign-in/page.tsx
src/app/(auth)/sign-up/page.tsx
```

Use safe forms and server actions or route handlers.

Required UX:

- bilingual-ready labels if the current app supports bilingual copy;
- simple error messages;
- no fake promises;
- accessible labels;
- mobile-friendly layout.

### 4. Sign-out

Implement sign-out safely:

- server action or route handler;
- clears Supabase session;
- redirects to sign-in or home.

### 5. Protected route shell

Add a minimal protected dashboard route:

```text
src/app/(dashboard)/dashboard/page.tsx
```

If user is not signed in, redirect to sign-in.

If user is signed in but has no active organization, redirect to `/onboarding`.

If user has an active organization, show a minimal dashboard shell.

### 6. Middleware

If needed for Supabase SSR, implement `middleware.ts` to refresh auth session safely.

Keep middleware minimal.

Do not put business authorization in middleware alone.

## Security constraints

- No service role in client code.
- No secrets in public env files.
- No auth bypass for dashboard pages.
- No client-only protection for private pages.
- No broad catch-all middleware that breaks static/public pages.
- No unsafe logging of tokens or cookies.
- No real customer data in test/dev seed.
- Do not weaken RLS created in Phase 3.

## Documentation updates

Update:

- `README.md` or docs with local env setup;
- architecture docs with auth helper locations;
- security docs with secret handling if needed.

## Acceptance criteria

This phase is complete only if:

- Users can sign up.
- Users can sign in.
- Users can sign out.
- Unauthenticated users cannot access dashboard pages.
- Signed-in users without organization are redirected to onboarding.
- Service role key is server-only.
- Env variables are documented.
- Lint/typecheck/test/build pass or failures are documented.

## Validation commands

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

If local Supabase credentials are unavailable, verify static/type/build behavior and report that live auth flow was not tested.

## Required final report

Report:

- auth files added/changed;
- route behavior;
- secret handling decisions;
- validation results;
- what needs real Supabase project testing.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
