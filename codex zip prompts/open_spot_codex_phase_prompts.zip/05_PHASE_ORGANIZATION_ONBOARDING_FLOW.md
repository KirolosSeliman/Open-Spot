# Phase 5 — Organization Onboarding Flow

## Target problem

A signed-in merchant must be able to create their business workspace safely.

Open Spot needs organization onboarding that creates:

1. an organization;
2. organization settings;
3. a profile for the current user if needed;
4. an active `owner` membership for the current user.

This must happen securely and consistently.

## Target solution

Implement a protected `/onboarding` flow that lets a signed-in user create their Open Spot organization.

The creation must be transaction-safe and must not allow role escalation, cross-tenant access, or partial broken setup.

## Scope

Implement only organization onboarding.

Do not implement:

- full dashboard;
- member invites;
- SMS;
- customers;
- services;
- waitlist;
- billing;
- AI.

## Files to inspect first

Read:

- existing Supabase schema/migrations;
- RLS policies;
- auth helpers;
- dashboard route logic;
- `docs/product-requirements.md`;
- `docs/security-and-privacy.md`;
- `docs/data-model.md`;
- existing `src/app/(auth)` and `src/app/(dashboard)` files;
- existing `src/lib/supabase` files.

## Required UX

Create:

```text
src/app/onboarding/page.tsx
```

or follow the existing route convention.

The page should ask for:

- business name;
- public slug, auto-suggested from name but editable;
- default language: French or English;
- timezone, default `America/Toronto`.

Keep it simple and mobile-friendly.

Required behavior:

- if unauthenticated, redirect to sign-in;
- if already has active organization, redirect to dashboard;
- if no organization, show onboarding form;
- on submit, create organization and owner membership;
- on success, redirect to dashboard.

## Required backend behavior

Use one of these safe patterns:

### Preferred pattern A: server-side action with admin client

Use a server action that:

- verifies current authenticated user;
- uses server-only Supabase admin client;
- creates or finds the user profile;
- creates organization;
- creates organization settings;
- creates owner membership;
- handles duplicate slug errors safely;
- never trusts client role input.

### Preferred pattern B: secure database RPC

Use a `security definer` SQL function only if it is carefully designed with safe `search_path`, current `auth.uid()` validation, and least privilege.

Do not mix patterns randomly.

The flow must be transaction-safe. If one part fails, avoid leaving a broken organization without owner/settings.

## Required validation

Validate input:

- business name required;
- slug required;
- slug lowercase URL-safe;
- default language in `fr` or `en`;
- timezone from a safe allowed list or a conservative default;
- no client-provided role accepted;
- no client-provided profile ID accepted.

## Data integrity requirements

On successful onboarding:

- `organizations` has a new row;
- `profiles` has a row linked to `auth.users.id`;
- `organization_members` has one active owner row;
- `organization_settings` has one row;
- dashboard can find the current active organization.

## Security constraints

- Do not expose service role key client-side.
- Do not allow user to choose role.
- Do not allow owner membership for another profile.
- Do not allow creating organization for another user.
- Do not ignore RLS implications.
- Do not rely on client-side redirects only.
- Do not create fake users.
- Do not create seed merchants with real data.

## Documentation updates

Update docs with:

- onboarding flow behavior;
- route names;
- server action/RPC choice;
- known setup/testing requirements.

## Acceptance criteria

This phase is complete only if:

- Signed-in user without org can create organization.
- User becomes owner automatically.
- Organization settings are created.
- Duplicate slug error is handled clearly.
- Existing org user is redirected away from onboarding.
- Unauthenticated user is redirected to sign-in.
- Dashboard route recognizes organization membership.
- No role escalation path exists.
- Lint/typecheck/test/build pass or failures are documented.

## Validation commands

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

If real Supabase env is not available, test as much as possible with build/type checks and describe exact manual live-test steps.

## Required final report

Report:

- onboarding files added/changed;
- backend pattern chosen and why;
- security decisions;
- validation results;
- manual test steps;
- remaining limitations.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
