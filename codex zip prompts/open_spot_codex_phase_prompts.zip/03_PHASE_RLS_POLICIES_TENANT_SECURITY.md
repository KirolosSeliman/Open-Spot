# Phase 3 — RLS Policies and Tenant Security

## Target problem

Open Spot stores organization-scoped business data. Without strict Row Level Security and server-side authorization, one merchant could accidentally or maliciously access another merchant’s data.

This is launch-blocking.

## Target solution

Implement Row Level Security for the foundational SaaS tables:

- `organizations`
- `profiles`
- `organization_members`
- `organization_settings`

Add safe helper functions for membership and role checks.

RLS must enforce tenant isolation at the database layer. Client-side checks are not enough.

## Scope

Implement only foundational RLS and security helpers.

Do not implement:

- auth UI;
- onboarding UI;
- services/customers/consents;
- SMS;
- billing;
- analytics;
- dashboard features.

## Files to inspect first

Read:

- all existing Supabase migrations;
- `docs/security-and-privacy.md`;
- `docs/data-model.md`;
- `docs/product-requirements.md`;
- any existing Supabase helper files;
- any existing tests related to database or security.

## Required RLS principles

Use these principles:

1. Enable RLS on every public table created for Open Spot.
2. Authenticated users can only read organizations where they are active members.
3. Users can read and update their own profile.
4. Organization members can read active membership records for their organization.
5. Only owners/managers can manage organization settings.
6. Staff should not manage organization settings.
7. No anonymous access to private tables.
8. No cross-organization leakage.
9. Avoid recursive RLS bugs when checking membership.
10. Sensitive writes should be done through controlled server-side logic or safe database functions.

## Required helper functions

Create safe SQL helper functions if not already present.

Recommended functions:

```sql
current_profile_id()
is_org_member(target_organization_id uuid)
has_org_role(target_organization_id uuid, allowed_roles text[])
```

Requirements:

- Use `auth.uid()` carefully.
- Explicitly handle unauthenticated users.
- Avoid infinite recursion in policies.
- Use `security definer` only when appropriate.
- Set a safe `search_path`.
- Do not expose dangerous functions to anonymous users unnecessarily.
- Grant only required execute permissions.

## Required policies

### `profiles`

- SELECT: user can read own profile.
- UPDATE: user can update own profile but not change `auth_user_id`.
- INSERT: user can create own profile if needed, or document if profile creation happens through server-side onboarding logic.

### `organizations`

- SELECT: active members can read their organizations.
- UPDATE: owners/managers can update safe organization fields.
- INSERT: only through controlled onboarding flow or secure server logic.
- DELETE: do not allow from client unless explicitly implemented with strong owner-only rules. Prefer no delete policy for now.

### `organization_members`

- SELECT: active members can read members of their own organization.
- INSERT/UPDATE/DELETE: owner/manager only if implemented. If member management is not in scope yet, keep writes restricted and document.
- Never allow staff to elevate roles.
- Never allow a user to make themselves owner through client-side writes.

### `organization_settings`

- SELECT: owners/managers can read full settings. If staff needs limited settings later, implement separate safe server-side projection later.
- UPDATE: owners/managers only.
- INSERT: only through onboarding/server logic.
- DELETE: no normal client delete.

## Security tests or checks

Add tests if the repo has a practical test setup for SQL/RLS. If not, add a clear manual verification document or SQL comments explaining expected access.

At minimum, document test scenarios:

1. unauthenticated user cannot read private tables;
2. user A cannot read organization B;
3. staff cannot update organization settings;
4. owner can update organization settings;
5. user can read/update own profile only.

## Security constraints

- Do not disable RLS to make app code easier.
- Do not create policies with `using (true)` on private data.
- Do not rely only on frontend route protection.
- Do not use service role from client code.
- Do not create broad grants to `anon`.
- Do not allow role escalation.
- Do not add platform admin bypass unless it is explicitly designed, audited, and server-only.

## Documentation updates

Update documentation to describe:

- enabled RLS tables;
- helper functions;
- policy intent;
- known limitations;
- how to test tenant isolation.

## Acceptance criteria

This phase is complete only if:

- RLS is enabled on all foundational tables.
- Policies are explicit and least-privilege.
- Helper functions are safe and documented.
- No anonymous private access exists.
- Cross-tenant reads are blocked by design.
- Role escalation is blocked by design.
- Owner/manager/staff boundaries are clear.
- Validation commands pass or failures are documented.

## Validation commands

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

If Supabase local testing is available, run the relevant migration reset/test commands and verify RLS behavior with test users.

If Supabase local testing is not available, state exactly what was not verifiable and provide SQL/manual verification steps.

## Required final report

Report:

- RLS migration file name;
- helper functions added;
- policies added table by table;
- security scenarios verified;
- scenarios not verified;
- validation results;
- remaining risks.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
