# Phase 6 — Final Security, QA, and Integration Review

## Target problem

After branding, database foundation, RLS, auth, and onboarding are implemented, the project needs a strict review before moving to customers, consent, waitlist, SMS, or dashboard features.

Skipping this review risks building on broken security, broken auth flow, or inconsistent product positioning.

## Target solution

Perform a focused integration audit and repair only critical issues from Phases 1–5.

This is not a feature-building phase. It is a hardening phase.

## Scope

Review and fix:

- product branding consistency;
- unsupported AI claims;
- docs vs code accuracy;
- Supabase schema integrity;
- RLS policy safety;
- auth helper safety;
- dashboard protection;
- onboarding flow;
- service role isolation;
- env documentation;
- lint/typecheck/test/build;
- route-level behavior.

Do not implement:

- SMS;
- customers;
- services;
- waitlist;
- billing;
- AI;
- advanced dashboard;
- member management.

## Files to inspect first

Inspect all files changed in Phases 1–5, plus:

- `README.md`
- `package.json`
- all docs under `docs/`
- all files under `src/app/`
- all files under `src/lib/`
- all files under `supabase/`
- `middleware.ts`
- env examples
- test files
- config files

## Required audit checklist

### Product coherence

- Public name is Open Spot.
- No Vistaire confusion.
- No unsupported AI claims.
- Manual confirmation rule is present.
- SMS consent positioning is still clear.

### Database

- Foundational tables exist.
- Foreign keys are correct.
- Unique constraints are correct.
- Slug constraints exist.
- `updated_at` triggers work by design.
- No real customer data exists.
- No secrets exist in migrations.

### RLS

- RLS enabled on public app tables.
- Policies are least-privilege.
- Anonymous users cannot read private tables.
- Active membership controls organization access.
- Staff cannot update sensitive settings.
- Role escalation is blocked.
- Helper functions avoid recursion and unsafe search paths.

### Auth

- Sign-up route exists.
- Sign-in route exists.
- Sign-out exists.
- Protected dashboard redirects unauthenticated users.
- Signed-in users without organization redirect to onboarding.
- Service role remains server-only.

### Onboarding

- User can create organization.
- User becomes owner.
- Organization settings created.
- Duplicate slug handled.
- No client role input trusted.
- No cross-user organization creation.

### Code quality

- No unnecessary dependencies.
- No disabled lint rules just to hide errors.
- No TODOs that hide critical launch blockers.
- No large over-engineered abstractions.
- TypeScript remains strict enough.
- UI remains mobile-friendly and accessible.

## Required fixes

Fix only issues that block the foundation from being safe and usable.

If a larger issue belongs to a later phase, document it instead of implementing it.

## Required validation commands

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

If Supabase local CLI and env are available, run migration reset/test commands.

If they are not available, provide exact manual Supabase verification steps.

## Required final verdict

Give one of these verdicts:

- `READY FOR NEXT PHASE`
- `NOT READY — BLOCKERS REMAIN`

Do not say ready if any of these are true:

- RLS is missing or weak;
- service role can reach client code;
- unauthenticated dashboard access exists;
- organization onboarding can create broken records;
- manual validation rule was broken;
- public copy promises unsupported AI;
- build/typecheck/lint fails due to your changes.

## Required final report

Return:

```md
# Final Foundation Review

## Verdict
READY FOR NEXT PHASE or NOT READY — BLOCKERS REMAIN

## What was verified
...

## What was fixed
...

## Validation results
...

## Security risks remaining
...

## Product risks remaining
...

## Exact next phase recommendation
...
```

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
