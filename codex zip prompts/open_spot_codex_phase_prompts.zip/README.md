# Open Spot Codex Phase Prompt Pack

This pack contains one master Codex orchestrator prompt and six phase-specific prompts.

Recommended use:

1. Start with `00_MASTER_CODEX_ORCHESTRATOR.md`.
2. Then run each phase prompt in order.
3. Do not let Codex jump ahead if the current phase has unresolved blockers.

Files:

- `00_MASTER_CODEX_ORCHESTRATOR.md`
- `01_PHASE_PRODUCT_BRANDING_COHERENCE.md`
- `02_PHASE_SUPABASE_FOUNDATIONAL_SCHEMA_MIGRATIONS.md`
- `03_PHASE_RLS_POLICIES_TENANT_SECURITY.md`
- `04_PHASE_SUPABASE_AUTH_HELPERS_AND_AUTH_PAGES.md`
- `05_PHASE_ORGANIZATION_ONBOARDING_FLOW.md`
- `06_PHASE_FINAL_SECURITY_QA_INTEGRATION_REVIEW.md`
