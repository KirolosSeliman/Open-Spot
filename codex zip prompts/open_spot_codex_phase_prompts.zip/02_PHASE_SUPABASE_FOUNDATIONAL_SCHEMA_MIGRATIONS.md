# Phase 2 — Supabase Foundational Schema Migrations

## Target problem

Open Spot cannot become a secure SaaS until it has a real multi-tenant database foundation.

The product needs organizations, authenticated user profiles, organization membership, roles, and organization settings before any customer, consent, SMS, opening, or reporting features can be safely implemented.

## Target solution

Create safe Supabase/PostgreSQL migrations for the base SaaS foundation:

1. `organizations`
2. `profiles`
3. `organization_members`
4. `organization_settings`
5. supporting enums, indexes, timestamps, constraints, and update triggers

This phase must create the schema only. RLS policies are handled in the next phase unless a minimal `enable row level security` statement is part of the schema hardening.

## Scope

Implement only the foundational database schema.

Do not implement:

- login pages;
- onboarding UI;
- dashboard UI;
- SMS features;
- waitlist pages;
- services/customers/consents;
- billing;
- AI;
- real SMS provider logic.

## Files to inspect first

Read:

- `docs/data-model.md`
- `docs/security-and-privacy.md`
- `docs/product-requirements.md`
- `docs/architecture.md`
- existing `supabase/` directory if present
- existing migrations if present
- existing Supabase client/helpers if present
- `package.json`

If no `supabase/migrations` directory exists, create it using the repo’s convention.

## Required schema design

### `organizations`

Purpose: merchant business workspace.

Required fields:

- `id uuid primary key default gen_random_uuid()`
- `name text not null`
- `slug text not null unique`
- `default_language text not null default 'fr'`
- `timezone text not null default 'America/Toronto'`
- `created_at timestamptz not null default now()`
- `updated_at timestamptz not null default now()`

Constraints:

- `default_language` must be limited to `fr` or `en`.
- `slug` should be lowercase URL-safe if possible through a check constraint.
- Do not store private settings in public slug fields.

### `profiles`

Purpose: app profile linked to Supabase Auth users.

Required fields:

- `id uuid primary key default gen_random_uuid()`
- `auth_user_id uuid not null unique references auth.users(id) on delete cascade`
- `full_name text`
- `email text`
- `created_at timestamptz not null default now()`
- `updated_at timestamptz not null default now()`

Constraints:

- Unique `auth_user_id`.
- Email should be nullable if Supabase auth provider does not expose it.
- Do not assume email is verified unless Supabase auth confirms it elsewhere.

### `organization_members`

Purpose: membership between profiles and organizations.

Required fields:

- `id uuid primary key default gen_random_uuid()`
- `organization_id uuid not null references organizations(id) on delete cascade`
- `profile_id uuid not null references profiles(id) on delete cascade`
- `role text not null`
- `status text not null default 'active'`
- `created_at timestamptz not null default now()`

Constraints:

- Unique `(organization_id, profile_id)`.
- Role limited to launch-safe roles:
  - `owner`
  - `manager`
  - `staff`
- Status limited to:
  - `active`
  - `invited`
  - `disabled`

Do not implement complex invites yet unless existing docs already require it in this phase.

### `organization_settings`

Purpose: configurable behavior per organization.

Required fields:

- `id uuid primary key default gen_random_uuid()`
- `organization_id uuid not null unique references organizations(id) on delete cascade`
- `default_language text not null default 'fr'`
- `sms_daily_limit integer not null default 50`
- `commission_rate_bps integer`
- `commission_cap_cents integer`
- `created_at timestamptz not null default now()`
- `updated_at timestamptz not null default now()`

Constraints:

- `default_language` limited to `fr` or `en`.
- `sms_daily_limit >= 0`.
- `commission_rate_bps` nullable but, if present, must be between 0 and 10000.
- `commission_cap_cents` nullable but, if present, must be >= 0.
- Do not store provider secrets here.

### Helpers

Add a reusable `updated_at` trigger function if none exists.

Use a clear naming convention.

Prefer one migration file for this phase, for example:

```text
supabase/migrations/0001_open_spot_foundation.sql
```

If migrations already exist, choose the next safe timestamped migration name instead.

## Security constraints

- Do not expose service role keys.
- Do not create broad public access.
- Do not create tables without thinking about RLS.
- Do not create data that crosses organizations without `organization_id`.
- Do not add seed data with real customer data.
- Do not hardcode real merchant/customer phone numbers.
- Do not store SMS provider credentials in database tables.

## Documentation updates

Update docs only as needed:

- mark foundational schema as implemented;
- document table purposes;
- document any deviation from the proposed data model;
- keep docs short and accurate.

## Acceptance criteria

This phase is complete only if:

- A Supabase migration exists for the foundational schema.
- The four base tables are created safely.
- Constraints and indexes exist for tenant integrity and lookup performance.
- `updated_at` handling exists for mutable tables.
- No real customer data or secrets are committed.
- The migration is idempotent enough for normal migration use and does not drop existing data.
- TypeScript/build is not broken.

## Validation commands

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

If Supabase CLI exists and local Supabase is configured, also run the relevant migration validation command.

If Supabase CLI is not available, inspect the SQL carefully and report that migration execution was not locally verified.

## Required final report

Report:

- migration file name;
- tables created;
- constraints created;
- indexes created;
- trigger functions created;
- any assumptions;
- validation results;
- what RLS/security work remains for Phase 3.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
