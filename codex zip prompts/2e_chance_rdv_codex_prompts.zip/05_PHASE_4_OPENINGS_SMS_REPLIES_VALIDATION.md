# 05 — Phase 4: Openings, SMS Provider, Replies, and Manual Validation


# Project Context — 2e Chance RDV

You are working on **2e Chance RDV**, an independent SaaS project completely separate from Vistaire.

## Product idea

2e Chance RDV is a bilingual SMS-first cancellation recovery platform for appointment-based local businesses.

The product helps businesses fill last-minute appointment cancellations by sending SMS offers to customers who opted into a waitlist. The business keeps its existing appointment system. 2e Chance RDV is not trying to replace Square, Fresha, Booksy, GOrendezvous, Google Calendar, Instagram DMs, phone booking, or paper agendas.

The core positioning is:

> Fill last-minute cancellations by SMS without changing your current appointment system.

## Initial target sectors

The initial target sectors are:

- beauty / esthétique
- barbers
- salons

The product should remain generic enough to later support massage, detailing, clinics, and other appointment-based services.

## Market

The product is not limited to Laval or Montréal. It should be designed for broader use, starting in Canada/Quebec, but not hardcoded to a city.

## Language

The app must support both French and English.

Internal code, database fields, functions, variables, and technical identifiers must be written in English.

User-facing copy must be designed for bilingual support.

## Business model

Starting model:

- 34.99 CAD/month base subscription
- plus a percentage commission on recovered bookings
- commission should only apply when a booking is manually validated by the merchant as recovered/accepted
- percentage and cap should be configurable later

## Key product rules

1. Customers do not need an app.
2. Customers interact by SMS.
3. Businesses use a web dashboard.
4. Businesses keep their existing booking system.
5. The product provides import, waitlist, SMS offers, response tracking, manual validation, and recovered revenue reporting.
6. Last-minute discounts/offers are optional marketing tools, not mandatory.
7. The merchant manually validates the booking. The first customer to reply is not automatically confirmed.
8. The dashboard must show respondents ordered from first response to last response.
9. The winning customer receives confirmation only after the merchant validates them.
10. Customers can unsubscribe by STOP.
11. The system must never send cancellation-recovery SMS to customers who are opted out.
12. Imported customers without clear SMS consent must not be treated as opted in automatically.

## Recommended technical stack

Use the simplest robust SaaS stack:

- Next.js App Router
- TypeScript
- Tailwind CSS
- shadcn/ui or clean reusable UI components
- Supabase Auth
- Supabase Postgres
- Supabase Row Level Security
- Vercel deployment
- Plivo or another low-cost SMS provider, abstracted behind an internal SMS provider interface
- SMS simulator for development/testing
- Stripe later for billing
- Resend later for emails if needed

## Design direction

Professional, simple, clean, mobile-first.

The UI should feel trustworthy and easy for small businesses. Avoid overly flashy, neon, full-dark, sci-fi, or complicated enterprise UI. Use:

- soft off-white or light neutral backgrounds
- charcoal text
- clean cards
- rounded corners
- clear CTAs
- strong spacing
- dashboard-first usability
- mobile-first flows for merchants
- clear status badges and simple tables/lists

## Core entities

At minimum, the system will need:

- organizations
- organization_members / profiles
- services
- customers
- sms_consents
- waitlist_entries
- import_batches
- openings
- opening_offers
- sms_messages
- booking_requests or recovered_bookings
- audit_logs
- settings

## Core flow

1. Merchant imports customers via CSV/Excel or customers join via QR code waitlist page.
2. Customers have SMS consent status: opted_in, needs_consent, opted_out.
3. Merchant creates a last-minute opening.
4. Merchant optionally adds a last-minute offer/discount.
5. System sends SMS only to eligible opted-in waitlist customers.
6. Customers reply OUI / YES / 1.
7. The system records replies in chronological order.
8. Dashboard notifies merchant and shows respondent list.
9. Merchant manually validates one customer.
10. Validated customer receives confirmation SMS.
11. Other respondents receive a polite unavailable message.
12. Dashboard records recovered revenue, discount, and platform commission estimate.

## Non-negotiable quality rules

- Do not invent APIs, dependencies, tables, routes, or environment variables without checking the codebase and documenting the decision.
- Do not hardcode secrets.
- Do not store credentials in client-side code.
- Do not bypass consent rules.
- Do not send SMS to opted-out customers.
- Do not assume imported customers are opted in.
- Do not create unsafe multi-tenant data access.
- Use Row Level Security where appropriate.
- Keep code readable, simple, maintainable, and production-minded.
- Validate with lint, typecheck, build, tests, and manual QA steps when available.
- Return a clear summary of modified files, what was verified, what was not verified, and remaining risks.



## Mission

Implement the core product engine:

- merchant creates a last-minute opening
- system sends SMS to eligible opted-in waitlist customers
- customers reply OUI / YES / 1
- replies are recorded in chronological order
- merchant manually validates one customer
- selected customer receives confirmation
- non-selected respondents receive an unavailable message
- STOP unsubscribe is handled safely

This is the heart of 2e Chance RDV.

## Core business rule

The first customer to reply is not automatically confirmed.

The dashboard must show respondents ordered from first to last. The merchant decides who to validate. Only after manual validation is the customer confirmed.

## Required routes/pages

Create or complete:

```text
/dashboard/openings
/dashboard/openings/new
/dashboard/openings/[id]
/api/sms/send-opening
/api/sms/inbound
/api/openings/[id]/validate
```

Use existing project conventions.

## Required SMS architecture

Build an internal SMS abstraction:

```text
lib/sms/
  provider.ts
  simulator.ts
  plivo.ts
  twilio.ts optional
  templates.ts
  inbound.ts
```

Do not hardcode the provider everywhere.

Required provider interface:

- sendSms(to, body, metadata)
- parseInboundRequest(request)
- verifyWebhookSignature if provider supports it
- normalizePhoneNumber
- getProviderName

Environment variable:

```text
SMS_PROVIDER=simulator | plivo | twilio
```

Use simulator safely in development.

## Opening creation

Merchant creates:

- service
- date/time
- duration
- normal price
- optional last-minute offer:
  - none
  - fixed amount
  - percentage
  - custom offer label
- expiration time
- notes

Opening starts as `draft`.

Merchant can click:

```text
Send SMS offers
```

Then system selects eligible customers.

## Eligibility rules

Only send to customers who:

- belong to the current organization
- have active waitlist entry
- match service if service is specified
- have SMS consent `opted_in`
- are not opted out
- have a valid phone number
- have not already received this opening offer
- are not rate-limited if rate limiting is implemented

Never send to `needs_consent` or `opted_out`.

## Sending strategy

For V1, implement simple sending with clean architecture.

Either:

- send to selected eligible customers immediately
- or send first batch with future-ready batch fields

Do not overbuild a queue unless already present.

Record one `opening_offers` row per customer.

Record each outbound SMS in `sms_messages`.

If provider fails, record failure.

## SMS templates

Templates must be bilingual-ready.

French example:

```text
{businessName} : une place s'est libérée {time} pour {serviceName}. {offerText} Répondez OUI pour demander la place. STOP pour arrêter.
```

English example:

```text
{businessName}: a last-minute spot opened {time} for {serviceName}. {offerText} Reply YES to request it. STOP to unsubscribe.
```

Important: because merchant validates manually, do not say "Reply YES to book automatically".

## Inbound SMS handling

The webhook must handle:

- STOP
- ARRET / ARRÊT
- UNSUBSCRIBE
- OUI
- YES
- 1
- unknown replies

### STOP handling

If STOP-like reply:

- mark consent `opted_out`
- set unsubscribed_at
- audit log
- send optional provider-compliant confirmation if appropriate
- never send future offers

### Positive reply handling

If reply is OUI / YES / 1:

- identify organization/customer/opening safely
- match active offer by phone and most recent active opening/offer
- record response_text
- record responded_at
- compute response order/rank by timestamp
- set offer status to responded
- set opening status to awaiting_validation
- create dashboard notification or visible status

If multiple openings are active for same phone, handle safely:
- prefer direct metadata if provider supports it
- otherwise choose most recent non-expired offer and document limitation

### Unknown replies

Record inbound SMS and show in dashboard. Do not confirm booking.

## Manual merchant validation

On opening detail page, show:

- opening details
- all contacted customers
- respondents ordered by response time
- response text
- customer info
- consent status
- buttons:
  - validate this customer
  - reject
  - mark unavailable/cancel

When merchant validates a respondent:

- transactionally set opening to `filled`
- create or update recovered booking
- mark selected offer `selected`
- mark other responded/pending offers `rejected` or `expired`
- send confirmation SMS to selected customer
- send unavailable SMS to other respondents
- create audit log
- calculate recovered value and commission estimate

Must be atomic enough to prevent double validation.

## Commission estimate

Use configurable placeholder values:

- monthly price: 34.99 CAD, not needed in transaction
- commission percent default configurable, e.g. `DEFAULT_COMMISSION_PERCENT`
- cap can be configured later

Do not hardcode final business logic in a way that is hard to change.

## Security requirements

- Verify SMS provider webhook signature if possible.
- Do not expose provider secrets.
- Do not trust inbound payload blindly.
- Do not validate customer from client-only logic.
- Merchant validation must check organization membership.
- Use database transaction/RPC if needed to avoid double validation.
- Respect RLS or use controlled server-side service role only when necessary.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run build
```

Add tests for:

- SMS template rendering
- STOP handling
- positive reply parsing
- eligibility filtering
- double validation prevention if practical
- commission calculation

Manually test in simulator mode:

1. Create customer opted in.
2. Create waitlist entry.
3. Create opening.
4. Send simulated SMS.
5. Simulate OUI reply.
6. Verify response order.
7. Validate manually.
8. Verify selected confirmation.
9. Verify other respondents are not confirmed.
10. Verify opted out customers never receive SMS.

## Final Codex response must include

- SMS provider abstraction
- simulator status
- real provider readiness
- opening flow status
- inbound webhook status
- manual validation status
- security concerns
- validation results

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
