# 04 — Phase 3: Customer Import, Consent, and QR Waitlist


# Project Context — 2e Chance RDV

You are working on **2e Chance RDV**, an independent SaaS project completely separate from Vistaire.

## Product idea

2e Chance RDV is a bilingual SMS-first cancellation recovery platform for appointment-based local businesses.

The product helps businesses fill last-minute appointment cancellations by sending SMS offers to customers who opted into a waitlist. The business keeps its existing appointment system. 2e Chance RDV is not trying to replace Square, Fresha, Booksy, GOrendezvous, Google Calendar, Instagram DMs, phone booking, or paper agendas.

The core positioning is:

> Fill last-minute cancellations by SMS without changing your current appointment system.

## Initial target sectors

The initial target sectors are:

- beauty / esthétique
- barbers
- salons

The product should remain generic enough to later support massage, detailing, clinics, and other appointment-based services.

## Market

The product is not limited to Laval or Montréal. It should be designed for broader use, starting in Canada/Quebec, but not hardcoded to a city.

## Language

The app must support both French and English.

Internal code, database fields, functions, variables, and technical identifiers must be written in English.

User-facing copy must be designed for bilingual support.

## Business model

Starting model:

- 34.99 CAD/month base subscription
- plus a percentage commission on recovered bookings
- commission should only apply when a booking is manually validated by the merchant as recovered/accepted
- percentage and cap should be configurable later

## Key product rules

1. Customers do not need an app.
2. Customers interact by SMS.
3. Businesses use a web dashboard.
4. Businesses keep their existing booking system.
5. The product provides import, waitlist, SMS offers, response tracking, manual validation, and recovered revenue reporting.
6. Last-minute discounts/offers are optional marketing tools, not mandatory.
7. The merchant manually validates the booking. The first customer to reply is not automatically confirmed.
8. The dashboard must show respondents ordered from first response to last response.
9. The winning customer receives confirmation only after the merchant validates them.
10. Customers can unsubscribe by STOP.
11. The system must never send cancellation-recovery SMS to customers who are opted out.
12. Imported customers without clear SMS consent must not be treated as opted in automatically.

## Recommended technical stack

Use the simplest robust SaaS stack:

- Next.js App Router
- TypeScript
- Tailwind CSS
- shadcn/ui or clean reusable UI components
- Supabase Auth
- Supabase Postgres
- Supabase Row Level Security
- Vercel deployment
- Plivo or another low-cost SMS provider, abstracted behind an internal SMS provider interface
- SMS simulator for development/testing
- Stripe later for billing
- Resend later for emails if needed

## Design direction

Professional, simple, clean, mobile-first.

The UI should feel trustworthy and easy for small businesses. Avoid overly flashy, neon, full-dark, sci-fi, or complicated enterprise UI. Use:

- soft off-white or light neutral backgrounds
- charcoal text
- clean cards
- rounded corners
- clear CTAs
- strong spacing
- dashboard-first usability
- mobile-first flows for merchants
- clear status badges and simple tables/lists

## Core entities

At minimum, the system will need:

- organizations
- organization_members / profiles
- services
- customers
- sms_consents
- waitlist_entries
- import_batches
- openings
- opening_offers
- sms_messages
- booking_requests or recovered_bookings
- audit_logs
- settings

## Core flow

1. Merchant imports customers via CSV/Excel or customers join via QR code waitlist page.
2. Customers have SMS consent status: opted_in, needs_consent, opted_out.
3. Merchant creates a last-minute opening.
4. Merchant optionally adds a last-minute offer/discount.
5. System sends SMS only to eligible opted-in waitlist customers.
6. Customers reply OUI / YES / 1.
7. The system records replies in chronological order.
8. Dashboard notifies merchant and shows respondent list.
9. Merchant manually validates one customer.
10. Validated customer receives confirmation SMS.
11. Other respondents receive a polite unavailable message.
12. Dashboard records recovered revenue, discount, and platform commission estimate.

## Non-negotiable quality rules

- Do not invent APIs, dependencies, tables, routes, or environment variables without checking the codebase and documenting the decision.
- Do not hardcode secrets.
- Do not store credentials in client-side code.
- Do not bypass consent rules.
- Do not send SMS to opted-out customers.
- Do not assume imported customers are opted in.
- Do not create unsafe multi-tenant data access.
- Use Row Level Security where appropriate.
- Keep code readable, simple, maintainable, and production-minded.
- Validate with lint, typecheck, build, tests, and manual QA steps when available.
- Return a clear summary of modified files, what was verified, what was not verified, and remaining risks.



## Mission

Implement the customer acquisition foundation:

1. CSV/Excel import for merchants
2. customer database management
3. consent tracking
4. QR-code waitlist page
5. public customer signup flow

This phase must be safe, privacy-aware, and sellable.

## Core rules

- Imported customers are not automatically opted in unless a valid consent status is provided and confirmed.
- Customers with `opted_out` must never be contacted.
- Customers with `needs_consent` must not receive cancellation-recovery SMS.
- Every consent change must be auditable.
- Public waitlist page must not expose private merchant/customer data.

## Required features

### 1. Customers page

Create:

```text
/dashboard/customers
```

Features:

- list customers for current organization
- search/filter by name or phone
- show consent status
- show waitlist status
- add customer manually
- edit basic customer info
- avoid exposing data from other organizations

### 2. Manual customer add

Fields:

- full name
- phone
- email optional
- preferred language
- service interest optional
- notes optional
- consent status:
  - opted_in
  - needs_consent
  - opted_out

If staff marks a customer as opted in, record:

- consent source = `staff_added`
- consent timestamp
- consent text used
- actor user id in audit log

### 3. CSV/Excel import

Create:

```text
/dashboard/import
```

Support at least CSV in V1. Excel can be added if simple and safe. If Excel requires dependency, evaluate carefully.

Import flow:

1. Upload file
2. Parse safely
3. Show preview
4. Let merchant map columns:
   - name
   - phone
   - email
   - service
   - notes
   - consent status
5. Normalize phone numbers to E.164 where possible
6. Validate rows
7. Detect duplicates within file and existing organization
8. Let merchant choose:
   - skip duplicates
   - update existing safe fields
9. Import
10. Create `import_batches`
11. Create audit log
12. Show import result summary

Do not store uploaded files permanently unless required. Prefer processing and discarding.

### 4. Consent handling

Implement clear statuses:

- opted_in
- needs_consent
- opted_out

UI must make it obvious that `needs_consent` cannot receive SMS offers.

### 5. QR-code waitlist

Create public page:

```text
/b/[slug]/waitlist
```

The merchant can share this link or QR code.

Customer fields:

- full name
- phone
- preferred language
- service interest
- availability simple fields
- discount interest checkbox
- consent checkbox required

Consent checkbox copy must clearly state that customer agrees to receive SMS about last-minute openings from that merchant and can reply STOP to unsubscribe.

### 6. Dashboard waitlist page

Create:

```text
/dashboard/waitlist
```

Features:

- list waitlist entries
- filter by service/status
- show consent eligibility
- pause/remove entries
- show source: QR, manual, import, etc.

### 7. QR code generation

Add a simple QR code for the merchant waitlist URL.

Options:

- generate client-side QR with a small dependency if justified
- or generate via a simple internal component/library

Do not use external tracking QR services.

## Security requirements

- Validate input on server.
- Sanitize uploaded CSV content.
- Protect dashboard routes.
- Do not allow public route to query all organization data.
- Do not allow cross-organization import.
- Do not trust client-side organization IDs.
- Keep audit logs for import and consent changes.

## UX requirements

- Simple and mobile-friendly.
- Clear statuses.
- Import summary must be understandable:
  - total rows
  - imported
  - skipped duplicates
  - invalid phones
  - needs consent
  - opted in
  - opted out

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run build
```

Add tests for:

- phone normalization
- duplicate detection
- consent status mapping
- CSV parsing edge cases

If test framework does not exist, add minimal practical tests.

## Final Codex response must include

- import features completed
- waitlist features completed
- consent protections
- validation results
- test coverage
- known limitations

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
