# 03 — Phase 2: Database, Auth, Organizations, and Row Level Security


# Project Context — 2e Chance RDV

You are working on **2e Chance RDV**, an independent SaaS project completely separate from Vistaire.

## Product idea

2e Chance RDV is a bilingual SMS-first cancellation recovery platform for appointment-based local businesses.

The product helps businesses fill last-minute appointment cancellations by sending SMS offers to customers who opted into a waitlist. The business keeps its existing appointment system. 2e Chance RDV is not trying to replace Square, Fresha, Booksy, GOrendezvous, Google Calendar, Instagram DMs, phone booking, or paper agendas.

The core positioning is:

> Fill last-minute cancellations by SMS without changing your current appointment system.

## Initial target sectors

The initial target sectors are:

- beauty / esthétique
- barbers
- salons

The product should remain generic enough to later support massage, detailing, clinics, and other appointment-based services.

## Market

The product is not limited to Laval or Montréal. It should be designed for broader use, starting in Canada/Quebec, but not hardcoded to a city.

## Language

The app must support both French and English.

Internal code, database fields, functions, variables, and technical identifiers must be written in English.

User-facing copy must be designed for bilingual support.

## Business model

Starting model:

- 34.99 CAD/month base subscription
- plus a percentage commission on recovered bookings
- commission should only apply when a booking is manually validated by the merchant as recovered/accepted
- percentage and cap should be configurable later

## Key product rules

1. Customers do not need an app.
2. Customers interact by SMS.
3. Businesses use a web dashboard.
4. Businesses keep their existing booking system.
5. The product provides import, waitlist, SMS offers, response tracking, manual validation, and recovered revenue reporting.
6. Last-minute discounts/offers are optional marketing tools, not mandatory.
7. The merchant manually validates the booking. The first customer to reply is not automatically confirmed.
8. The dashboard must show respondents ordered from first response to last response.
9. The winning customer receives confirmation only after the merchant validates them.
10. Customers can unsubscribe by STOP.
11. The system must never send cancellation-recovery SMS to customers who are opted out.
12. Imported customers without clear SMS consent must not be treated as opted in automatically.

## Recommended technical stack

Use the simplest robust SaaS stack:

- Next.js App Router
- TypeScript
- Tailwind CSS
- shadcn/ui or clean reusable UI components
- Supabase Auth
- Supabase Postgres
- Supabase Row Level Security
- Vercel deployment
- Plivo or another low-cost SMS provider, abstracted behind an internal SMS provider interface
- SMS simulator for development/testing
- Stripe later for billing
- Resend later for emails if needed

## Design direction

Professional, simple, clean, mobile-first.

The UI should feel trustworthy and easy for small businesses. Avoid overly flashy, neon, full-dark, sci-fi, or complicated enterprise UI. Use:

- soft off-white or light neutral backgrounds
- charcoal text
- clean cards
- rounded corners
- clear CTAs
- strong spacing
- dashboard-first usability
- mobile-first flows for merchants
- clear status badges and simple tables/lists

## Core entities

At minimum, the system will need:

- organizations
- organization_members / profiles
- services
- customers
- sms_consents
- waitlist_entries
- import_batches
- openings
- opening_offers
- sms_messages
- booking_requests or recovered_bookings
- audit_logs
- settings

## Core flow

1. Merchant imports customers via CSV/Excel or customers join via QR code waitlist page.
2. Customers have SMS consent status: opted_in, needs_consent, opted_out.
3. Merchant creates a last-minute opening.
4. Merchant optionally adds a last-minute offer/discount.
5. System sends SMS only to eligible opted-in waitlist customers.
6. Customers reply OUI / YES / 1.
7. The system records replies in chronological order.
8. Dashboard notifies merchant and shows respondent list.
9. Merchant manually validates one customer.
10. Validated customer receives confirmation SMS.
11. Other respondents receive a polite unavailable message.
12. Dashboard records recovered revenue, discount, and platform commission estimate.

## Non-negotiable quality rules

- Do not invent APIs, dependencies, tables, routes, or environment variables without checking the codebase and documenting the decision.
- Do not hardcode secrets.
- Do not store credentials in client-side code.
- Do not bypass consent rules.
- Do not send SMS to opted-out customers.
- Do not assume imported customers are opted in.
- Do not create unsafe multi-tenant data access.
- Use Row Level Security where appropriate.
- Keep code readable, simple, maintainable, and production-minded.
- Validate with lint, typecheck, build, tests, and manual QA steps when available.
- Return a clear summary of modified files, what was verified, what was not verified, and remaining risks.



## Mission

Implement the secure multi-tenant foundation: Supabase Auth, organizations, members, services, customers, consent statuses, waitlist entries, openings, SMS logs, and RLS policies.

This phase is critical. The app must never allow one organization to access another organization's data.

## Scope

Create database schema, types, Supabase clients, auth gates, organization context, and RLS policies.

Do not implement CSV import, SMS sending, or reply handling yet except placeholders if needed.

## Required database design

Create SQL migrations in the existing migrations pattern. If no pattern exists, create a clean Supabase migration folder.

### Required tables

Implement or design these tables:

1. `organizations`
   - id
   - name
   - slug unique
   - email
   - phone
   - timezone
   - default_language
   - created_at
   - updated_at

2. `organization_members`
   - id
   - organization_id
   - user_id
   - role: owner, manager, staff
   - created_at

3. `services`
   - id
   - organization_id
   - name
   - description
   - duration_minutes
   - normal_price_cents
   - currency
   - active
   - created_at
   - updated_at

4. `customers`
   - id
   - organization_id
   - full_name
   - phone_e164
   - email
   - preferred_language
   - notes
   - created_at
   - updated_at

5. `sms_consents`
   - id
   - organization_id
   - customer_id
   - phone_e164
   - status: opted_in, needs_consent, opted_out
   - source
   - consent_text
   - consented_at
   - unsubscribed_at
   - created_at
   - updated_at

6. `waitlist_entries`
   - id
   - organization_id
   - customer_id
   - service_id nullable
   - status: active, paused, booked, removed
   - preferred_days
   - preferred_time_windows
   - discount_interest
   - notes
   - created_at
   - updated_at

7. `import_batches`
   - id
   - organization_id
   - file_name
   - total_rows
   - valid_rows
   - invalid_rows
   - duplicate_rows
   - created_by
   - created_at

8. `openings`
   - id
   - organization_id
   - service_id nullable
   - title
   - start_time
   - end_time
   - normal_price_cents
   - discount_type: none, fixed_amount, percentage, custom
   - discount_value
   - offer_label
   - status: draft, broadcasting, awaiting_validation, filled, expired, cancelled
   - expires_at
   - created_by
   - created_at
   - updated_at

9. `opening_offers`
   - id
   - organization_id
   - opening_id
   - customer_id
   - status: pending, sent, responded, selected, rejected, expired, invalid
   - sent_at
   - responded_at
   - response_text
   - response_rank
   - created_at
   - updated_at

10. `booking_requests` or `recovered_bookings`
   - id
   - organization_id
   - opening_id
   - selected_offer_id
   - customer_id
   - status: pending_merchant_validation, confirmed, cancelled, completed, no_show
   - recovered_value_cents
   - platform_commission_cents
   - confirmed_at
   - created_at
   - updated_at

11. `sms_messages`
   - id
   - organization_id
   - customer_id nullable
   - opening_id nullable
   - direction: outbound, inbound
   - provider
   - provider_message_id
   - from_number
   - to_number
   - body
   - status
   - error_message
   - created_at

12. `audit_logs`
   - id
   - organization_id
   - actor_user_id nullable
   - action
   - entity_type
   - entity_id
   - metadata jsonb
   - created_at

### Required constraints and indexes

Add indexes for:

- organization scoped lookups
- slug lookups
- phone lookups
- opening status
- waitlist active status
- inbound SMS lookup by phone
- response ordering by `responded_at`

Add unique constraints where needed:

- organization slug unique
- phone unique per organization if appropriate
- one active consent row per customer/phone if possible
- prevent duplicate offers for same opening/customer

## RLS requirements

Enable RLS on all organization-scoped tables.

Policies must ensure:

- organization members can access only their organization
- owner/manager can modify organization settings/services/customers
- staff permissions should be conservative
- public waitlist insertion can only insert safe fields and must not expose private data
- admin/service role operations are server-side only

If implementing public waitlist inserts directly from client is risky, prefer a server route.

## Auth

Implement:

- Supabase Auth client setup
- server client
- middleware or route protection
- dashboard auth guard
- organization context helper
- role helper

Do not build a perfect invitation system yet unless simple.

## Types

Generate or create TypeScript database types if practical.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run build
```

If Supabase local tooling exists, validate migrations. If not, document how migrations should be applied.

## Final Codex response must include

- migrations created
- tables created
- RLS policies created
- auth flow changes
- security assumptions
- validation results
- unresolved risks

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
