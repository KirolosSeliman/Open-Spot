# 01 — Phase 0: Product Foundation, Requirements, and Architecture


# Project Context — 2e Chance RDV

You are working on **2e Chance RDV**, an independent SaaS project completely separate from Vistaire.

## Product idea

2e Chance RDV is a bilingual SMS-first cancellation recovery platform for appointment-based local businesses.

The product helps businesses fill last-minute appointment cancellations by sending SMS offers to customers who opted into a waitlist. The business keeps its existing appointment system. 2e Chance RDV is not trying to replace Square, Fresha, Booksy, GOrendezvous, Google Calendar, Instagram DMs, phone booking, or paper agendas.

The core positioning is:

> Fill last-minute cancellations by SMS without changing your current appointment system.

## Initial target sectors

The initial target sectors are:

- beauty / esthétique
- barbers
- salons

The product should remain generic enough to later support massage, detailing, clinics, and other appointment-based services.

## Market

The product is not limited to Laval or Montréal. It should be designed for broader use, starting in Canada/Quebec, but not hardcoded to a city.

## Language

The app must support both French and English.

Internal code, database fields, functions, variables, and technical identifiers must be written in English.

User-facing copy must be designed for bilingual support.

## Business model

Starting model:

- 34.99 CAD/month base subscription
- plus a percentage commission on recovered bookings
- commission should only apply when a booking is manually validated by the merchant as recovered/accepted
- percentage and cap should be configurable later

## Key product rules

1. Customers do not need an app.
2. Customers interact by SMS.
3. Businesses use a web dashboard.
4. Businesses keep their existing booking system.
5. The product provides import, waitlist, SMS offers, response tracking, manual validation, and recovered revenue reporting.
6. Last-minute discounts/offers are optional marketing tools, not mandatory.
7. The merchant manually validates the booking. The first customer to reply is not automatically confirmed.
8. The dashboard must show respondents ordered from first response to last response.
9. The winning customer receives confirmation only after the merchant validates them.
10. Customers can unsubscribe by STOP.
11. The system must never send cancellation-recovery SMS to customers who are opted out.
12. Imported customers without clear SMS consent must not be treated as opted in automatically.

## Recommended technical stack

Use the simplest robust SaaS stack:

- Next.js App Router
- TypeScript
- Tailwind CSS
- shadcn/ui or clean reusable UI components
- Supabase Auth
- Supabase Postgres
- Supabase Row Level Security
- Vercel deployment
- Plivo or another low-cost SMS provider, abstracted behind an internal SMS provider interface
- SMS simulator for development/testing
- Stripe later for billing
- Resend later for emails if needed

## Design direction

Professional, simple, clean, mobile-first.

The UI should feel trustworthy and easy for small businesses. Avoid overly flashy, neon, full-dark, sci-fi, or complicated enterprise UI. Use:

- soft off-white or light neutral backgrounds
- charcoal text
- clean cards
- rounded corners
- clear CTAs
- strong spacing
- dashboard-first usability
- mobile-first flows for merchants
- clear status badges and simple tables/lists

## Core entities

At minimum, the system will need:

- organizations
- organization_members / profiles
- services
- customers
- sms_consents
- waitlist_entries
- import_batches
- openings
- opening_offers
- sms_messages
- booking_requests or recovered_bookings
- audit_logs
- settings

## Core flow

1. Merchant imports customers via CSV/Excel or customers join via QR code waitlist page.
2. Customers have SMS consent status: opted_in, needs_consent, opted_out.
3. Merchant creates a last-minute opening.
4. Merchant optionally adds a last-minute offer/discount.
5. System sends SMS only to eligible opted-in waitlist customers.
6. Customers reply OUI / YES / 1.
7. The system records replies in chronological order.
8. Dashboard notifies merchant and shows respondent list.
9. Merchant manually validates one customer.
10. Validated customer receives confirmation SMS.
11. Other respondents receive a polite unavailable message.
12. Dashboard records recovered revenue, discount, and platform commission estimate.

## Non-negotiable quality rules

- Do not invent APIs, dependencies, tables, routes, or environment variables without checking the codebase and documenting the decision.
- Do not hardcode secrets.
- Do not store credentials in client-side code.
- Do not bypass consent rules.
- Do not send SMS to opted-out customers.
- Do not assume imported customers are opted in.
- Do not create unsafe multi-tenant data access.
- Use Row Level Security where appropriate.
- Keep code readable, simple, maintainable, and production-minded.
- Validate with lint, typecheck, build, tests, and manual QA steps when available.
- Return a clear summary of modified files, what was verified, what was not verified, and remaining risks.



## Mission

Create the project foundation documentation before implementing major code. Your goal is to define the SaaS product clearly enough that every later implementation phase is consistent, safe, and focused.

You are not building the full app in this phase unless the repo is empty and documentation scaffolding is needed. This phase is about product architecture, scope control, technical architecture, and implementation plan.

## What to produce

Create or update documentation files such as:

- `README.md`
- `docs/product-requirements.md`
- `docs/architecture.md`
- `docs/roadmap.md`
- `docs/security-and-privacy.md`
- `docs/data-model.md`
- `docs/sms-compliance-notes.md`
- `docs/design-direction.md`

Use existing documentation structure if present.

## Required content

### 1. Product definition

Document clearly:

- product name: 2e Chance RDV
- independent SaaS, unrelated to Vistaire
- target sectors: beauty, barbers, salons
- bilingual support: French and English
- no mobile app for customers in MVP
- SMS-first customer experience
- merchant web dashboard
- QR-code waitlist
- CSV/Excel import
- manual validation flow
- optional last-minute offer/discount
- recovered revenue reporting

### 2. MVP boundaries

Define what is in MVP:

- merchant auth
- organization workspace
- services
- customers
- import CSV/Excel
- customer consent statuses
- QR-code waitlist page
- opening creation
- optional discount
- real SMS integration behind provider abstraction
- SMS simulator for development
- inbound reply handling
- response ranking by timestamp
- manual merchant validation
- confirmation and unavailable messages
- STOP unsubscribe
- simple admin view
- recovered revenue report

Define what is not in MVP:

- mobile apps
- replacing merchant booking system
- automatic integration with Square/Fresha/Booksy
- complex staff scheduling
- full CRM
- AI features
- advanced billing automation, unless later phase
- automatic booking confirmation without merchant validation

### 3. Architecture

Document the chosen stack:

- Next.js App Router
- TypeScript
- Tailwind CSS
- shadcn/ui or clean custom components
- Supabase Auth
- Supabase Postgres
- Supabase RLS
- Vercel
- SMS provider abstraction with simulator and Plivo/Twilio/Telnyx support
- Stripe later

### 4. Data model

Propose tables and relationships:

- organizations
- profiles / organization_members
- services
- customers
- sms_consents
- waitlist_entries
- import_batches
- openings
- opening_offers
- sms_messages
- recovered_bookings or booking_requests
- audit_logs
- app_settings / organization_settings

For each table, document:

- purpose
- key fields
- organization scoping
- privacy/security concerns
- indexes needed
- RLS expectations

### 5. Consent and privacy

Document:

- imported customers can be `needs_consent`
- opted-out customers must never receive promotional or cancellation-recovery SMS
- consent source must be stored
- consent timestamp must be stored
- STOP must be respected
- minimum data principle
- audit logging for sensitive actions

### 6. Flow diagrams in text

Include text flow diagrams for:

- customer waitlist signup
- CSV import
- opening creation
- SMS offer sending
- inbound reply handling
- manual merchant validation
- opt-out handling

### 7. Development phases

Write a phased roadmap matching these prompt files.

## Technical requirements

- Keep documentation concrete.
- Avoid generic SaaS fluff.
- Do not invent implementation details that conflict with existing code.
- If the repo already has a different stack, report the mismatch before changing direction.
- If the repo is empty, document the proposed setup clearly.

## Validation

Run available checks if documentation tooling exists. Otherwise verify manually that all docs are consistent and reference the same product decisions.

## Final Codex response must include

- docs created/updated
- product decisions captured
- architecture decisions captured
- open questions
- risks
- next phase recommendation

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
