# 06 — Phase 5: Merchant Dashboard, Reports, Admin, and Operational Views


# Project Context — 2e Chance RDV

You are working on **2e Chance RDV**, an independent SaaS project completely separate from Vistaire.

## Product idea

2e Chance RDV is a bilingual SMS-first cancellation recovery platform for appointment-based local businesses.

The product helps businesses fill last-minute appointment cancellations by sending SMS offers to customers who opted into a waitlist. The business keeps its existing appointment system. 2e Chance RDV is not trying to replace Square, Fresha, Booksy, GOrendezvous, Google Calendar, Instagram DMs, phone booking, or paper agendas.

The core positioning is:

> Fill last-minute cancellations by SMS without changing your current appointment system.

## Initial target sectors

The initial target sectors are:

- beauty / esthétique
- barbers
- salons

The product should remain generic enough to later support massage, detailing, clinics, and other appointment-based services.

## Market

The product is not limited to Laval or Montréal. It should be designed for broader use, starting in Canada/Quebec, but not hardcoded to a city.

## Language

The app must support both French and English.

Internal code, database fields, functions, variables, and technical identifiers must be written in English.

User-facing copy must be designed for bilingual support.

## Business model

Starting model:

- 34.99 CAD/month base subscription
- plus a percentage commission on recovered bookings
- commission should only apply when a booking is manually validated by the merchant as recovered/accepted
- percentage and cap should be configurable later

## Key product rules

1. Customers do not need an app.
2. Customers interact by SMS.
3. Businesses use a web dashboard.
4. Businesses keep their existing booking system.
5. The product provides import, waitlist, SMS offers, response tracking, manual validation, and recovered revenue reporting.
6. Last-minute discounts/offers are optional marketing tools, not mandatory.
7. The merchant manually validates the booking. The first customer to reply is not automatically confirmed.
8. The dashboard must show respondents ordered from first response to last response.
9. The winning customer receives confirmation only after the merchant validates them.
10. Customers can unsubscribe by STOP.
11. The system must never send cancellation-recovery SMS to customers who are opted out.
12. Imported customers without clear SMS consent must not be treated as opted in automatically.

## Recommended technical stack

Use the simplest robust SaaS stack:

- Next.js App Router
- TypeScript
- Tailwind CSS
- shadcn/ui or clean reusable UI components
- Supabase Auth
- Supabase Postgres
- Supabase Row Level Security
- Vercel deployment
- Plivo or another low-cost SMS provider, abstracted behind an internal SMS provider interface
- SMS simulator for development/testing
- Stripe later for billing
- Resend later for emails if needed

## Design direction

Professional, simple, clean, mobile-first.

The UI should feel trustworthy and easy for small businesses. Avoid overly flashy, neon, full-dark, sci-fi, or complicated enterprise UI. Use:

- soft off-white or light neutral backgrounds
- charcoal text
- clean cards
- rounded corners
- clear CTAs
- strong spacing
- dashboard-first usability
- mobile-first flows for merchants
- clear status badges and simple tables/lists

## Core entities

At minimum, the system will need:

- organizations
- organization_members / profiles
- services
- customers
- sms_consents
- waitlist_entries
- import_batches
- openings
- opening_offers
- sms_messages
- booking_requests or recovered_bookings
- audit_logs
- settings

## Core flow

1. Merchant imports customers via CSV/Excel or customers join via QR code waitlist page.
2. Customers have SMS consent status: opted_in, needs_consent, opted_out.
3. Merchant creates a last-minute opening.
4. Merchant optionally adds a last-minute offer/discount.
5. System sends SMS only to eligible opted-in waitlist customers.
6. Customers reply OUI / YES / 1.
7. The system records replies in chronological order.
8. Dashboard notifies merchant and shows respondent list.
9. Merchant manually validates one customer.
10. Validated customer receives confirmation SMS.
11. Other respondents receive a polite unavailable message.
12. Dashboard records recovered revenue, discount, and platform commission estimate.

## Non-negotiable quality rules

- Do not invent APIs, dependencies, tables, routes, or environment variables without checking the codebase and documenting the decision.
- Do not hardcode secrets.
- Do not store credentials in client-side code.
- Do not bypass consent rules.
- Do not send SMS to opted-out customers.
- Do not assume imported customers are opted in.
- Do not create unsafe multi-tenant data access.
- Use Row Level Security where appropriate.
- Keep code readable, simple, maintainable, and production-minded.
- Validate with lint, typecheck, build, tests, and manual QA steps when available.
- Return a clear summary of modified files, what was verified, what was not verified, and remaining risks.



## Mission

Turn the product into a sellable merchant dashboard.

This phase focuses on usability, reporting, operational visibility, and admin control. The merchant should be able to understand value quickly: openings sent, responses received, bookings recovered, and revenue recovered.

## Required merchant dashboard pages

Complete and polish:

```text
/dashboard
/dashboard/openings
/dashboard/openings/[id]
/dashboard/waitlist
/dashboard/customers
/dashboard/import
/dashboard/services
/dashboard/sms
/dashboard/reports
/dashboard/settings
```

## Dashboard homepage

Show key cards:

- recovered revenue this month
- openings created
- openings filled
- response rate
- customers on waitlist
- SMS sent
- opt-outs
- estimated commission owed

Show recent activity:

- recent openings
- recent responses
- recent validated bookings
- failed SMS messages

## Openings page

Features:

- list all openings
- status filters
- create new opening
- quick action to view respondents
- clear badges:
  - draft
  - broadcasting
  - awaiting validation
  - filled
  - expired
  - cancelled

## Opening detail page

Must show:

- opening details
- offer/discount
- SMS send status
- list of offers sent
- response list ordered by first response to last
- manual validation action
- audit activity for this opening

## Reports page

Show simple reports:

- recovered revenue
- normal price total
- discount total
- net recovered estimate
- commission estimate
- filled openings
- response rate
- average time to first response
- customer opt-in count
- customer opt-out count

Reports should be filterable by:

- date range
- service
- status

## SMS page

Show:

- outbound messages
- inbound messages
- status
- provider
- errors
- related customer/opening
- search by phone/customer

Do not expose provider secrets.

## Services page

Allow merchant to:

- create service
- edit service
- deactivate service
- set normal price and duration
- select active/inactive

## Settings page

Allow merchant to configure:

- business name
- phone
- email
- timezone
- default language
- waitlist page link
- SMS sending window
- default offer settings
- optional branding basics

## Admin dashboard for platform owner

Create/complete:

```text
/admin
/admin/organizations
/admin/sms
/admin/reports
```

Admin should show:

- organizations
- active merchants
- SMS volume
- failed SMS
- recovered bookings
- platform commission estimate
- opt-out totals
- error logs

Keep admin secure. Only platform admin users should access it.

If platform admin role does not exist, implement a safe minimal approach using an environment variable or admin table, but document it.

## UX requirements

- Professional and simple.
- Mobile-first, especially for merchant validation.
- Clear empty states.
- Clear status badges.
- No clutter.
- No confusing scheduling-system replacement language.
- Always reinforce that the merchant keeps their existing appointment system.

## Bilingual readiness

At minimum, structure user-facing text so it can be translated. If i18n is already implemented, translate key UI strings.

## Security requirements

- Dashboard data must be organization-scoped.
- Admin must not be accessible to normal merchants.
- Reports must not leak cross-organization data.
- SMS logs must be protected.
- Settings changes must be audited.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run build
```

Manual QA:

- login as merchant
- view only own data
- create service
- create customer
- create opening
- send simulated SMS
- see response
- validate booking
- verify dashboard metrics
- verify admin access is protected

## Final Codex response must include

- dashboard pages completed
- reports completed
- admin completed
- UX improvements
- validation results
- security checks
- remaining improvements

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
