# 07 — Phase 6: Public Landing, Pricing, Onboarding, Legal Pages, and Bilingual Copy


# Project Context — 2e Chance RDV

You are working on **2e Chance RDV**, an independent SaaS project completely separate from Vistaire.

## Product idea

2e Chance RDV is a bilingual SMS-first cancellation recovery platform for appointment-based local businesses.

The product helps businesses fill last-minute appointment cancellations by sending SMS offers to customers who opted into a waitlist. The business keeps its existing appointment system. 2e Chance RDV is not trying to replace Square, Fresha, Booksy, GOrendezvous, Google Calendar, Instagram DMs, phone booking, or paper agendas.

The core positioning is:

> Fill last-minute cancellations by SMS without changing your current appointment system.

## Initial target sectors

The initial target sectors are:

- beauty / esthétique
- barbers
- salons

The product should remain generic enough to later support massage, detailing, clinics, and other appointment-based services.

## Market

The product is not limited to Laval or Montréal. It should be designed for broader use, starting in Canada/Quebec, but not hardcoded to a city.

## Language

The app must support both French and English.

Internal code, database fields, functions, variables, and technical identifiers must be written in English.

User-facing copy must be designed for bilingual support.

## Business model

Starting model:

- 34.99 CAD/month base subscription
- plus a percentage commission on recovered bookings
- commission should only apply when a booking is manually validated by the merchant as recovered/accepted
- percentage and cap should be configurable later

## Key product rules

1. Customers do not need an app.
2. Customers interact by SMS.
3. Businesses use a web dashboard.
4. Businesses keep their existing booking system.
5. The product provides import, waitlist, SMS offers, response tracking, manual validation, and recovered revenue reporting.
6. Last-minute discounts/offers are optional marketing tools, not mandatory.
7. The merchant manually validates the booking. The first customer to reply is not automatically confirmed.
8. The dashboard must show respondents ordered from first response to last response.
9. The winning customer receives confirmation only after the merchant validates them.
10. Customers can unsubscribe by STOP.
11. The system must never send cancellation-recovery SMS to customers who are opted out.
12. Imported customers without clear SMS consent must not be treated as opted in automatically.

## Recommended technical stack

Use the simplest robust SaaS stack:

- Next.js App Router
- TypeScript
- Tailwind CSS
- shadcn/ui or clean reusable UI components
- Supabase Auth
- Supabase Postgres
- Supabase Row Level Security
- Vercel deployment
- Plivo or another low-cost SMS provider, abstracted behind an internal SMS provider interface
- SMS simulator for development/testing
- Stripe later for billing
- Resend later for emails if needed

## Design direction

Professional, simple, clean, mobile-first.

The UI should feel trustworthy and easy for small businesses. Avoid overly flashy, neon, full-dark, sci-fi, or complicated enterprise UI. Use:

- soft off-white or light neutral backgrounds
- charcoal text
- clean cards
- rounded corners
- clear CTAs
- strong spacing
- dashboard-first usability
- mobile-first flows for merchants
- clear status badges and simple tables/lists

## Core entities

At minimum, the system will need:

- organizations
- organization_members / profiles
- services
- customers
- sms_consents
- waitlist_entries
- import_batches
- openings
- opening_offers
- sms_messages
- booking_requests or recovered_bookings
- audit_logs
- settings

## Core flow

1. Merchant imports customers via CSV/Excel or customers join via QR code waitlist page.
2. Customers have SMS consent status: opted_in, needs_consent, opted_out.
3. Merchant creates a last-minute opening.
4. Merchant optionally adds a last-minute offer/discount.
5. System sends SMS only to eligible opted-in waitlist customers.
6. Customers reply OUI / YES / 1.
7. The system records replies in chronological order.
8. Dashboard notifies merchant and shows respondent list.
9. Merchant manually validates one customer.
10. Validated customer receives confirmation SMS.
11. Other respondents receive a polite unavailable message.
12. Dashboard records recovered revenue, discount, and platform commission estimate.

## Non-negotiable quality rules

- Do not invent APIs, dependencies, tables, routes, or environment variables without checking the codebase and documenting the decision.
- Do not hardcode secrets.
- Do not store credentials in client-side code.
- Do not bypass consent rules.
- Do not send SMS to opted-out customers.
- Do not assume imported customers are opted in.
- Do not create unsafe multi-tenant data access.
- Use Row Level Security where appropriate.
- Keep code readable, simple, maintainable, and production-minded.
- Validate with lint, typecheck, build, tests, and manual QA steps when available.
- Return a clear summary of modified files, what was verified, what was not verified, and remaining risks.



## Mission

Build the public-facing website and onboarding flow so the product is sellable.

The public site must clearly communicate that 2e Chance RDV helps businesses recover last-minute cancellations by SMS without replacing their current booking system.

## Required public pages

Create or polish:

```text
/
 /pricing
 /contact
 /privacy
 /terms
 /login
 /signup
```

Optional:

```text
/how-it-works
/industries
```

## Landing page message

Primary headline direction:

```text
Fill last-minute cancellations by SMS without changing your current booking system.
```

French version:

```text
Remplissez vos annulations de dernière minute par SMS, sans changer votre système de rendez-vous actuel.
```

Subheadline:

```text
2e Chance RDV helps salons, barbers, and beauty businesses recover lost revenue with a simple SMS waitlist, customer import, QR signup, and manual booking validation.
```

French version:

```text
2e Chance RDV aide les salons, barbiers et commerces beauté à récupérer du revenu perdu grâce à une liste d’attente SMS simple, l’import client, l’inscription par QR code et la validation manuelle.
```

## Core sections

Landing page must include:

1. Hero
2. Problem
3. How it works
4. Why not a full booking system
5. SMS waitlist
6. Optional last-minute offer
7. Manual merchant validation
8. Recovered revenue dashboard
9. Pricing preview
10. FAQ
11. CTA

## Key positioning rules

Do not position as:

- full appointment system
- replacement for Fresha/Booksy/Square
- guaranteed revenue system
- automatic booking confirmation
- medical compliance tool

Position as:

- cancellation recovery layer
- SMS-first waitlist
- lightweight add-on
- simple tool for small appointment-based businesses
- revenue recovery assistant

## Pricing page

Show:

- 34.99 CAD/month
- plus percentage commission on recovered bookings
- mention SMS usage may be included up to fair-use limit or billed depending on final setup
- keep terms configurable

Do not hardcode unrealistic unlimited SMS promises.

## Contact page

Simple lead capture:

- business name
- name
- email
- phone
- business type
- current booking system
- estimated cancellations per week
- message

## Onboarding flow

Initial merchant onboarding should capture:

- organization name
- business type
- preferred language
- timezone
- services setup
- waitlist link/QR code
- import customers CTA

## Legal pages

Create practical placeholders:

- Privacy Policy
- Terms of Service

Important: do not pretend these are lawyer-reviewed. Include TODO note internally if appropriate.

Legal pages must mention:

- SMS consent
- STOP unsubscribe
- merchant responsibility for imported contact consent
- data deletion requests
- service limitations
- no guarantee of filling every cancellation

## Bilingual copy

Implement either:

- French and English pages
- or a bilingual-ready copy structure

The app should be ready for bilingual support without duplicating messy code.

## Design requirements

Professional, simple, clean:

- light neutral background
- clear typography
- strong CTA buttons
- cards
- mobile-first
- no dark/neon gimmicks
- trustworthy local-business SaaS tone

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run build
```

Manually QA:

- mobile landing
- pricing clarity
- contact form behavior
- signup/onboarding flow
- no misleading claims
- bilingual strings not hardcoded chaotically

## Final Codex response must include

- pages created
- copy decisions
- onboarding flow
- legal disclaimers added
- validation results
- remaining legal/business TODOs

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
