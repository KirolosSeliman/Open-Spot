# Roadmap — 2e Chance RDV Codex Phases

## Goal

Build a sellable bilingual SMS-first SaaS that helps salons, barbers, and beauty businesses recover last-minute cancellations without replacing their current appointment system.

## Phase overview

| Phase | Name | Main goal | Output |
|---|---|---|---|
| 0 | Product Foundation | Lock scope, architecture, data model, risks | Docs and roadmap |
| 1 | Base App | Create clean Next.js/Supabase-ready SaaS skeleton | App structure, pages, env setup |
| 2 | Database/Auth/RLS | Build secure multi-tenant foundation | Supabase schema, RLS, auth |
| 3 | Import/Consent/Waitlist | Add customers, import, QR waitlist, consent | Import flow and public waitlist |
| 4 | SMS/Openings/Validation | Build core cancellation recovery engine | SMS, replies, manual validation |
| 5 | Dashboard/Admin/Reports | Make it sellable for merchants | Merchant dashboard and admin |
| 6 | Landing/Onboarding/Legal | Make it marketable and bilingual | Public site and onboarding |
| 7 | Billing/Cost Controls | Prepare paid usage | Billing-ready system and SMS controls |
| 8 | QA/Security/Deploy | Prepare beta launch | Audit, fixes, deployment docs |

## How to use these prompts

1. Start with `00_MASTER_CODEX_OPERATING_PROMPT.md`.
2. Give Codex one phase prompt at a time.
3. Do not give all implementation prompts at once.
4. After each phase, review Codex output.
5. Run the app and validate manually where possible.
6. Fix critical issues before moving to the next phase.
7. Keep commits separate by phase.

## Recommended Git workflow

Use one branch per phase if possible:

```bash
git checkout -b phase-0-docs
git checkout -b phase-1-base-app
git checkout -b phase-2-db-auth-rls
git checkout -b phase-3-import-consent-waitlist
git checkout -b phase-4-sms-openings-validation
git checkout -b phase-5-dashboard-reports-admin
git checkout -b phase-6-landing-onboarding-legal
git checkout -b phase-7-billing-cost-controls
git checkout -b phase-8-qa-security-deploy
```

Suggested commit style:

```bash
git commit -m "Complete phase 1 base app setup"
git commit -m "Add database schema and RLS foundation"
git commit -m "Implement customer import and waitlist consent"
```

## Critical product principle

Do not build a full booking platform.

Build a lightweight cancellation recovery layer that works beside the merchant's existing system.

## Critical security principle

Never send SMS to opted-out customers and never allow cross-organization data access.
