# 02 — Phase 1: Project Setup and Base SaaS Application


# Project Context — 2e Chance RDV

You are working on **2e Chance RDV**, an independent SaaS project completely separate from Vistaire.

## Product idea

2e Chance RDV is a bilingual SMS-first cancellation recovery platform for appointment-based local businesses.

The product helps businesses fill last-minute appointment cancellations by sending SMS offers to customers who opted into a waitlist. The business keeps its existing appointment system. 2e Chance RDV is not trying to replace Square, Fresha, Booksy, GOrendezvous, Google Calendar, Instagram DMs, phone booking, or paper agendas.

The core positioning is:

> Fill last-minute cancellations by SMS without changing your current appointment system.

## Initial target sectors

The initial target sectors are:

- beauty / esthétique
- barbers
- salons

The product should remain generic enough to later support massage, detailing, clinics, and other appointment-based services.

## Market

The product is not limited to Laval or Montréal. It should be designed for broader use, starting in Canada/Quebec, but not hardcoded to a city.

## Language

The app must support both French and English.

Internal code, database fields, functions, variables, and technical identifiers must be written in English.

User-facing copy must be designed for bilingual support.

## Business model

Starting model:

- 34.99 CAD/month base subscription
- plus a percentage commission on recovered bookings
- commission should only apply when a booking is manually validated by the merchant as recovered/accepted
- percentage and cap should be configurable later

## Key product rules

1. Customers do not need an app.
2. Customers interact by SMS.
3. Businesses use a web dashboard.
4. Businesses keep their existing booking system.
5. The product provides import, waitlist, SMS offers, response tracking, manual validation, and recovered revenue reporting.
6. Last-minute discounts/offers are optional marketing tools, not mandatory.
7. The merchant manually validates the booking. The first customer to reply is not automatically confirmed.
8. The dashboard must show respondents ordered from first response to last response.
9. The winning customer receives confirmation only after the merchant validates them.
10. Customers can unsubscribe by STOP.
11. The system must never send cancellation-recovery SMS to customers who are opted out.
12. Imported customers without clear SMS consent must not be treated as opted in automatically.

## Recommended technical stack

Use the simplest robust SaaS stack:

- Next.js App Router
- TypeScript
- Tailwind CSS
- shadcn/ui or clean reusable UI components
- Supabase Auth
- Supabase Postgres
- Supabase Row Level Security
- Vercel deployment
- Plivo or another low-cost SMS provider, abstracted behind an internal SMS provider interface
- SMS simulator for development/testing
- Stripe later for billing
- Resend later for emails if needed

## Design direction

Professional, simple, clean, mobile-first.

The UI should feel trustworthy and easy for small businesses. Avoid overly flashy, neon, full-dark, sci-fi, or complicated enterprise UI. Use:

- soft off-white or light neutral backgrounds
- charcoal text
- clean cards
- rounded corners
- clear CTAs
- strong spacing
- dashboard-first usability
- mobile-first flows for merchants
- clear status badges and simple tables/lists

## Core entities

At minimum, the system will need:

- organizations
- organization_members / profiles
- services
- customers
- sms_consents
- waitlist_entries
- import_batches
- openings
- opening_offers
- sms_messages
- booking_requests or recovered_bookings
- audit_logs
- settings

## Core flow

1. Merchant imports customers via CSV/Excel or customers join via QR code waitlist page.
2. Customers have SMS consent status: opted_in, needs_consent, opted_out.
3. Merchant creates a last-minute opening.
4. Merchant optionally adds a last-minute offer/discount.
5. System sends SMS only to eligible opted-in waitlist customers.
6. Customers reply OUI / YES / 1.
7. The system records replies in chronological order.
8. Dashboard notifies merchant and shows respondent list.
9. Merchant manually validates one customer.
10. Validated customer receives confirmation SMS.
11. Other respondents receive a polite unavailable message.
12. Dashboard records recovered revenue, discount, and platform commission estimate.

## Non-negotiable quality rules

- Do not invent APIs, dependencies, tables, routes, or environment variables without checking the codebase and documenting the decision.
- Do not hardcode secrets.
- Do not store credentials in client-side code.
- Do not bypass consent rules.
- Do not send SMS to opted-out customers.
- Do not assume imported customers are opted in.
- Do not create unsafe multi-tenant data access.
- Use Row Level Security where appropriate.
- Keep code readable, simple, maintainable, and production-minded.
- Validate with lint, typecheck, build, tests, and manual QA steps when available.
- Return a clear summary of modified files, what was verified, what was not verified, and remaining risks.



## Mission

Create or normalize the base web application for 2e Chance RDV.

The goal is to establish a clean, production-minded Next.js SaaS foundation that future phases can safely build on.

## Scope

Build the technical skeleton only. Do not implement the full SMS system, billing, or advanced dashboard yet.

## Required stack

Use or preserve:

- Next.js App Router
- TypeScript
- Tailwind CSS
- ESLint
- clean component structure
- environment variable validation pattern
- Supabase client structure
- bilingual-ready route/content structure
- responsive layout
- Vercel-ready project setup

If the repo already exists, inspect it first and adapt instead of blindly recreating.

## Required implementation

### 1. Base app structure

Create/normalize:

```text
src/
  app/
    page.tsx
    pricing/page.tsx
    contact/page.tsx
    privacy/page.tsx
    terms/page.tsx
    dashboard/page.tsx
    admin/page.tsx
    b/[slug]/waitlist/page.tsx
    api/health/route.ts
  components/
    ui/
    layout/
    dashboard/
    marketing/
    forms/
  lib/
    env/
    supabase/
    auth/
    sms/
    i18n/
    utils/
  types/
```

Use the existing structure if already present, but keep it clean.

### 2. Environment variables

Add an `.env.example` with placeholders only, never secrets.

Include only needed keys such as:

```text
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
SMS_PROVIDER=simulator
PLIVO_AUTH_ID=
PLIVO_AUTH_TOKEN=
PLIVO_SOURCE_NUMBER=
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
TWILIO_SOURCE_NUMBER=
APP_BASE_URL=
```

Do not expose service role keys to client code.

### 3. Base UI

Create a simple professional UI:

- public landing placeholder
- pricing placeholder with 34.99 CAD/month + percentage commission concept
- dashboard placeholder
- admin placeholder
- waitlist placeholder
- mobile-first layout
- simple navigation
- no fake overpromising claims

### 4. Bilingual readiness

Do not hardcode a complex i18n system if not needed yet, but organize content so French/English can be added cleanly.

Recommended:

```text
lib/i18n/
  dictionaries.ts
  types.ts
```

or a similar simple structure.

### 5. Health check route

Add:

```text
GET /api/health
```

It should return basic app status without exposing secrets.

### 6. Code quality

- Use TypeScript strict enough for production.
- Keep components simple.
- Avoid unnecessary dependencies.
- Avoid client components unless needed.
- Keep server-only code server-only.

## Do not implement yet

- Real SMS sending
- SMS webhooks
- Supabase schema
- RLS policies
- Stripe
- CSV import logic
- full dashboard logic

## Validation commands

Run available commands, typically:

```bash
npm install
npm run lint
npm run typecheck
npm run build
```

If a command does not exist, add it when appropriate or document why it is missing.

## Final Codex response must include

- created app structure
- installed dependencies
- environment setup
- UI pages created
- validation results
- anything not completed
- exact next phase

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
