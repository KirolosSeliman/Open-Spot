# 09 — Phase 8: QA, Security Audit, Deployment, and Beta Launch Readiness


# Project Context — 2e Chance RDV

You are working on **2e Chance RDV**, an independent SaaS project completely separate from Vistaire.

## Product idea

2e Chance RDV is a bilingual SMS-first cancellation recovery platform for appointment-based local businesses.

The product helps businesses fill last-minute appointment cancellations by sending SMS offers to customers who opted into a waitlist. The business keeps its existing appointment system. 2e Chance RDV is not trying to replace Square, Fresha, Booksy, GOrendezvous, Google Calendar, Instagram DMs, phone booking, or paper agendas.

The core positioning is:

> Fill last-minute cancellations by SMS without changing your current appointment system.

## Initial target sectors

The initial target sectors are:

- beauty / esthétique
- barbers
- salons

The product should remain generic enough to later support massage, detailing, clinics, and other appointment-based services.

## Market

The product is not limited to Laval or Montréal. It should be designed for broader use, starting in Canada/Quebec, but not hardcoded to a city.

## Language

The app must support both French and English.

Internal code, database fields, functions, variables, and technical identifiers must be written in English.

User-facing copy must be designed for bilingual support.

## Business model

Starting model:

- 34.99 CAD/month base subscription
- plus a percentage commission on recovered bookings
- commission should only apply when a booking is manually validated by the merchant as recovered/accepted
- percentage and cap should be configurable later

## Key product rules

1. Customers do not need an app.
2. Customers interact by SMS.
3. Businesses use a web dashboard.
4. Businesses keep their existing booking system.
5. The product provides import, waitlist, SMS offers, response tracking, manual validation, and recovered revenue reporting.
6. Last-minute discounts/offers are optional marketing tools, not mandatory.
7. The merchant manually validates the booking. The first customer to reply is not automatically confirmed.
8. The dashboard must show respondents ordered from first response to last response.
9. The winning customer receives confirmation only after the merchant validates them.
10. Customers can unsubscribe by STOP.
11. The system must never send cancellation-recovery SMS to customers who are opted out.
12. Imported customers without clear SMS consent must not be treated as opted in automatically.

## Recommended technical stack

Use the simplest robust SaaS stack:

- Next.js App Router
- TypeScript
- Tailwind CSS
- shadcn/ui or clean reusable UI components
- Supabase Auth
- Supabase Postgres
- Supabase Row Level Security
- Vercel deployment
- Plivo or another low-cost SMS provider, abstracted behind an internal SMS provider interface
- SMS simulator for development/testing
- Stripe later for billing
- Resend later for emails if needed

## Design direction

Professional, simple, clean, mobile-first.

The UI should feel trustworthy and easy for small businesses. Avoid overly flashy, neon, full-dark, sci-fi, or complicated enterprise UI. Use:

- soft off-white or light neutral backgrounds
- charcoal text
- clean cards
- rounded corners
- clear CTAs
- strong spacing
- dashboard-first usability
- mobile-first flows for merchants
- clear status badges and simple tables/lists

## Core entities

At minimum, the system will need:

- organizations
- organization_members / profiles
- services
- customers
- sms_consents
- waitlist_entries
- import_batches
- openings
- opening_offers
- sms_messages
- booking_requests or recovered_bookings
- audit_logs
- settings

## Core flow

1. Merchant imports customers via CSV/Excel or customers join via QR code waitlist page.
2. Customers have SMS consent status: opted_in, needs_consent, opted_out.
3. Merchant creates a last-minute opening.
4. Merchant optionally adds a last-minute offer/discount.
5. System sends SMS only to eligible opted-in waitlist customers.
6. Customers reply OUI / YES / 1.
7. The system records replies in chronological order.
8. Dashboard notifies merchant and shows respondent list.
9. Merchant manually validates one customer.
10. Validated customer receives confirmation SMS.
11. Other respondents receive a polite unavailable message.
12. Dashboard records recovered revenue, discount, and platform commission estimate.

## Non-negotiable quality rules

- Do not invent APIs, dependencies, tables, routes, or environment variables without checking the codebase and documenting the decision.
- Do not hardcode secrets.
- Do not store credentials in client-side code.
- Do not bypass consent rules.
- Do not send SMS to opted-out customers.
- Do not assume imported customers are opted in.
- Do not create unsafe multi-tenant data access.
- Use Row Level Security where appropriate.
- Keep code readable, simple, maintainable, and production-minded.
- Validate with lint, typecheck, build, tests, and manual QA steps when available.
- Return a clear summary of modified files, what was verified, what was not verified, and remaining risks.



## Mission

Perform a final production-minded audit before beta launch.

Your goal is to find bugs, security risks, privacy issues, broken flows, weak UX, deployment issues, and anything that could make the product unsafe or embarrassing to sell.

Do not add random new features. Stabilize and verify.

## Required audit areas

### 1. Repository audit

Inspect:

- package.json
- environment config
- Next.js config
- Supabase config/migrations
- auth helpers
- SMS helpers
- dashboard routes
- public routes
- API routes
- RLS policies
- middleware
- build/lint/test setup

### 2. Security audit

Check:

- no secrets in repo
- no service role key exposed to client
- RLS enabled on organization-scoped tables
- dashboard route protection
- admin route protection
- API authorization checks
- webhook verification where supported
- cross-organization data leaks
- unsafe file upload/import parsing
- SQL injection risks
- XSS risks in customer notes/SMS bodies
- rate limiting needs
- audit logs for sensitive actions

### 3. Consent/privacy audit

Check:

- opted out customers cannot receive SMS
- needs_consent customers cannot receive offer SMS
- STOP works
- consent source/timestamp stored
- imported customers are not automatically opted in unless explicitly mapped
- public waitlist consent copy is clear
- privacy page exists
- deletion/export path is documented

### 4. Product flow QA

Test end-to-end:

1. Merchant signs up.
2. Merchant creates organization.
3. Merchant creates service.
4. Merchant imports CSV.
5. Merchant sees import summary.
6. Customer joins through waitlist QR page.
7. Customer consent stored.
8. Merchant creates opening.
9. Merchant sends SMS in simulator or configured provider.
10. Customer replies OUI / YES / 1.
11. Dashboard shows respondent order.
12. Merchant manually validates customer.
13. Selected customer receives confirmation.
14. Other respondents are marked unavailable.
15. Revenue recovered is tracked.
16. Reports update.
17. STOP unsubscribe blocks future sends.

### 5. UI/UX audit

Check:

- mobile merchant experience
- waitlist page mobile experience
- clear CTAs
- clear errors
- empty states
- no confusing appointment-system replacement language
- bilingual readiness
- professional/simple style

### 6. Performance audit

Check:

- no obviously slow queries
- indexes exist for common filters
- import does not freeze browser for large CSV
- dashboard queries are scoped and efficient
- SMS sending is not blocking huge UI actions unnecessarily

### 7. Deployment readiness

Check:

- environment variables documented
- Vercel deployment instructions
- Supabase migration instructions
- SMS provider setup instructions
- webhook URLs documented
- test data setup
- rollback risks
- monitoring/logging gaps

## Required output

Create or update:

- `docs/beta-launch-checklist.md`
- `docs/security-audit.md`
- `docs/deployment-guide.md`
- `docs/known-limitations.md`

Fix critical issues found during audit.

If you find major issues that require big changes, document them and fix only what is safe within this phase.

## Validation commands

Run all available:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

If any command is missing, document it and recommend adding it.

## Final Codex response must include

- audit verdict
- critical issues found
- issues fixed
- issues remaining
- commands run
- deployment readiness
- beta launch recommendation
- exact files changed

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
