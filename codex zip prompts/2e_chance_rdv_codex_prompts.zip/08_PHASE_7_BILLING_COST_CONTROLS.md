# 08 — Phase 7: Billing, Provider Abstraction, Production Settings, and Cost Controls


# Project Context — 2e Chance RDV

You are working on **2e Chance RDV**, an independent SaaS project completely separate from Vistaire.

## Product idea

2e Chance RDV is a bilingual SMS-first cancellation recovery platform for appointment-based local businesses.

The product helps businesses fill last-minute appointment cancellations by sending SMS offers to customers who opted into a waitlist. The business keeps its existing appointment system. 2e Chance RDV is not trying to replace Square, Fresha, Booksy, GOrendezvous, Google Calendar, Instagram DMs, phone booking, or paper agendas.

The core positioning is:

> Fill last-minute cancellations by SMS without changing your current appointment system.

## Initial target sectors

The initial target sectors are:

- beauty / esthétique
- barbers
- salons

The product should remain generic enough to later support massage, detailing, clinics, and other appointment-based services.

## Market

The product is not limited to Laval or Montréal. It should be designed for broader use, starting in Canada/Quebec, but not hardcoded to a city.

## Language

The app must support both French and English.

Internal code, database fields, functions, variables, and technical identifiers must be written in English.

User-facing copy must be designed for bilingual support.

## Business model

Starting model:

- 34.99 CAD/month base subscription
- plus a percentage commission on recovered bookings
- commission should only apply when a booking is manually validated by the merchant as recovered/accepted
- percentage and cap should be configurable later

## Key product rules

1. Customers do not need an app.
2. Customers interact by SMS.
3. Businesses use a web dashboard.
4. Businesses keep their existing booking system.
5. The product provides import, waitlist, SMS offers, response tracking, manual validation, and recovered revenue reporting.
6. Last-minute discounts/offers are optional marketing tools, not mandatory.
7. The merchant manually validates the booking. The first customer to reply is not automatically confirmed.
8. The dashboard must show respondents ordered from first response to last response.
9. The winning customer receives confirmation only after the merchant validates them.
10. Customers can unsubscribe by STOP.
11. The system must never send cancellation-recovery SMS to customers who are opted out.
12. Imported customers without clear SMS consent must not be treated as opted in automatically.

## Recommended technical stack

Use the simplest robust SaaS stack:

- Next.js App Router
- TypeScript
- Tailwind CSS
- shadcn/ui or clean reusable UI components
- Supabase Auth
- Supabase Postgres
- Supabase Row Level Security
- Vercel deployment
- Plivo or another low-cost SMS provider, abstracted behind an internal SMS provider interface
- SMS simulator for development/testing
- Stripe later for billing
- Resend later for emails if needed

## Design direction

Professional, simple, clean, mobile-first.

The UI should feel trustworthy and easy for small businesses. Avoid overly flashy, neon, full-dark, sci-fi, or complicated enterprise UI. Use:

- soft off-white or light neutral backgrounds
- charcoal text
- clean cards
- rounded corners
- clear CTAs
- strong spacing
- dashboard-first usability
- mobile-first flows for merchants
- clear status badges and simple tables/lists

## Core entities

At minimum, the system will need:

- organizations
- organization_members / profiles
- services
- customers
- sms_consents
- waitlist_entries
- import_batches
- openings
- opening_offers
- sms_messages
- booking_requests or recovered_bookings
- audit_logs
- settings

## Core flow

1. Merchant imports customers via CSV/Excel or customers join via QR code waitlist page.
2. Customers have SMS consent status: opted_in, needs_consent, opted_out.
3. Merchant creates a last-minute opening.
4. Merchant optionally adds a last-minute offer/discount.
5. System sends SMS only to eligible opted-in waitlist customers.
6. Customers reply OUI / YES / 1.
7. The system records replies in chronological order.
8. Dashboard notifies merchant and shows respondent list.
9. Merchant manually validates one customer.
10. Validated customer receives confirmation SMS.
11. Other respondents receive a polite unavailable message.
12. Dashboard records recovered revenue, discount, and platform commission estimate.

## Non-negotiable quality rules

- Do not invent APIs, dependencies, tables, routes, or environment variables without checking the codebase and documenting the decision.
- Do not hardcode secrets.
- Do not store credentials in client-side code.
- Do not bypass consent rules.
- Do not send SMS to opted-out customers.
- Do not assume imported customers are opted in.
- Do not create unsafe multi-tenant data access.
- Use Row Level Security where appropriate.
- Keep code readable, simple, maintainable, and production-minded.
- Validate with lint, typecheck, build, tests, and manual QA steps when available.
- Return a clear summary of modified files, what was verified, what was not verified, and remaining risks.



## Mission

Prepare the app for real paid usage.

This phase focuses on billing, provider configuration, cost controls, environment safety, and operational settings.

Do not implement bloated enterprise billing. Keep it practical and safe.

## Required billing features

Use Stripe if requested/configured.

Implement:

- plan configuration
- 34.99 CAD/month base plan
- percentage commission model as internal tracking
- recovered booking commission calculation
- billing status on organization
- subscription status fields
- basic billing page
- webhook foundation if Stripe is implemented

If Stripe is not configured, create a billing-ready architecture with clear TODOs and no fake charging.

## Commission tracking

For every manually validated recovered booking, store:

- recovered value
- discount amount
- commission percent used
- commission cap if configured
- commission amount
- currency
- calculated_at

Commission should be traceable and not recalculated unpredictably later.

## SMS cost controls

Implement settings and protections:

- monthly SMS counter per organization
- daily SMS counter per organization
- per-customer SMS frequency guard if practical
- sending window settings
- failed SMS monitoring
- provider cost visibility field if possible
- admin SMS usage report

Do not send unlimited SMS without controls.

## Provider abstraction hardening

Ensure SMS provider architecture supports:

- simulator
- Plivo or selected low-cost provider
- optional Twilio fallback
- environment-based provider selection
- webhook verification when supported
- consistent inbound parsing

Do not spread provider-specific logic across the app.

## Organization settings

Add settings for:

- default language
- timezone
- SMS sending window
- default discount/offer behavior
- default commission percent if admin-configurable
- waitlist public status enabled/disabled

## Production environment safety

Add checks to prevent:

- missing environment variables
- accidental real SMS sends in development unless explicitly enabled
- service role key exposure
- webhook endpoint misuse
- invalid provider configuration

## Audit logs

Ensure audit logs exist for:

- billing status changes
- booking validation
- SMS sending
- import
- consent updates
- organization settings updates

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run build
```

If Stripe is added:

- test webhook handling locally if possible
- verify no secret keys are client-side
- verify webhook signature validation

If SMS provider is added:

- verify simulator still works
- verify provider config errors are handled cleanly
- do not send real SMS unless explicitly configured

## Final Codex response must include

- billing status
- commission tracking
- SMS cost controls
- provider abstraction status
- validation results
- production readiness gaps

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
