# 03 — Phase 3: Repair or Document Supabase Migration Tracking Drift


# Common Context — 2e Chance RDV

You are working on the repository:

```text
KirolosSeliman/2e-chance-RDV
```

Project name:

```text
2e Chance RDV
```

2e Chance RDV is an independent SaaS project, completely separate from Vistaire. It is a bilingual SMS-first cancellation recovery product for appointment-based businesses, initially targeting beauty, barbers, and salons.

The product helps merchants fill last-minute appointment cancellations by SMS without replacing their existing booking system.

Current important constraints:

- Use Next.js App Router, TypeScript, Tailwind, Supabase Auth, Supabase Postgres, Supabase RLS.
- Keep SMS disabled. Do not implement real Plivo/Twilio in these blocker-fix phases.
- Keep `SMS_PROVIDER=simulator`.
- Keep `ALLOW_REAL_SMS_SENDS=false`.
- Do not implement Stripe/billing checkout now.
- Do not implement CSV import persistence now unless a phase explicitly asks for it.
- Do not implement real SMS sending now.
- Do not add external integrations such as Square, Fresha, Booksy, GOrendezvous.
- Do not expose secrets.
- Do not commit `.env.local`.
- Do not weaken RLS.
- Do not invent tables, APIs, routes, or dependencies without verifying the repo first.
- Preserve the existing architecture unless there is a clearly justified security or correctness reason.

Supabase project currently used by the owner:

```text
Project URL: https://fuksavmwmfqyfmjcbgsx.supabase.co
Project ref: fuksavmwmfqyfmjcbgsx
```

Known audit findings that these phases address:

1. Supabase TypeScript types are incomplete compared to migrations and current code.
2. Supabase security advisors reported unsafe function warnings, especially `public.rls_auto_enable()` executable by anon/authenticated and `private.set_updated_at` mutable search_path.
3. Supabase migrations appear applied to the database, but migration tracking may not show them.
4. Organization bootstrap currently performs multiple writes with manual rollback instead of a transaction-safe RPC.
5. Users may be able to create multiple organizations even though no organization switcher exists yet.
6. Organization creation should be audited and data quality should be tightened.
7. Build/typecheck/test/lint and the live auth/onboarding flow need strict validation.


## Phase Goal

Resolve the discrepancy where Supabase tables exist in the live project but Supabase migration tracking may show no migrations.

This is a deployment and reliability problem. If the database schema exists but migrations are not tracked, future deployments can drift or fail.

## Specific Problem

The audit found:

- Live Supabase tables exist.
- RLS is enabled.
- But migration listing returned no tracked migrations.

This likely means migrations were applied manually in SQL Editor or with a method that did not record migration history.

## Required Work

1. Read the repo first.
2. Inspect `supabase/migrations`.
3. Inspect `docs/deployment-guide.md`.
4. Determine whether migration tracking can be repaired safely.

Possible actions:

### If Supabase CLI is available

Use a safe migration repair workflow. Do not guess. Inspect current state first:

```bash
supabase migration list
```

If the database has already applied migrations manually, document the correct repair command strategy. Do not run destructive commands without certainty.

### If Supabase CLI is not available

Update docs to clearly explain:

- tables exist live;
- migrations may not be tracked;
- future migrations must be applied in filename order;
- owner must run `supabase migration list`;
- owner may need `supabase migration repair` after confirming the live schema matches repo migrations.

5. Do not create duplicate migrations just to make tracking appear clean.
6. Do not reapply destructive schema migrations to a live DB with data unless idempotent and safe.
7. Do not drop tables or reset DB.

## Safety Requirements

- No destructive database reset.
- No table drops.
- No blind reapplication of migrations if schema already exists.
- No changes to production data.
- Preserve all existing data.

## Validation Required

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If Supabase CLI is available:

```bash
supabase migration list
```

If not, document exactly what the user must run locally.

## Success Criteria

This phase is complete only if:

- migration drift is repaired OR clearly documented with safe next steps;
- no destructive DB action was taken;
- deployment guide reflects the real state;
- future migration workflow is clear.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
