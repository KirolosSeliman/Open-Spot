# 01 — Phase 1: Fix Supabase TypeScript Types


# Common Context — 2e Chance RDV

You are working on the repository:

```text
KirolosSeliman/2e-chance-RDV
```

Project name:

```text
2e Chance RDV
```

2e Chance RDV is an independent SaaS project, completely separate from Vistaire. It is a bilingual SMS-first cancellation recovery product for appointment-based businesses, initially targeting beauty, barbers, and salons.

The product helps merchants fill last-minute appointment cancellations by SMS without replacing their existing booking system.

Current important constraints:

- Use Next.js App Router, TypeScript, Tailwind, Supabase Auth, Supabase Postgres, Supabase RLS.
- Keep SMS disabled. Do not implement real Plivo/Twilio in these blocker-fix phases.
- Keep `SMS_PROVIDER=simulator`.
- Keep `ALLOW_REAL_SMS_SENDS=false`.
- Do not implement Stripe/billing checkout now.
- Do not implement CSV import persistence now unless a phase explicitly asks for it.
- Do not implement real SMS sending now.
- Do not add external integrations such as Square, Fresha, Booksy, GOrendezvous.
- Do not expose secrets.
- Do not commit `.env.local`.
- Do not weaken RLS.
- Do not invent tables, APIs, routes, or dependencies without verifying the repo first.
- Preserve the existing architecture unless there is a clearly justified security or correctness reason.

Supabase project currently used by the owner:

```text
Project URL: https://fuksavmwmfqyfmjcbgsx.supabase.co
Project ref: fuksavmwmfqyfmjcbgsx
```

Known audit findings that these phases address:

1. Supabase TypeScript types are incomplete compared to migrations and current code.
2. Supabase security advisors reported unsafe function warnings, especially `public.rls_auto_enable()` executable by anon/authenticated and `private.set_updated_at` mutable search_path.
3. Supabase migrations appear applied to the database, but migration tracking may not show them.
4. Organization bootstrap currently performs multiple writes with manual rollback instead of a transaction-safe RPC.
5. Users may be able to create multiple organizations even though no organization switcher exists yet.
6. Organization creation should be audited and data quality should be tightened.
7. Build/typecheck/test/lint and the live auth/onboarding flow need strict validation.


## Phase Goal

Fix the mismatch between the actual Supabase schema/migrations and `src/types/database.ts`.

The audit found that `src/lib/organization/current.ts` queries tables such as `services`, but `src/types/database.ts` only declares a small subset of tables. This can break `npm run typecheck` and `npm run build`.

## Specific Problem

Current code uses Supabase tables that may not exist in the TypeScript `Database` type.

Examples to inspect:

- `src/types/database.ts`
- `src/lib/organization/current.ts`
- `src/lib/organization/actions.ts`
- `src/app/api/waitlist/route.ts`
- `src/app/api/openings/[id]/validate/route.ts`
- all `supabase/migrations/*.sql`

## Required Work

1. Read the repo first.
2. Inspect all Supabase table usage in TypeScript:
   - `.from("...")`
   - `.rpc("...")`
   - table row shape casts
   - manually defined Supabase client generics
3. Compare current TypeScript `Database` type against migrations.
4. Fix `src/types/database.ts` so it includes all tables, enums, and functions used by current code.

Preferred approach:

- If Supabase CLI and project access are available, generate types from the linked Supabase project.
- If generation is not possible, update the manual `Database` type carefully from migrations.

Tables that likely must be represented:

- `organizations`
- `organization_members`
- `services`
- `customers`
- `sms_consents`
- `waitlist_entries`
- `import_batches`
- `openings`
- `opening_offers`
- `booking_requests`
- `sms_messages`
- `audit_logs`
- `organization_billing_settings`
- `commission_records`
- `sms_usage_counters`

Functions that likely must be represented:

- `register_waitlist_signup`
- `validate_opening_offer`

5. Do not change business logic unless necessary to fix type correctness.
6. Do not remove strict TypeScript.
7. Do not weaken types to `any` unless there is a narrow, justified boundary.
8. Add or update tests only if needed.

## Safety Requirements

- Do not expose secrets.
- Do not modify `.env.local`.
- Do not change Supabase RLS policies in this phase.
- Do not implement new features.
- Do not activate real SMS.

## Validation Required

Run:

```bash
npm run typecheck
npm run lint
npm test
npm run build
```

## Success Criteria

This phase is complete only if:

- `src/types/database.ts` matches current code usage;
- TypeScript no longer errors on Supabase table names;
- no `any` blanket workaround is introduced;
- all required validation commands pass or failures are unrelated and documented.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
