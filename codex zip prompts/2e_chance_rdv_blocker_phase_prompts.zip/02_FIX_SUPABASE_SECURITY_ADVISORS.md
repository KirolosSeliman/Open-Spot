# 02 — Phase 2: Fix Supabase Security Advisor Warnings


# Common Context — 2e Chance RDV

You are working on the repository:

```text
KirolosSeliman/2e-chance-RDV
```

Project name:

```text
2e Chance RDV
```

2e Chance RDV is an independent SaaS project, completely separate from Vistaire. It is a bilingual SMS-first cancellation recovery product for appointment-based businesses, initially targeting beauty, barbers, and salons.

The product helps merchants fill last-minute appointment cancellations by SMS without replacing their existing booking system.

Current important constraints:

- Use Next.js App Router, TypeScript, Tailwind, Supabase Auth, Supabase Postgres, Supabase RLS.
- Keep SMS disabled. Do not implement real Plivo/Twilio in these blocker-fix phases.
- Keep `SMS_PROVIDER=simulator`.
- Keep `ALLOW_REAL_SMS_SENDS=false`.
- Do not implement Stripe/billing checkout now.
- Do not implement CSV import persistence now unless a phase explicitly asks for it.
- Do not implement real SMS sending now.
- Do not add external integrations such as Square, Fresha, Booksy, GOrendezvous.
- Do not expose secrets.
- Do not commit `.env.local`.
- Do not weaken RLS.
- Do not invent tables, APIs, routes, or dependencies without verifying the repo first.
- Preserve the existing architecture unless there is a clearly justified security or correctness reason.

Supabase project currently used by the owner:

```text
Project URL: https://fuksavmwmfqyfmjcbgsx.supabase.co
Project ref: fuksavmwmfqyfmjcbgsx
```

Known audit findings that these phases address:

1. Supabase TypeScript types are incomplete compared to migrations and current code.
2. Supabase security advisors reported unsafe function warnings, especially `public.rls_auto_enable()` executable by anon/authenticated and `private.set_updated_at` mutable search_path.
3. Supabase migrations appear applied to the database, but migration tracking may not show them.
4. Organization bootstrap currently performs multiple writes with manual rollback instead of a transaction-safe RPC.
5. Users may be able to create multiple organizations even though no organization switcher exists yet.
6. Organization creation should be audited and data quality should be tightened.
7. Build/typecheck/test/lint and the live auth/onboarding flow need strict validation.


## Phase Goal

Fix the Supabase security warnings found in the audit without weakening RLS or breaking the app.

## Specific Problems

Supabase Advisor reported:

1. `private.set_updated_at` has a role-mutable `search_path`.
2. `public.rls_auto_enable()` is a `SECURITY DEFINER` function executable by `anon`.
3. `public.rls_auto_enable()` is also executable by `authenticated`.

These are security hardening blockers before production.

## Required Work

1. Read the repo and current migrations first.
2. Inspect whether `public.rls_auto_enable()` exists in repo migrations or only in the live Supabase database.
3. Determine whether `public.rls_auto_enable()` is still needed.
4. Create a new migration to fix advisor warnings.

Likely safe fixes:

### For `private.set_updated_at`

Recreate the function with a fixed search path, for example:

```sql
create or replace function private.set_updated_at()
returns trigger
language plpgsql
set search_path = private, public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;
```

Adjust search_path only after verifying the function’s needs.

### For `public.rls_auto_enable()`

If it is not needed:

```sql
revoke all on function public.rls_auto_enable() from public, anon, authenticated;
```

If it should not exist:

```sql
drop function if exists public.rls_auto_enable();
```

Choose the safest option based on inspection. Do not drop anything blindly if it is used by migrations or current code.

5. Add comments in the migration explaining why the fix exists.
6. Do not weaken RLS policies.
7. Do not grant broad privileges.
8. Do not create a new exposed `SECURITY DEFINER` function unless necessary and tightly controlled.

## Safety Requirements

- Do not change app behavior except fixing DB security.
- Do not expose service role secrets.
- Do not make functions executable by `anon` unless explicitly needed and safe.
- Do not disable RLS.
- Do not bypass RLS for app routes.

## Validation Required

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If Supabase CLI/project access is available:

```bash
supabase db lint
supabase migration list
```

Or use the Supabase advisor tool/logs if available.

## Success Criteria

This phase is complete only if:

- security advisor warnings are fixed or explicitly justified;
- a migration is added for the fix;
- RLS remains enabled;
- no new advisor warning is introduced;
- validation commands pass or are clearly documented.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
