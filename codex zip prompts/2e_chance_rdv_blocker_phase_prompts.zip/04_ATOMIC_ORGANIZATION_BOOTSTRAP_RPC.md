# 04 — Phase 4: Make Organization Bootstrap Transaction-Safe


# Common Context — 2e Chance RDV

You are working on the repository:

```text
KirolosSeliman/2e-chance-RDV
```

Project name:

```text
2e Chance RDV
```

2e Chance RDV is an independent SaaS project, completely separate from Vistaire. It is a bilingual SMS-first cancellation recovery product for appointment-based businesses, initially targeting beauty, barbers, and salons.

The product helps merchants fill last-minute appointment cancellations by SMS without replacing their existing booking system.

Current important constraints:

- Use Next.js App Router, TypeScript, Tailwind, Supabase Auth, Supabase Postgres, Supabase RLS.
- Keep SMS disabled. Do not implement real Plivo/Twilio in these blocker-fix phases.
- Keep `SMS_PROVIDER=simulator`.
- Keep `ALLOW_REAL_SMS_SENDS=false`.
- Do not implement Stripe/billing checkout now.
- Do not implement CSV import persistence now unless a phase explicitly asks for it.
- Do not implement real SMS sending now.
- Do not add external integrations such as Square, Fresha, Booksy, GOrendezvous.
- Do not expose secrets.
- Do not commit `.env.local`.
- Do not weaken RLS.
- Do not invent tables, APIs, routes, or dependencies without verifying the repo first.
- Preserve the existing architecture unless there is a clearly justified security or correctness reason.

Supabase project currently used by the owner:

```text
Project URL: https://fuksavmwmfqyfmjcbgsx.supabase.co
Project ref: fuksavmwmfqyfmjcbgsx
```

Known audit findings that these phases address:

1. Supabase TypeScript types are incomplete compared to migrations and current code.
2. Supabase security advisors reported unsafe function warnings, especially `public.rls_auto_enable()` executable by anon/authenticated and `private.set_updated_at` mutable search_path.
3. Supabase migrations appear applied to the database, but migration tracking may not show them.
4. Organization bootstrap currently performs multiple writes with manual rollback instead of a transaction-safe RPC.
5. Users may be able to create multiple organizations even though no organization switcher exists yet.
6. Organization creation should be audited and data quality should be tightened.
7. Build/typecheck/test/lint and the live auth/onboarding flow need strict validation.


## Phase Goal

Replace the current multi-step organization bootstrap logic with a safer transaction-controlled database function or a clearly safer server-side flow.

## Specific Problem

Current organization creation likely does:

1. Insert into `organizations`.
2. Insert into `organization_members`.
3. Insert into `organization_billing_settings`.
4. If step 2 or 3 fails, manually delete organization.

This is not transaction-safe and can create partial data or rollback failures.

## Required Work

1. Read the repo first.
2. Inspect:
   - `src/lib/organization/actions.ts`
   - `supabase/migrations`
   - RLS policies
   - current organization onboarding tests
3. Create a new safe migration with an RPC such as:

```sql
public.create_organization_with_owner(...)
```

The function should:

- require an authenticated user;
- create organization;
- create owner membership for `auth.uid()`;
- create organization billing settings if table exists;
- create an audit log row;
- run transactionally by default as a Postgres function;
- reject duplicate slugs;
- reject missing/invalid values;
- use fixed `search_path`;
- avoid broad public execution;
- not allow creating an organization for another user.

Important: The function must not allow `anon` execution.

4. Update the server action to call this RPC instead of doing manual multi-step writes.
5. Keep the service role usage minimal or eliminate it if the RPC can safely use authenticated context.
6. Ensure the RPC is compatible with existing RLS/security requirements.
7. Add tests for:
   - valid organization payload;
   - duplicate slug behavior if practical;
   - already-member handling if combined with Phase 5;
   - no client-controlled user ID.

## Safety Requirements

- Do not weaken RLS.
- Do not make the RPC broadly exploitable.
- Use `auth.uid()` inside the RPC rather than accepting arbitrary user ID from client.
- Do not expose service role to client.
- Do not activate real SMS.
- Do not implement unrelated features.

## Validation Required

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If Supabase DB access is available, test the RPC in a safe staging/test context.

## Success Criteria

This phase is complete only if:

- organization creation is transaction-safe;
- server action no longer relies on manual rollback;
- creator becomes owner;
- billing settings are created if required;
- audit log is created if required;
- duplicate slug is handled cleanly;
- validation commands pass.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
