# 08 — Phase 8: Final Smoke-Test and Deployment Readiness Review


# Common Context — 2e Chance RDV

You are working on the repository:

```text
KirolosSeliman/2e-chance-RDV
```

Project name:

```text
2e Chance RDV
```

2e Chance RDV is an independent SaaS project, completely separate from Vistaire. It is a bilingual SMS-first cancellation recovery product for appointment-based businesses, initially targeting beauty, barbers, and salons.

The product helps merchants fill last-minute appointment cancellations by SMS without replacing their existing booking system.

Current important constraints:

- Use Next.js App Router, TypeScript, Tailwind, Supabase Auth, Supabase Postgres, Supabase RLS.
- Keep SMS disabled. Do not implement real Plivo/Twilio in these blocker-fix phases.
- Keep `SMS_PROVIDER=simulator`.
- Keep `ALLOW_REAL_SMS_SENDS=false`.
- Do not implement Stripe/billing checkout now.
- Do not implement CSV import persistence now unless a phase explicitly asks for it.
- Do not implement real SMS sending now.
- Do not add external integrations such as Square, Fresha, Booksy, GOrendezvous.
- Do not expose secrets.
- Do not commit `.env.local`.
- Do not weaken RLS.
- Do not invent tables, APIs, routes, or dependencies without verifying the repo first.
- Preserve the existing architecture unless there is a clearly justified security or correctness reason.

Supabase project currently used by the owner:

```text
Project URL: https://fuksavmwmfqyfmjcbgsx.supabase.co
Project ref: fuksavmwmfqyfmjcbgsx
```

Known audit findings that these phases address:

1. Supabase TypeScript types are incomplete compared to migrations and current code.
2. Supabase security advisors reported unsafe function warnings, especially `public.rls_auto_enable()` executable by anon/authenticated and `private.set_updated_at` mutable search_path.
3. Supabase migrations appear applied to the database, but migration tracking may not show them.
4. Organization bootstrap currently performs multiple writes with manual rollback instead of a transaction-safe RPC.
5. Users may be able to create multiple organizations even though no organization switcher exists yet.
6. Organization creation should be audited and data quality should be tightened.
7. Build/typecheck/test/lint and the live auth/onboarding flow need strict validation.


## Phase Goal

Perform a final readiness audit after the blocker fixes are complete.

This phase does not add major features. It verifies whether the foundation is safe enough to deploy as an internal/beta preview.

## Required Work

1. Read the repo first.
2. Inspect recent commits.
3. Confirm no secrets are committed.
4. Confirm `.env.example` is safe.
5. Confirm `.env.local` is ignored.
6. Confirm real SMS is disabled.
7. Confirm Supabase Auth + onboarding + dashboard are implemented.
8. Confirm known limitations are accurate.
9. Confirm deployment guide is accurate.
10. Run validation commands:

```bash
git status
npm run lint
npm run typecheck
npm test
npm run build
```

11. If Vercel is configured, inspect deployment/build logs if available.
12. If Supabase access is configured, check:
   - RLS enabled;
   - advisor warnings resolved or documented;
   - migrations tracked or drift documented;
   - no unsafe `SECURITY DEFINER` public function remains.
13. Produce a final deployability rating from 0 to 10.

## Required Final Verdict

Use one:

- READY FOR INTERNAL PREVIEW
- ALMOST READY BUT NEEDS MINOR FIXES
- NOT READY FOR PREVIEW
- DANGEROUS / BLOCKED

This is not “production-ready” unless auth, onboarding, RLS, build, and security checks are verified.

## Safety Requirements

- Do not add unrelated product features.
- Do not activate real SMS.
- Do not add Stripe.
- Do not weaken security to pass checks.
- Do not claim deployability without evidence.

## Success Criteria

This phase is complete only if:

- the project can be evaluated honestly for beta/internal preview;
- all validation results are reported;
- remaining blockers are clearly separated from non-blocking improvements;
- the next phase recommendation is precise.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
