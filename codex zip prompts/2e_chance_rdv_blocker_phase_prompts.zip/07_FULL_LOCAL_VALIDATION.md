# 07 — Phase 7: Full Local Validation of Auth, Onboarding, and Dashboard


# Common Context — 2e Chance RDV

You are working on the repository:

```text
KirolosSeliman/2e-chance-RDV
```

Project name:

```text
2e Chance RDV
```

2e Chance RDV is an independent SaaS project, completely separate from Vistaire. It is a bilingual SMS-first cancellation recovery product for appointment-based businesses, initially targeting beauty, barbers, and salons.

The product helps merchants fill last-minute appointment cancellations by SMS without replacing their existing booking system.

Current important constraints:

- Use Next.js App Router, TypeScript, Tailwind, Supabase Auth, Supabase Postgres, Supabase RLS.
- Keep SMS disabled. Do not implement real Plivo/Twilio in these blocker-fix phases.
- Keep `SMS_PROVIDER=simulator`.
- Keep `ALLOW_REAL_SMS_SENDS=false`.
- Do not implement Stripe/billing checkout now.
- Do not implement CSV import persistence now unless a phase explicitly asks for it.
- Do not implement real SMS sending now.
- Do not add external integrations such as Square, Fresha, Booksy, GOrendezvous.
- Do not expose secrets.
- Do not commit `.env.local`.
- Do not weaken RLS.
- Do not invent tables, APIs, routes, or dependencies without verifying the repo first.
- Preserve the existing architecture unless there is a clearly justified security or correctness reason.

Supabase project currently used by the owner:

```text
Project URL: https://fuksavmwmfqyfmjcbgsx.supabase.co
Project ref: fuksavmwmfqyfmjcbgsx
```

Known audit findings that these phases address:

1. Supabase TypeScript types are incomplete compared to migrations and current code.
2. Supabase security advisors reported unsafe function warnings, especially `public.rls_auto_enable()` executable by anon/authenticated and `private.set_updated_at` mutable search_path.
3. Supabase migrations appear applied to the database, but migration tracking may not show them.
4. Organization bootstrap currently performs multiple writes with manual rollback instead of a transaction-safe RPC.
5. Users may be able to create multiple organizations even though no organization switcher exists yet.
6. Organization creation should be audited and data quality should be tightened.
7. Build/typecheck/test/lint and the live auth/onboarding flow need strict validation.


## Phase Goal

Prove that the current Auth + Organization Workspace foundation actually builds and works locally.

This phase is mostly validation and small fixes only.

## Required Work

1. Read the repo first.
2. Run:

```bash
git status
npm ci
npm run lint
npm run typecheck
npm test
npm run build
```

3. If any command fails:
   - identify the root cause;
   - fix it minimally;
   - rerun the failed command;
   - do not hide failures.

4. Perform manual local checks if possible:

```text
/signup
/sign-in
/onboarding
/dashboard
```

Expected behavior:

- signed-out user trying `/dashboard` redirects to `/sign-in`;
- user can sign up;
- user can sign in;
- signed-in user with no organization goes to `/onboarding`;
- user can create organization;
- user becomes owner;
- dashboard shows real organization name, role, language, timezone, and counts.

5. If real Supabase env vars are unavailable in Codex, document exact local test steps for the owner instead.

## Safety Requirements

- Do not add features.
- Do not skip failing tests.
- Do not disable tests.
- Do not disable TypeScript strict.
- Do not edit `.env.local`.
- Do not use real SMS.

## Validation Required

This phase is validation. The validation commands are mandatory.

## Success Criteria

This phase is complete only if:

- lint passes;
- typecheck passes;
- tests pass;
- build passes;
- manual flow is verified OR unverified steps are documented with exact owner instructions.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
