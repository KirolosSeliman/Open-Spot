# 2e Chance RDV — Blocker Fix Prompt Pack

This pack separates the current blockers into focused Codex phases.

## How to use

1. Start with `00_MASTER_PHASE_DISCIPLINE.md`.
2. Then give Codex exactly one phase prompt at a time.
3. Do not give all phase prompts at once.
4. After each phase, review Codex output.
5. Run or verify the commands Codex claims it ran.
6. Only move to the next phase when the current one is complete and validated.

## Phase order

1. `01_FIX_SUPABASE_TYPES.md`
2. `02_FIX_SUPABASE_SECURITY_ADVISORS.md`
3. `03_REPAIR_MIGRATION_TRACKING.md`
4. `04_ATOMIC_ORGANIZATION_BOOTSTRAP_RPC.md`
5. `05_PREVENT_MULTI_ORG_WITHOUT_SWITCHER.md`
6. `06_ORG_AUDIT_LOGS_DATA_QUALITY.md`
7. `07_FULL_LOCAL_VALIDATION.md`
8. `08_FINAL_SMOKE_TEST_DEPLOYMENT_READINESS.md`

## Important

Do not move to CSV import, real SMS, Plivo, Stripe, or bookings until these blockers are fixed.
