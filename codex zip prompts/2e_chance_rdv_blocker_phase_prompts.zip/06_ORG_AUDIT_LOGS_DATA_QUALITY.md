# 06 — Phase 6: Add Organization Audit Logs and Data-Quality Guardrails


# Common Context — 2e Chance RDV

You are working on the repository:

```text
KirolosSeliman/2e-chance-RDV
```

Project name:

```text
2e Chance RDV
```

2e Chance RDV is an independent SaaS project, completely separate from Vistaire. It is a bilingual SMS-first cancellation recovery product for appointment-based businesses, initially targeting beauty, barbers, and salons.

The product helps merchants fill last-minute appointment cancellations by SMS without replacing their existing booking system.

Current important constraints:

- Use Next.js App Router, TypeScript, Tailwind, Supabase Auth, Supabase Postgres, Supabase RLS.
- Keep SMS disabled. Do not implement real Plivo/Twilio in these blocker-fix phases.
- Keep `SMS_PROVIDER=simulator`.
- Keep `ALLOW_REAL_SMS_SENDS=false`.
- Do not implement Stripe/billing checkout now.
- Do not implement CSV import persistence now unless a phase explicitly asks for it.
- Do not implement real SMS sending now.
- Do not add external integrations such as Square, Fresha, Booksy, GOrendezvous.
- Do not expose secrets.
- Do not commit `.env.local`.
- Do not weaken RLS.
- Do not invent tables, APIs, routes, or dependencies without verifying the repo first.
- Preserve the existing architecture unless there is a clearly justified security or correctness reason.

Supabase project currently used by the owner:

```text
Project URL: https://fuksavmwmfqyfmjcbgsx.supabase.co
Project ref: fuksavmwmfqyfmjcbgsx
```

Known audit findings that these phases address:

1. Supabase TypeScript types are incomplete compared to migrations and current code.
2. Supabase security advisors reported unsafe function warnings, especially `public.rls_auto_enable()` executable by anon/authenticated and `private.set_updated_at` mutable search_path.
3. Supabase migrations appear applied to the database, but migration tracking may not show them.
4. Organization bootstrap currently performs multiple writes with manual rollback instead of a transaction-safe RPC.
5. Users may be able to create multiple organizations even though no organization switcher exists yet.
6. Organization creation should be audited and data quality should be tightened.
7. Build/typecheck/test/lint and the live auth/onboarding flow need strict validation.


## Phase Goal

Improve data quality and auditability for organization creation without expanding product scope.

## Specific Problems

- Organization creation should be auditable.
- Business phone is stored as raw text without normalization.
- Organization creation needs clearer metadata for future debugging and compliance.
- Data quality now matters for future reports, billing, and support.

## Required Work

1. Read the repo first.
2. Inspect:
   - `src/lib/organization/onboarding.ts`
   - `src/lib/organization/actions.ts`
   - migration schemas for `audit_logs`
   - existing phone normalization utility in `src/lib/customers/phone.ts`
3. Add audit logging for organization creation if not already done.
4. Add data-quality validation:
   - normalize slug;
   - validate slug matches DB constraint before DB write;
   - optionally normalize business phone to E.164 or allow null if invalid;
   - validate email shape minimally if provided;
   - preserve default language as `en` or `fr`;
   - preserve timezone only from allowed list for now.
5. Avoid storing unnecessary PII.
6. Update tests for:
   - invalid slug;
   - invalid email if validation added;
   - invalid phone behavior;
   - audit behavior if testable.

## Safety Requirements

- Do not store secrets in audit logs.
- Do not store full tokens or service role data.
- Do not log sensitive request bodies.
- Do not block valid businesses unnecessarily, but do not store junk values.
- Do not activate real SMS.

## Validation Required

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Success Criteria

This phase is complete only if:

- organization creation is audited;
- data quality validation is improved;
- tests cover the new validation;
- no excessive PII is stored;
- validation commands pass.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
