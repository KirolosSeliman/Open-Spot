# 05 — Phase 5: Prevent Accidental Multi-Organization Creation Until Switcher Exists


# Common Context — 2e Chance RDV

You are working on the repository:

```text
KirolosSeliman/2e-chance-RDV
```

Project name:

```text
2e Chance RDV
```

2e Chance RDV is an independent SaaS project, completely separate from Vistaire. It is a bilingual SMS-first cancellation recovery product for appointment-based businesses, initially targeting beauty, barbers, and salons.

The product helps merchants fill last-minute appointment cancellations by SMS without replacing their existing booking system.

Current important constraints:

- Use Next.js App Router, TypeScript, Tailwind, Supabase Auth, Supabase Postgres, Supabase RLS.
- Keep SMS disabled. Do not implement real Plivo/Twilio in these blocker-fix phases.
- Keep `SMS_PROVIDER=simulator`.
- Keep `ALLOW_REAL_SMS_SENDS=false`.
- Do not implement Stripe/billing checkout now.
- Do not implement CSV import persistence now unless a phase explicitly asks for it.
- Do not implement real SMS sending now.
- Do not add external integrations such as Square, Fresha, Booksy, GOrendezvous.
- Do not expose secrets.
- Do not commit `.env.local`.
- Do not weaken RLS.
- Do not invent tables, APIs, routes, or dependencies without verifying the repo first.
- Preserve the existing architecture unless there is a clearly justified security or correctness reason.

Supabase project currently used by the owner:

```text
Project URL: https://fuksavmwmfqyfmjcbgsx.supabase.co
Project ref: fuksavmwmfqyfmjcbgsx
```

Known audit findings that these phases address:

1. Supabase TypeScript types are incomplete compared to migrations and current code.
2. Supabase security advisors reported unsafe function warnings, especially `public.rls_auto_enable()` executable by anon/authenticated and `private.set_updated_at` mutable search_path.
3. Supabase migrations appear applied to the database, but migration tracking may not show them.
4. Organization bootstrap currently performs multiple writes with manual rollback instead of a transaction-safe RPC.
5. Users may be able to create multiple organizations even though no organization switcher exists yet.
6. Organization creation should be audited and data quality should be tightened.
7. Build/typecheck/test/lint and the live auth/onboarding flow need strict validation.


## Phase Goal

Prevent a signed-in user from creating multiple organizations while the app does not yet have an organization switcher.

## Specific Problem

The onboarding page redirects existing members away from onboarding, but the server action itself may not explicitly block a direct POST by a user who already belongs to an organization.

This can create multiple organizations for one user, while the dashboard currently uses the first membership as the active organization.

## Required Work

1. Read the repo first.
2. Inspect:
   - `src/lib/organization/current.ts`
   - `src/lib/organization/actions.ts`
   - any new RPC from Phase 4
   - `organization_members` migration constraints
3. Add a server-side guard:
   - If the user already has a membership, do not create another organization.
   - Redirect to `/dashboard` or return a clear error.
4. If Phase 4 RPC exists, enforce this guard inside the RPC too.
5. Keep current “first membership is active” logic documented as temporary.
6. Update tests to verify:
   - user without organization may onboard;
   - user with organization cannot create another organization through the action/RPC;
   - redirect decisions are correct.

## Safety Requirements

- Do not implement a full organization switcher in this phase.
- Do not delete existing organizations.
- Do not change unrelated data.
- Do not weaken RLS.
- Do not activate real SMS.

## Validation Required

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Success Criteria

This phase is complete only if:

- users cannot create accidental second organizations;
- current single-org limitation is documented;
- dashboard still loads the active organization;
- tests cover this behavior.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
