# Phase 5 — Database Model, Migrations, and RLS Alignment

## Goal

Align the actual Supabase/Postgres schema, TypeScript types, documentation, and app assumptions.

This is foundational for secure multi-tenant behavior.

## Problem to solve

The documentation proposes a data model, while `src/types/database.ts` shows a concrete schema that differs in several ways. Before building more features, the project must settle the real model and ensure migrations and RLS exist.

## Required solution

1. Inspect:
   - `src/types/database.ts`
   - `docs/data-model.md`
   - `docs/security-and-privacy.md`
   - `docs/product-requirements.md`
   - `supabase/` directory if present
   - existing migrations if present
   - all code querying Supabase

2. Identify mismatches between docs and actual types, including:
   - `profiles` vs direct `auth.users`
   - `organization_members.user_id` vs `profile_id`
   - audit actor fields
   - booking validation fields
   - `sms_messages` timestamp fields
   - consent fields
   - organization settings/billing settings
   - role enums
   - waitlist fields

3. Decide the simplest safe MVP schema. Prefer minimal changes that support:
   - organizations;
   - organization members;
   - services;
   - customers;
   - sms_consents;
   - waitlist_entries;
   - openings;
   - opening_offers or equivalent recipients;
   - sms_messages;
   - booking_requests;
   - audit_logs;
   - SMS usage/cost control if already present.

4. Create or update migrations if missing.

5. Add or verify RLS policies for every organization-scoped table.

6. Required RLS behavior:
   - users can read/write only rows for organizations where they are members;
   - role permissions are enforced where practical;
   - public waitlist insert is narrowly controlled;
   - service role may write webhook records server-side;
   - normal users cannot bypass organization scope;
   - audit logs are append-only for normal flows.

7. Update TypeScript database types if needed.

8. Update docs to match the chosen schema.

## Security requirements

This phase must be treated as security-critical.

Never implement tenant isolation only in client-side code.

Never allow a user from one organization to read:
- another organization’s customers;
- consent records;
- SMS messages;
- openings;
- replies;
- booking requests;
- billing settings;
- audit logs.

Do not expose service role key to browser code.

## Integration requirements

- Existing auth/onboarding must still work.
- Existing dashboard can still use mock data temporarily, but real DB foundation must be valid.
- RPCs such as `create_organization_with_owner`, `register_waitlist_signup`, and `validate_opening_offer` must match the actual schema or be removed/replaced.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

If Supabase CLI is available, also run the appropriate migration validation commands.

Add tests or SQL verification notes for:
- organization isolation;
- owner membership creation;
- public waitlist insert;
- consent status restrictions;
- validation RPC behavior if implemented.

## Completion criteria

This phase is complete only when the schema, docs, TypeScript types, and security model no longer contradict each other.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.