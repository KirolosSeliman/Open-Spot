# Phase 2 — Remove AI Promises From MVP Marketing

## Goal

Remove or rewrite public AI claims from the MVP marketing experience because AI is out of MVP scope.

The product must remain simple, credible, and sellable without promising functionality that does not exist.

## Problem to solve

The marketing page currently presents AI/smart targeting language, but the product requirements list AI features as out of scope for MVP. This creates a product/marketing mismatch and can damage trust with merchants.

## Required solution

1. Inspect:
   - `docs/product-requirements.md`
   - `docs/roadmap.md`
   - `src/components/marketing/open-spot-funnel.tsx`
   - `src/app/globals.css`
   - any marketing or dashboard copy mentioning:
     - AI
     - IA
     - smart targeting
     - intelligent targeting
     - agent
     - assistant
     - prioritization if it implies AI

2. Remove the dedicated AI section from the landing page MVP experience, or rewrite it into a non-AI section.

3. Replace AI claims with accurate MVP language:
   - service-based targeting
   - consent-based recipient selection
   - customer preferences
   - merchant rules
   - manual control
   - no automatic confirmation

4. Ensure the hero mockup does not imply an AI engine if no AI exists.

5. If there are CSS classes only used by the removed AI section, clean them only if safe. Do not over-refactor.

6. Keep the landing strong. Do not make the page weaker. Replace the AI promise with a credible operational benefit.

## Suggested replacement messaging

Use copy in this direction, adapted to existing style:

- “Ciblez les bons clients selon vos services, leurs préférences et leur consentement SMS.”
- “La sélection reste contrôlée par le commerce.”
- “Aucune réservation automatique. Vous confirmez toujours manuellement.”
- “Simple, rapide, sans changer votre système de rendez-vous.”

## Security and quality requirements

- No fake AI claims.
- No hidden future feature presented as current.
- No new dependencies.
- No unnecessary UI complexity.
- Keep mobile responsive behavior intact.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run build
```

Search the repo for AI-related terms after changes. If any remain, document whether they are roadmap-only, doc-only, or still visible in production UI.

## Completion criteria

This phase is complete only when the MVP public landing page no longer promises AI functionality and still communicates a strong business value.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.