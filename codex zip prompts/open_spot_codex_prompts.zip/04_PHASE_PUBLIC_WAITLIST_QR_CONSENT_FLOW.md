# Phase 4 — Public Waitlist QR Signup Flow

## Goal

Implement the missing or incomplete public waitlist signup flow used by QR codes.

This is a core MVP feature because merchants need a safe way to collect opted-in customers.

## Problem to solve

The dashboard waitlist page references a public signup link, but the public route appears missing or incomplete. The MVP requires a QR-code waitlist page with explicit SMS consent.

## Required solution

1. Inspect existing route conventions:
   - `src/app`
   - `src/app/dashboard/waitlist/page.tsx`
   - Supabase helpers
   - organization types
   - database types
   - any existing waitlist/signup functions
   - `src/types/database.ts`

2. Implement a public route such as:

```text
/b/[organizationSlug]/waitlist
```

or use the route pattern already intended by the codebase if different.

3. The public page must:
   - load public organization basics by slug;
   - show merchant/business name;
   - not expose private business settings;
   - collect customer full name;
   - collect phone number;
   - collect preferred language;
   - collect optional service interest if services are available;
   - include explicit SMS consent checkbox;
   - display clear consent copy in FR/EN;
   - submit through safe server logic;
   - create/update customer safely;
   - create a consent record;
   - create a waitlist entry;
   - never mark someone opted in without checked consent;
   - handle duplicates by organization + phone safely;
   - show success and error states.

4. Use existing RPC `register_waitlist_signup` if it exists and is correct. If it does not exist in migrations/code, create a safe server action route that works with the current schema.

5. If migrations/RLS are missing, document the missing backend requirement clearly and implement the frontend/server scaffolding in a way that fails safely.

6. Update dashboard waitlist QR link to use the active organization slug when possible instead of hardcoded demo links.

## SMS consent requirements

Consent copy must clearly say:
- the customer agrees to receive SMS alerts for last-minute openings from this business;
- replying does not automatically confirm an appointment;
- the merchant must validate manually;
- message/data rates may apply if appropriate;
- they can reply STOP/ARRET to unsubscribe.

Do not claim legal compliance as final. Mark consent copy as requiring legal review before production if needed.

## Security and privacy requirements

- Public page must not allow arbitrary organization data exposure.
- Public inserts must be narrowly scoped.
- Do not use service role in client components.
- Validate and normalize phone server-side.
- Prevent cross-tenant inserts.
- Do not store unnecessary sensitive notes.
- Avoid leaking whether a phone already exists if that creates privacy risk.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

Add tests if there are existing test patterns. At minimum test:
- phone normalization;
- required consent;
- duplicate-safe behavior if server logic is implemented;
- invalid slug behavior.

## Completion criteria

This phase is complete only when a merchant can use a QR/public link to collect a customer with explicit consent safely, or when missing DB/RLS blockers are documented with exact next steps.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.