# Phase 1 — Branding and Name Consistency

## Goal

Fix the urgent branding inconsistency between `Open Spot` and `2e Chance RDV`.

The public-facing product name must be consistent. For this phase, use **2e Chance RDV** as the visible public product name unless the repository contains a newer explicit naming decision.

Do not perform a destructive rename of technical folders, package names, database names, or routes unless necessary. This phase is about visible product copy and documentation consistency first.

## Problem to solve

The project currently mixes names across marketing, metadata, dashboard, and documentation. This makes the product look unfinished and weakens commercial credibility.

Examples of places to inspect:

- `README.md`
- `src/app/layout.tsx`
- `src/app/page.tsx`
- `src/components/marketing/open-spot-funnel.tsx`
- `src/components/marketing/open-spot-booking-page.tsx`
- `src/components/dashboard/dashboard-shell.tsx`
- Dashboard pages
- Metadata and SEO copy
- Any docs mentioning `Open Spot`
- Any public CTA pages

## Required solution

1. Audit every visible user-facing occurrence of:
   - `Open Spot`
   - `2e Chance RDV`
   - `2e chance rendez-vous`
   - `Deuxième chance RDV`
   - `2ie chance rendez vous`

2. Standardize visible public product copy to **2e Chance RDV**.

3. Keep technical file names unchanged unless renaming them is low-risk and clearly useful. Do not break imports.

4. Update SEO metadata:
   - title
   - description
   - any marketing headline if needed

5. Preserve the product positioning:
   - SMS-first cancellation recovery
   - appointment-based local businesses
   - merchant stays in control
   - manual confirmation required
   - no customer app

6. Ensure Vistaire is not mentioned or mixed into this product.

7. Do not add unnecessary abstractions. Make minimal safe edits.

## Integration requirements

- Ensure all imports still resolve.
- If component names still include `OpenSpot`, decide whether to keep them temporarily as technical names or rename safely. Prefer not to rename unless it is simple and low-risk.
- If you rename files, update every import.
- Do not change database identifiers in this phase.

## Security and quality requirements

- No secrets.
- No new dependencies.
- No fake features.
- No behavior changes beyond naming/copy.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run build
```

Also search the repo after changes for old public naming variants.

Report every remaining occurrence of `Open Spot` and explain whether it is intentionally kept as a technical identifier or must be fixed later.

## Completion criteria

This phase is complete only when the visible public app no longer feels split between two product names.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.