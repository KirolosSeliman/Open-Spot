# Phase 9 — Manual Validation Transaction and Confirmation Workflow

## Goal

Implement safe, persistent manual merchant validation.

## Problem to solve

The current responses queue allows local UI status changes only. It does not persist confirmation, does not enforce one selected customer, does not write audit logs, and does not send confirmation/unavailable messages.

## Required solution

1. Inspect:
   - `src/app/dashboard/responses/page.tsx`
   - `src/components/dashboard/responses-queue.tsx`
   - cancellation detail page
   - `src/types/database.ts`
   - booking request schema
   - opening offer schema
   - SMS provider abstraction
   - existing RPC `validate_opening_offer` type if present

2. Implement a server-side validation action or RPC.

3. The validation action must:
   - require authenticated user;
   - require organization membership;
   - verify role permission;
   - verify opening belongs to organization;
   - verify target offer/request belongs to opening;
   - verify the reply is eligible;
   - set selected customer/request to confirmed/selected;
   - prevent duplicate confirmation beyond opening capacity;
   - record validated/confirmed timestamp;
   - record validator user ID if schema supports it;
   - record recovered value;
   - calculate/store commission estimate if applicable;
   - update opening status to filled if capacity reached;
   - write audit log;
   - optionally create outbound confirmation SMS using simulator;
   - optionally create unavailable SMS records for non-selected respondents, depending on product decision.

4. Default behavior for unavailable messages:
   - do not auto-send unless product settings clearly allow it;
   - show merchant-controlled action if not implemented.

5. Update UI:
   - responses shown by timestamp order;
   - selected/confirmed state from database;
   - confirmation button disabled when opening is filled;
   - clear modal warning that confirmation is manual and final.

## Transaction safety

The validation operation must be atomic. Use a database transaction/RPC where possible.

Race condition to prevent:
- two staff users confirm two different clients at the same time for a one-capacity opening.

If capacity > 1 is supported, enforce capacity correctly.

## Security requirements

- Never validate from client-only state.
- Never trust client-provided organization ID.
- Never allow staff from another organization to validate.
- Never confirm opted-out customers if they opted out before validation.
- Audit every validation.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

Add tests or SQL checks for:
- one confirmation only for capacity one;
- second validation blocked;
- cross-tenant validation blocked;
- recovered value stored;
- commission estimate stored;
- audit log written;
- no automatic first-reply confirmation.

## Completion criteria

This phase is complete only when merchant validation is real, persistent, race-safe, auditable, and does not automatically confirm the first respondent.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.