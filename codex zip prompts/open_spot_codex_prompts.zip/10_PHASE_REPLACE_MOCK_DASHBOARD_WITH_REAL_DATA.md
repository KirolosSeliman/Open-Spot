# Phase 10 — Replace Mock Dashboard Data With Real Data Progressively

## Goal

Progressively replace mock dashboard data with real organization-scoped Supabase data.

## Problem to solve

Many dashboard pages still import `@/lib/dashboard/mock-data`. This makes the product look functional while not actually managing the merchant’s real data.

## Required solution

1. Inspect all imports of `@/lib/dashboard/mock-data`.

2. Replace mock data page by page, prioritizing:
   - dashboard overview;
   - clients;
   - services;
   - waitlist;
   - cancellations/openings;
   - responses;
   - messages;
   - settings.

3. Keep pages safe and useful even when there is no data:
   - empty states;
   - loading behavior where needed;
   - error states;
   - no fake counts;
   - no fake revenue.

4. Every query must:
   - use the active authenticated organization;
   - rely on RLS and server-side membership checks;
   - avoid exposing cross-tenant data;
   - avoid client-side-only filtering for security.

5. Do not remove all demo data if it is still needed for public marketing mockups. Keep marketing mockups isolated from authenticated dashboard data.

6. Add clear labels if a route remains demo-only.

## Integration requirements

- Dashboard shell should show real organization name.
- Dashboard metrics should come from real tables.
- Clients page should show real customers and consent state.
- Services page should show real services.
- Waitlist page should show real waitlist entries and QR/public link.
- Responses page should show real inbound replies/booking requests.
- Cancellation detail should show real opening, messages, recipients, replies, and confirmed customer.

## Security requirements

- Do not query by organization ID supplied in URL unless membership is verified.
- Do not expose phone numbers outside the organization.
- Do not show SMS bodies to unauthorized users.
- Do not allow unauthenticated dashboard access.
- Respect role permissions for sensitive actions.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

Search after changes:

```bash
grep -R "mock-data" -n src
```

Remaining uses of mock data must be limited to marketing/demo-only contexts and documented.

## Completion criteria

This phase is complete only when the authenticated dashboard no longer presents fake operational data as real business state.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.