# Phase 8 — Inbound SMS Webhook, STOP Handling, and Reply Persistence

## Goal

Make inbound SMS webhook handling real and persistent.

## Problem to solve

The existing inbound route classifies messages but does not persist inbound messages, does not update STOP consent, and does not create/update booking requests for positive replies.

## Required solution

1. Inspect:
   - `src/app/api/sms/inbound/route.ts`
   - `src/lib/sms/inbound.ts`
   - `src/lib/sms/factory.ts`
   - `src/lib/supabase/service.ts`
   - `src/types/database.ts`
   - SMS message schema
   - consent schema
   - opening/offer/booking request schema
   - audit log schema

2. Implement complete inbound handling.

3. The webhook must:
   - verify provider signature;
   - parse inbound message;
   - normalize phone numbers;
   - classify body;
   - persist inbound `sms_messages`;
   - identify the organization/customer/opening context safely;
   - handle STOP/ARRET/UNSUBSCRIBE/CANCEL immediately;
   - update consent to `opted_out`;
   - write audit log for opt-out;
   - for positive replies OUI/YES/1, create or update the related response/booking request;
   - rank or allow ordering by actual received timestamp;
   - never confirm automatically.

4. If the inbound message cannot be linked to an opening:
   - still persist the message if possible;
   - mark it as unknown/unlinked;
   - do not create a booking request;
   - do not fail silently.

5. If Supabase service role is missing:
   - local/dev may return a safe diagnostic;
   - production must fail loudly because inbound SMS cannot be lost silently.

## STOP handling requirements

Supported opt-out keywords:
- STOP
- UNSUBSCRIBE
- CANCEL
- ARRET
- accented variants after normalization if possible

Parser must trim whitespace and be case-insensitive.

An opt-out must exclude the customer from all future cancellation-recovery sends.

## Positive reply requirements

Supported positive replies:
- YES
- OUI
- 1

Positive reply creates interest only. It never confirms the appointment.

## Security requirements

- Verify webhook signatures for real providers.
- Simulator may bypass signature only in local/simulator mode.
- Do not expose secrets.
- Do not trust inbound body without validation.
- Do not allow inbound webhook to mutate unrelated organization data.
- Avoid duplicate booking requests for repeated replies.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

Add tests for:
- STOP;
- ARRET;
- lowercase/whitespace variants;
- OUI/YES/1;
- unknown reply;
- duplicate positive reply;
- unlinked inbound message;
- missing service role behavior;
- provider verification failure.

## Completion criteria

This phase is complete only when inbound SMS messages are safely persisted and STOP/OUI behavior affects real app state.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.