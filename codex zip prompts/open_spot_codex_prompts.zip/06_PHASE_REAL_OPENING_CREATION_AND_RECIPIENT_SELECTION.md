# Phase 6 — Real Opening Creation and Eligible Recipient Selection

## Goal

Replace the fake “new cancellation” demo flow with a real persisted opening creation flow.

## Problem to solve

The current “Nouvelle annulation” page prepares a mock SMS from client-side state and mock data. It does not create an opening, does not persist selected recipients, does not enforce server-side consent, and does not create audit records.

## Required solution

1. Inspect:
   - `src/app/dashboard/new-cancellation/page.tsx`
   - `src/components/dashboard/new-cancellation-flow.tsx`
   - `src/lib/dashboard/message-generation.ts`
   - Supabase database types
   - services/customers/consents/waitlist schema
   - organization current workspace helper
   - SMS provider abstraction

2. Convert the flow into a real server-backed workflow.

3. The merchant should be able to:
   - choose service;
   - choose date/time;
   - choose duration/end time;
   - enter estimated recovered value;
   - add optional offer/discount text;
   - select audience criteria;
   - preview eligible recipients;
   - preview SMS message;
   - confirm before sending/preparing.

4. Server-side logic must:
   - require authenticated user;
   - require active organization membership;
   - validate role permissions;
   - create an `opening`;
   - select only eligible customers with current `opted_in` consent;
   - exclude `needs_consent` and `opted_out`;
   - create recipient/offer records;
   - generate message text safely;
   - write audit log for opening creation and prepared audience.

5. Do not send real SMS in this phase unless the project already has a safe simulator send path ready. If SMS sending is not yet safe, prepare records with status `draft` or `ready_to_send`.

6. Remove or clearly isolate mock data from this page. If demo mode is kept, it must be explicit and must not be mixed with real dashboard behavior.

## Product requirements

- The first reply must never be auto-confirmed.
- Merchant must review before SMS sends.
- Show why excluded contacts were excluded if safe:
  - no consent;
  - opted out;
  - inactive;
  - not matching service.

## Security requirements

- Never trust client-provided organization ID.
- Never trust client-provided consent status.
- Never send/select based only on client-side filters.
- Validate all values server-side.
- Prevent cross-organization service/customer selection.
- Record audit logs.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

Add tests where possible for:
- no eligible customers;
- opted-out excluded;
- needs-consent excluded;
- cross-tenant customer cannot be selected;
- invalid service rejected;
- opening created for active organization only.

## Completion criteria

This phase is complete only when creating a cancellation/opening results in real safe persisted data and an eligible audience computed server-side.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.