# Phase 7 — SMS Simulator Send and Message Records

## Goal

Connect the opening workflow to the SMS simulator and persist outbound SMS messages safely.

## Problem to solve

The SMS abstraction and simulator exist, but the dashboard flow does not actually create outbound SMS records or call the provider in a complete workflow.

## Required solution

1. Inspect:
   - `src/lib/sms/provider.ts`
   - `src/lib/sms/simulator.ts`
   - `src/lib/sms/factory.ts`
   - `src/lib/sms/plivo.ts`
   - `src/lib/sms/twilio.ts`
   - `src/lib/dashboard/message-generation.ts`
   - opening/offer/message tables
   - environment config
   - previous phase opening creation code

2. Implement safe simulator-first sending.

3. The send action must:
   - require authenticated user and organization membership;
   - verify role permission;
   - load opening and recipients server-side;
   - verify the opening belongs to active organization;
   - verify every recipient is still opted in at send time;
   - exclude opted-out/needs-consent customers;
   - generate or use approved message body;
   - call `createSmsProvider()`;
   - default to simulator;
   - create one `sms_messages` record per outbound send;
   - update recipient/offer send status;
   - write audit log.

4. If `SMS_PROVIDER` is not simulator:
   - real sending must be blocked unless `ALLOW_REAL_SMS_SENDS=true`;
   - provider credentials must be present;
   - webhook verification strategy must be configured;
   - otherwise fail safely.

5. Do not implement real Twilio/Plivo sending in this phase unless all safety gates are already done. The priority is simulator send records.

## Message safety requirements

Outbound message must include:
- business identity;
- opening time/context;
- reply instruction;
- manual validation language;
- opt-out instruction if required.

Do not use misleading urgency.
Do not imply guaranteed booking.
Do not send discounts not configured by merchant.

## Security requirements

- Provider credentials server-only.
- Never call SMS provider from client component.
- Never expose service role key.
- Never allow client to provide arbitrary recipient phone list.
- Consent check must happen immediately before send.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

Add tests for:
- simulator provider returns simulated message ID;
- real provider blocked without explicit enable flag;
- opted-out excluded at send time;
- send action cannot cross organization;
- outbound message record created.

## Completion criteria

This phase is complete only when a merchant can safely send simulated SMS for a real opening and the system records every outbound message.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.