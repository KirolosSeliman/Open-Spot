# 07 — Phase Cancellation Targeting Prep

## Role

You are a senior product engineer, senior data analyst, senior systems architect, senior Supabase engineer, and senior QA lead.

You are working only on **Phase 7: preparing cancellation targeting based on service interests**.

Do not implement real SMS sending. This phase prepares the data selection logic that future cancellation alerts will use.

## Specific Problem

The reason to collect service interests is to target relevant clients when a merchant has a last-minute opening.

The app needs a reliable helper/query that can find eligible clients for an opening based on service interest and SMS consent.

## Goal

Build a targeting helper that returns eligible waitlist clients for a given service/opening.

Eligibility should consider:
- organization scope;
- active waitlist entry;
- opted-in SMS consent;
- valid phone;
- selected service interest;
- active service;
- optional general waitlist fallback if no specific service interest exists.

## Files to Read First

Read:

- opening/cancellation workflow files
- waitlist service interest data model
- customers and consent schema
- dashboard waitlist data loaders
- tests

## Targeting Rules

A client is eligible if:
1. belongs to same organization;
2. has active waitlist entry;
3. has SMS consent opted_in;
4. phone is valid;
5. selected services include the opening service;
6. not opted_out.

If general waitlist fallback is allowed:
- clients without selected services may be included only if product decision says general waitlist members are eligible.

Do not include:
- opted_out clients;
- needs_consent clients;
- inactive waitlist entries;
- clients from another organization;
- inactive services;
- duplicate rows for same customer.

## Implementation Requirements

Create a server-side helper, for example:

```text
src/lib/waitlist/targeting.ts
```

or match existing project structure.

Function example:

```ts
getEligibleWaitlistClientsForService({ organizationId, serviceId })
```

It must return typed data for future alert creation.

Do not expose this logic directly to public client code.

## Tests Required

Add tests for:
1. opted_in client with matching service is eligible.
2. needs_consent client is not eligible.
3. opted_out client is not eligible.
4. inactive waitlist entry is not eligible.
5. non-matching service is not eligible.
6. cross-organization service/client is not eligible.
7. duplicate service interests do not duplicate returned clients.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Manual QA

If UI exists:
1. Create services.
2. Add multiple clients with different service interests.
3. Create/select a service opening.
4. Confirm eligible clients preview only shows relevant opted-in clients.

If no UI exists, document helper-level test only.

## Final Report

Report:
1. Targeting helper created.
2. Eligibility rules.
3. Tests added.
4. How future cancellation workflow should use it.
5. Validation results.
6. Remaining targeting limitations.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
