# 00 — Master Codex Protocol: Service Interests, QR Signup, and Waitlist Targeting

## Role

You are a senior problem analyst, senior data analyst, senior product strategist, senior full-stack software engineer, senior systems architect, senior Supabase/PostgreSQL engineer, senior Next.js App Router engineer, senior React/TypeScript engineer, senior UX engineer, senior SMS consent/compliance-aware engineer, and senior QA lead.

You are working on **2e Chance RDV**, a focused B2B SaaS for appointment-based local businesses that helps recover last-minute cancellations by SMS.

Your mission is to correct and improve the public QR/waitlist signup flow so that it collects structured service interests from the merchant's configured services, instead of collecting dirty free-text service interests or irrelevant scheduling preferences.

## Current Product Problem

The current public join/waitlist form includes:
- a free-text **Service interest** input;
- a **Preferred days** field;
- a checkbox like **I am open to last-minute offers or discounts**;
- an SMS consent checkbox.

This is not aligned with the product.

2e Chance RDV is a last-minute appointment recovery app. A customer who scans the QR/signup link is already expressing interest in last-minute openings. Asking preferred days and a generic discount/open-offers checkbox adds friction and weakens the product logic.

Service interests must come from the merchant's real configured services and must be selectable as one or multiple clickable options.

## Product Boundaries

2e Chance RDV is not:
- a CRM;
- a full booking platform;
- a marketplace;
- a generic SMS marketing tool;
- a Calendly clone;
- a Square clone;
- an email marketing platform;
- part of Vistaire.

Do not overbuild. Build the minimum reliable, secure, structured service-interest foundation for later cancellation targeting.

## Global Goal

Implement a safe, secure, efficient, tested, deployable flow where:

1. Merchant configures active services in dashboard/settings.
2. Public QR/signup page loads that merchant's active services.
3. Customer selects one or multiple services as clickable choices.
4. Preferred days is removed.
5. The last-minute offers/discount checkbox is removed.
6. SMS consent remains explicit and required for SMS eligibility.
7. Submission creates/updates customer, consent, waitlist entry, and selected service interests safely.
8. Dashboard displays selected service interests cleanly.
9. Future cancellation targeting can use selected service interests.

## Required Phase Order

Work one phase at a time.

1. `01_PHASE_SERVICE_MODEL_AND_EXISTING_CODE_AUDIT.md`
2. `02_PHASE_MERCHANT_SERVICE_SETTINGS.md`
3. `03_PHASE_MULTI_SERVICE_INTEREST_DATA_MODEL.md`
4. `04_PHASE_PUBLIC_QR_FORM_SERVICE_MULTISELECT_UX.md`
5. `05_PHASE_PUBLIC_SIGNUP_BACKEND_INTEGRATION.md`
6. `06_PHASE_WAITLIST_DASHBOARD_SERVICE_INTERESTS.md`
7. `07_PHASE_CANCELLATION_TARGETING_PREP.md`
8. `08_PHASE_FINAL_QA_DEPLOYMENT_AUDIT.md`

## Phase Discipline

For each phase:

1. Read relevant files before editing.
2. Identify the specific problem for that phase.
3. Separate confirmed facts from assumptions.
4. Identify root cause.
5. Implement the smallest safe durable solution.
6. Keep code secure and organization-scoped.
7. Avoid unnecessary dependencies.
8. Add or update tests.
9. Run validation commands.
10. Produce a final phase report.
11. Move to the next phase only if the current phase is safe, secure, efficient, working, tested, and documented.

Do not move to the next phase while the current one has unresolved issues.

## Global Security Rules

Never:
- expose service-role keys to client code;
- trust organization_id from browser input;
- allow cross-organization service selection;
- allow public signup to read private merchant/customer data;
- mark a customer as SMS eligible without explicit consent;
- weaken RLS to make a feature easier;
- send real SMS in these phases;
- drop or truncate existing data;
- silently hide errors.

## Global Data Rules

Service interests must be structured.

Do not rely on comma-separated text as the primary targeting model. It is acceptable to keep old text fields for backward compatibility, but new service targeting must use service IDs tied to the merchant's active services.

Every selected service must:
- belong to the target organization;
- be active;
- be validated server-side;
- be stored in a structure that supports multi-select.

## Global UX Rules

The public signup page should be simple:

- Name
- Mobile phone
- Preferred language
- Services you are interested in
- SMS consent checkbox
- Join waitlist button

Remove:
- Preferred days
- Generic last-minute offers/discount checkbox

Use simple copy:
- “Which services are you interested in? Select all that apply.”
- “Quels services vous intéressent ? Choisissez un ou plusieurs services.”

## Mandatory Validation Commands

Run after every code-changing phase:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If migrations are added:

```bash
supabase migration list --linked
supabase db push
```

If Supabase CLI is unavailable, clearly report it and give the exact command the user must run.

## Final Report After All Phases

After all phases, report:
1. Services/settings behavior.
2. Public QR form behavior.
3. Removed fields.
4. Consent behavior.
5. Database changes.
6. Tests added.
7. Security guarantees.
8. Manual QA result.
9. Deployment commands.
10. Remaining risks.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
