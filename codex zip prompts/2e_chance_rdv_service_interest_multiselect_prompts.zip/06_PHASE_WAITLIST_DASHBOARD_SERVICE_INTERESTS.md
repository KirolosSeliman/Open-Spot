# 06 — Phase Waitlist Dashboard Service Interests

## Role

You are a senior product engineer, senior dashboard UX engineer, senior data analyst, senior full-stack engineer, senior Supabase engineer, and senior QA lead.

You are working only on **Phase 6: displaying and filtering service interests in the dashboard**.

Do not implement actual SMS sending. Do not build full cancellation targeting yet.

## Specific Problem

After customers choose services on the public signup form, merchants must be able to see and use those service interests in the dashboard.

If selected services are stored but not visible, the feature is not operational.

## Goal

Update dashboard clients/waitlist views to show selected service interests clearly.

## Files to Read First

Read:

- dashboard clients pages
- dashboard waitlist pages
- service data loaders
- public signup backend integration
- join table migration
- tests

## UI Requirements

In customer/waitlist tables/cards, show:
- client name;
- phone;
- consent status;
- source;
- selected service interests as chips;
- created date;
- waitlist status.

If multiple services selected:
- show multiple chips.
- keep layout readable on mobile.

If no service selected:
- show “General waitlist” or equivalent.

## Filter Requirements

Add simple filters if not already present:
- service;
- consent status;
- source;
- waitlist status;
- search by name/phone.

Do not overbuild advanced segmentation now.

## Data Requirements

Queries must:
- be organization-scoped;
- join service interest table safely;
- avoid showing another organization's services;
- avoid fetching unnecessary large datasets.

## Tests Required

Add/update tests for:
1. service chips rendering.
2. no service = general waitlist.
3. filter by service.
4. filter by consent.
5. organization scoping.
6. no demo/fake clients in real dashboard.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Manual QA

1. Submit QR form selecting multiple services.
2. Open dashboard waitlist.
3. Confirm client appears.
4. Confirm selected services appear as chips.
5. Filter by one selected service.
6. Confirm client appears.
7. Filter by unselected service.
8. Confirm client does not appear.
9. Confirm mobile layout.

## Final Report

Report:
1. Dashboard pages changed.
2. Query/data changes.
3. Filters added.
4. Tests added.
5. Validation results.
6. Remaining display limitations.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
