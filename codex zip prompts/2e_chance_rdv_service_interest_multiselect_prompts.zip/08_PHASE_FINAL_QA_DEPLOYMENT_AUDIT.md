# 08 — Final QA and Deployment Audit for Service Interest Multi-Select

## Role

You are a senior release engineer, senior QA lead, senior security reviewer, senior data integrity analyst, senior performance reviewer, and senior production-readiness architect.

You are working only on **Phase 8: final QA and deployment audit for the service interest multi-select implementation**.

Do not add features. Do not redesign. Verify the system is safe, secure, efficient, tested, and deployable.

## Scope

Audit the entire service-interest flow:

1. Merchant service settings.
2. Multi-service interest data model.
3. Public QR form.
4. Public signup backend validation.
5. Dashboard display.
6. Targeting prep.
7. Consent behavior.
8. Security boundaries.
9. Tests.
10. Deployment readiness.

## Required Audit Areas

### Product Behavior

Confirm:
- merchant can configure services;
- public form shows active services;
- customer can select one or multiple services;
- preferred days is removed;
- discount/offers checkbox is removed;
- SMS consent remains explicit;
- selected services appear in dashboard;
- future targeting can use selected services.

### Data Integrity

Confirm:
- selected services are structured, not free-text primary data;
- service IDs belong to organization;
- inactive services cannot be selected;
- duplicates are prevented;
- existing waitlist entries are not broken;
- no data was destructively removed.

### Security

Confirm:
- no service-role key client-side;
- no organization_id trusted from browser;
- public form does not expose private data;
- cross-organization service submission is rejected;
- RLS is not weakened.

### UX

Confirm:
- public form is mobile-friendly;
- service selected state is clear;
- empty services state is understandable;
- consent copy is clear;
- errors are user-friendly.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If migrations were added:

```bash
supabase migration list --linked
supabase db push
```

Optional local-only destructive test:

```bash
supabase db reset
```

Only run `supabase db reset` on a disposable local database. Never on linked production/staging.

## Manual QA Script

1. Login as merchant.
2. Add services:
   - Coupe
   - Coloration
   - Barbe
   - Manucure
   - Pose gel
3. Deactivate one service.
4. Open public QR link logged out.
5. Confirm active services only appear.
6. Select multiple services.
7. Confirm preferred days is gone.
8. Confirm discount/offers checkbox is gone.
9. Check SMS consent.
10. Submit.
11. Open dashboard waitlist.
12. Confirm customer appears.
13. Confirm selected services appear as chips.
14. Confirm deactivated service does not appear.
15. Confirm no service from another organization appears.
16. Confirm no real SMS was sent.

## Deployment Checklist

Before deploy:
- migrations pushed;
- tests pass;
- build passes;
- no service-role leak;
- public route tested;
- mobile tested;
- no destructive SQL;
- rollback plan known.

## Rollback Strategy

If frontend issue:
- revert form/dashboard changes.

If migration issue:
- create a forward-fix migration.
- do not reset production.
- do not drop data.

If public signup issue:
- temporarily hide QR link or disable public route with a safe maintenance message while forward fix is deployed.

## Final Report

Produce:
1. Release readiness verdict.
2. Features completed.
3. Files changed.
4. Migrations added.
5. Security findings.
6. Consent behavior.
7. Validation results.
8. Manual QA results.
9. Deployment commands.
10. Remaining risks.

## Acceptance Criteria

The implementation is ready only if:
- merchant-configured services drive the public form;
- multi-select works;
- preferred days is removed;
- discount/offers checkbox is removed;
- SMS consent remains explicit;
- data is organization-scoped;
- dashboard shows selected services;
- tests pass;
- build passes;
- migrations are safe.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
