# 04 — Phase Public QR Form Service Multi-Select UX

## Role

You are a senior UX engineer, senior frontend engineer, senior React/TypeScript engineer, senior accessibility reviewer, senior product strategist, and senior QA lead.

You are working only on **Phase 4: public QR form service multi-select UX**.

Do not change the backend write logic yet except for types or minimal form plumbing. Do not implement cancellation targeting in this phase.

## Specific Problem

The public QR form currently uses a free-text `Service interest` input and asks unnecessary questions like preferred days and discount/offers.

This produces dirty data and adds friction.

## Goal

Replace the public form UX with a clean service multi-select sourced from active merchant services.

The form should show:
- Name
- Mobile phone
- Preferred language
- Service choices from merchant settings
- SMS consent checkbox
- Join waitlist button

Remove:
- Preferred days
- “I am open to last-minute offers or discounts” checkbox
- free-text service interest as the main service targeting input

## Files to Read First

Read:

- public join/waitlist route file
- public form component
- service query/data loader
- QR code route/page
- phone input component
- tests

## UX Requirements

### Service Multi-Select

Show active services as clickable choices.

Use one of:
- checkbox cards;
- selectable chips;
- button-style toggles with hidden inputs;
- accessible checkbox list.

Requirements:
- customer can select one or more services;
- selected state is visually clear;
- works on mobile;
- accessible by keyboard;
- labels are clear;
- submits selected service IDs.

Suggested copy:
- English: “Which services are you interested in? Select all that apply.”
- French: “Quels services vous intéressent ? Choisissez un ou plusieurs services.”

### Empty Service State

If merchant has no active services, allow a general waitlist signup unless the product explicitly requires services.

Suggested copy:
“This business has not configured service options yet. You can still join the general waitlist.”

### Remove Fields

Remove:
- Preferred days input.
- Discount/offers checkbox.

Do not remove SMS consent checkbox.

## Accessibility Requirements

- Use real checkbox inputs or buttons with correct `aria-pressed`/state.
- Every service option must be focusable or associated with a focusable control.
- Do not use clickable divs.
- Keep visible focus styles.
- Provide validation message if service selection is required.

## Tests Required

Add/update tests for:
1. public form renders active services.
2. inactive services are not shown.
3. selected services are submitted.
4. preferred days field no longer exists.
5. discount/offers checkbox no longer exists.
6. SMS consent remains present.
7. empty service state works.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Manual QA

1. Configure services as merchant.
2. Open public QR link logged out.
3. Confirm service options appear.
4. Select multiple services.
5. Confirm selected state.
6. Confirm preferred days is gone.
7. Confirm discount/offers checkbox is gone.
8. Confirm SMS consent checkbox remains.
9. Confirm mobile layout is usable.

## Rollback Strategy

Revert form UI changes. No DB rollback should be needed in this phase.

## Final Report

Report:
1. Form route/component changed.
2. Fields removed.
3. Multi-select behavior.
4. Accessibility decisions.
5. Tests added.
6. Validation results.
7. Remaining UX limitations.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
