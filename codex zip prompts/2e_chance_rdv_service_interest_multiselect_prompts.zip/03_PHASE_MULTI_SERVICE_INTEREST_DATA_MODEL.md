# 03 — Phase Multi-Service Interest Data Model

## Role

You are a senior Supabase/PostgreSQL engineer, senior data analyst, senior backend engineer, senior systems architect, and senior QA lead.

You are working only on **Phase 3: multi-service interest data model**.

Do not build the public form UI yet. Do not build cancellation targeting yet. This phase is only about creating the durable data structure required for multiple selected services.

## Specific Problem

A client may be interested in multiple services. A free-text field or single service_id does not support clean targeting.

The product needs structured many-to-many service interests for waitlist entries or customers.

## Goal

Add a safe, additive, organization-scoped data model to store one or multiple service interests selected during QR/public signup.

## Files to Read First

Read:

- all `supabase/migrations/*.sql`
- schema for services, customers, sms_consents, waitlist_entries, audit_logs
- public signup RPC/server action
- current tests
- `src/lib/organization/current.ts`

## Preferred Data Model

Create a join table if it does not exist, for example:

```sql
public.waitlist_entry_services
```

Suggested columns:
- id uuid primary key default gen_random_uuid()
- organization_id uuid not null references public.organizations(id) on delete cascade
- waitlist_entry_id uuid not null references public.waitlist_entries(id) on delete cascade
- service_id uuid not null references public.services(id) on delete cascade
- created_at timestamptz not null default now()
- unique(waitlist_entry_id, service_id)

Add useful indexes:
- organization_id, service_id
- waitlist_entry_id

If the existing architecture makes `customer_service_interests` more appropriate, justify the choice. The preferred target for cancellation alerts is waitlist entries, so `waitlist_entry_services` is usually more direct.

## Backward Compatibility

If `waitlist_entries.service_id` already exists:
- do not drop it;
- keep it for backward compatibility;
- optionally populate it with the first selected service;
- use the new join table as the source of truth for multiple interests.

Do not break existing rows.

## Security Requirements

- Enable RLS if the rest of the schema uses RLS.
- Policies must be organization-scoped.
- Public signup should not require broad anon table access.
- Server actions/RPC should validate service ownership before inserting.

## Migration Requirements

Create a new additive migration.

Never:
- drop existing customer/waitlist data;
- truncate;
- remove old service_id;
- weaken existing RLS;
- grant broad anon access.

## Tests Required

Add tests to verify:
1. migration is additive.
2. join table exists.
3. unique(waitlist_entry_id, service_id) exists.
4. indexes exist.
5. no destructive SQL.
6. selected service must belong to same organization.
7. duplicate selections do not duplicate rows.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If migration added:

```bash
supabase migration list --linked
supabase db push
```

## Manual QA

After migration:
1. Confirm table exists.
2. Confirm duplicate service selections are prevented.
3. Confirm RLS/policies match the project model.
4. Confirm existing waitlist entries remain intact.

## Final Report

Report:
1. Table added.
2. Why this model was chosen.
3. Backward compatibility strategy.
4. RLS/security behavior.
5. Tests added.
6. Validation results.
7. Remaining data model risks.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
