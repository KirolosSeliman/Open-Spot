# 05 — Phase Public Signup Backend Integration

## Role

You are a senior backend engineer, senior Supabase/PostgreSQL engineer, senior full-stack software engineer, senior security reviewer, senior SMS consent-aware engineer, and senior QA lead.

You are working only on **Phase 5: backend integration for public signup service selections**.

Do not redesign the public form. Do not implement cancellation targeting yet. This phase makes the form submission write correct structured data securely.

## Specific Problem

The public signup form will submit selected service IDs. The backend must validate them and store them safely.

The backend must not trust client-supplied service IDs blindly.

## Goal

When a customer submits the public QR/signup form:

1. Resolve organization from slug or public token.
2. Validate name, phone, preferred language.
3. Validate selected service IDs.
4. Ensure every selected service belongs to the organization.
5. Ensure every selected service is active.
6. Create or update customer.
7. Create or update SMS consent.
8. Create waitlist entry.
9. Insert join rows for selected services.
10. Keep SMS eligibility tied to explicit consent.

## Files to Read First

Read:

- public signup server action/RPC
- QR/public signup route
- service multi-select form component
- schema/migration from Phase 3
- `src/lib/customers/phone.ts`
- `src/lib/supabase/server.ts`
- tests

## Backend Requirements

### Organization Resolution

Public signup must resolve the organization using:
- slug, or
- safe public token if implemented.

Do not accept organization_id directly from the browser as source of truth.

### Service Validation

For each submitted service ID:
- check it exists;
- check it belongs to the resolved organization;
- check it is active.

If invalid IDs are submitted:
- reject safely with a user-friendly error; or
- ignore invalid IDs and log internally if that matches project style.
Prefer rejection if there is a possible tampering signal.

### Customer Upsert

Upsert by:
- organization_id + phone_e164.

Do not duplicate same phone within same organization.

### Consent

If consent checkbox is checked:
- status = opted_in;
- consent_text recorded;
- consented_at set.

If consent checkbox is required and missing:
- reject submission.

Do not silently mark as opted_in without explicit checkbox.

### Waitlist Entry

Create or update a waitlist entry.
Associate selected services through the join table.

If no services selected and general waitlist is allowed:
- create general waitlist entry without service rows.

## Security Requirements

Never:
- expose service-role keys client-side;
- trust service IDs without validation;
- show private merchant/customer data publicly;
- allow cross-organization service insertion;
- bypass consent rules.

## Tests Required

Add/update tests for:
1. selected service belongs to organization.
2. selected service must be active.
3. cross-organization service ID is rejected.
4. duplicate service IDs do not create duplicate join rows.
5. consent is required.
6. missing consent does not create opted-in consent.
7. customer upsert by phone.
8. waitlist entry is created.
9. general waitlist behavior if no service selected.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If migrations were added:

```bash
supabase migration list --linked
supabase db push
```

## Manual QA

1. Open public QR link.
2. Select multiple services.
3. Submit with consent.
4. Confirm customer created/updated.
5. Confirm consent opted_in.
6. Confirm waitlist entry created.
7. Confirm selected service interest rows exist.
8. Try tampering with service ID from another organization if possible.
9. Confirm it is rejected or ignored safely.

## Final Report

Report:
1. Server action/RPC changed.
2. Validation rules.
3. Tables written.
4. Consent behavior.
5. Security behavior.
6. Tests added.
7. Validation results.
8. Remaining backend risks.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
