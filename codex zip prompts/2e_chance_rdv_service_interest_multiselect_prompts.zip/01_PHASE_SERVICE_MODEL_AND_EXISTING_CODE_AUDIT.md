# 01 — Phase Service Model and Existing Code Audit

## Role

You are a senior problem analyst, senior data analyst, senior Supabase/PostgreSQL engineer, senior full-stack software engineer, senior systems architect, and senior QA lead.

You are working only on **Phase 1: auditing the current service model, QR signup form, and waitlist data flow**.

Do not implement UI changes yet. Do not create migrations yet unless a build-breaking issue requires a minimal correction. This phase is for rigorous inspection and planning.

## Specific Problem

The public QR/waitlist form currently collects service interest as free text and includes fields that do not fit a last-minute appointment recovery product.

Before implementing the fix, you must identify:
- how services are currently modeled;
- how public signup currently works;
- where service interest is stored;
- whether the schema supports one service or multiple services;
- how QR/public signup resolves organizations;
- how consent is handled.

## Files to Read First

Read all relevant code before editing:

- public waitlist/join route files, likely under:
  - `src/app/join/**`
  - `src/app/waitlist/**`
  - `src/app/**/[slug]/**`
- QR code dashboard page files.
- service dashboard/settings files.
- `src/lib/organization/current.ts`
- `src/lib/supabase/server.ts`
- `src/lib/customers/phone.ts`
- waitlist signup server actions or RPC helpers.
- all `supabase/migrations/*.sql`
- existing tests.
- `package.json`.

## Questions to Answer

Before implementing later phases, answer:

1. Where is the public QR/waitlist form implemented?
2. What route is used for the customer signup page?
3. How does the route identify the merchant/organization?
4. Does a `services` table already exist?
5. Does `services` include organization_id, name, active, duration, price?
6. Can merchants already create/edit/deactivate services?
7. Does `waitlist_entries` include a `service_id` field?
8. Does the system support multiple service interests per waitlist entry?
9. Is service interest currently stored as free text?
10. Where is SMS consent stored?
11. Does QR signup call a secure server action/RPC?
12. Does public signup expose any private data?
13. Are there tests for public signup, consent, and service interests?

## Root Cause Analysis Required

Identify why the current implementation is insufficient:

- Free-text service interest creates dirty data.
- Preferred days do not fit last-minute opening alerts.
- The discount/offers checkbox duplicates the intent of joining the waitlist.
- Future targeting needs structured service IDs, not text.

## Deliverable of This Phase

Produce an audit report in the final Codex response with:

1. Confirmed files/routes.
2. Current data model.
3. Current service limitations.
4. Current public form limitations.
5. Current security assumptions.
6. Recommended architecture for Phase 2 and Phase 3.
7. Whether a migration is needed.
8. Whether merchant service settings already exist.

## Tests/Validation

If no code changes are made, no validation commands are required, but still inspect enough to avoid guessing.

If any code is changed, run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Completion Gate

Do not move to Phase 2 until:
- the real public signup route is identified;
- the service model is understood;
- the data model gap is clear;
- the safest multi-service architecture is chosen.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
