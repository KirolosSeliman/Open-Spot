# 02 — Phase Merchant Service Settings

## Role

You are a senior product engineer, senior UX engineer, senior full-stack software engineer, senior Next.js/React/TypeScript engineer, senior Supabase engineer, and senior QA lead.

You are working only on **Phase 2: merchant service configuration**.

Do not modify the public QR form yet except if necessary to keep build stability. The goal is to ensure the merchant can manage the list of services that will later appear on the QR signup page.

## Specific Problem

The public QR form should not ask customers to type services manually. It should show services configured by the merchant.

Therefore the dashboard/settings must provide a reliable way for the merchant to create, edit, and deactivate offered services.

## Goal

Implement or verify merchant service management.

The merchant must be able to:
- view services;
- add service;
- edit service;
- deactivate/reactivate service;
- define enough service data for future targeting.

## Files to Read First

Read:

- `src/app/dashboard/services/**`
- `src/app/dashboard/settings/**`
- service-related components/actions if present
- `src/lib/organization/current.ts`
- `src/lib/supabase/server.ts`
- migrations defining `services`
- tests for services if any

## Required Service Fields

Use existing schema if possible.

Minimum fields:
- name
- active
- duration_minutes if required by DB
- normal_price_cents if already available
- description optional

Do not overbuild categories, staff assignment, schedules, resources, or full booking logic in this phase.

## Security Requirements

All service writes must:
- require authenticated user;
- resolve organization from active workspace;
- never trust organization_id from the browser;
- be organization-scoped;
- use server actions or existing backend pattern;
- validate inputs server-side.

## UX Requirements

The services settings page should:
- be simple;
- show active/inactive state;
- allow quick creation;
- show empty state for new organizations;
- avoid making service setup feel like a full booking system.

Example empty state:
“Ajoutez les services que vos clients pourront choisir quand ils rejoignent votre liste SMS.”

## Tests Required

Add or update tests for:
1. service input validation.
2. service creation with active organization.
3. organization_id not accepted from browser.
4. deactivation/reactivation.
5. empty state behavior if testable.
6. no cross-organization service edit.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If migrations are added:

```bash
supabase migration list --linked
supabase db push
```

## Manual QA

1. Login as merchant.
2. Open services/settings page.
3. Add services:
   - Coupe
   - Coloration
   - Barbe
   - Manucure
   - Pose gel
4. Deactivate one service.
5. Confirm active services list is correct.
6. Confirm no other organization service is visible.

## Rollback Strategy

If only code changes, revert the commit. If migrations are added, use a forward-fix migration, not a destructive rollback.

## Final Report

Report:
1. Service settings route.
2. Data model used.
3. Server actions added/changed.
4. Security behavior.
5. Tests added.
6. Validation results.
7. Remaining limitations.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
