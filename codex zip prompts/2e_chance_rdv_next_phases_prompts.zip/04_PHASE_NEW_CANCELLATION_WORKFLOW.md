# 04 — Phase New Cancellation Workflow

## Role

You are a senior product engineer, senior full-stack software engineer, senior workflow architect, senior Supabase engineer, and senior QA lead.

You are working only on **Phase 4: implementing the New Cancellation workflow**.

Do not implement real SMS sending yet. This phase creates the cancellation/opening and prepares eligible clients.

## Problem Restatement

The core product action is: a merchant has a last-minute cancellation and wants to recover the spot.

Currently the dashboard has a “Nouvelle annulation” button, but the real operational workflow needs to exist.

## Goal

Implement an MVP workflow where the merchant can:

1. Create a cancellation/opening.
2. Select or define service/date/time/value.
3. See eligible waitlist clients.
4. Prepare an alert message.
5. Save the opening in Supabase.
6. Move toward SMS simulation in the next phase.

## Files to Read First

Read:

- Supabase migrations for:
  - `openings`
  - `opening_offers`
  - `services`
  - `customers`
  - `waitlist_entries`
  - `sms_consents`
- dashboard routes/components
- services/client/waitlist modules from previous phase
- organization/auth helpers
- tests

## Root Cause Analysis Required

Identify:

1. Which table represents a cancellation/opening.
2. Which status values already exist.
3. How opening offers are modeled.
4. How customers are linked to waitlist.
5. Which clients are eligible for alerting.
6. Whether the first responder is automatically confirmed anywhere.
7. Whether current code uses mock cancellation data.

## MVP Requirements

Create a route/page such as:

```text
/dashboard/cancellations/new
```

or use the existing route style.

Form fields:
- title;
- service;
- start date/time;
- end time or duration;
- estimated value;
- optional discount label;
- expiration time;
- internal note.

Eligible clients:
- active waitlist entries;
- opted-in consent only;
- matching service if service is selected;
- not opted out.

Message preview:
- generate a simple SMS draft;
- do not send yet;
- make clear it is preview/simulation until SMS phase.

Submit behavior:
- create an `openings` row;
- optionally create `opening_offers` rows for eligible clients with status `pending`;
- redirect to opening detail page.

## Critical Product Rule

The first client who replies “yes/oui” must **not** be automatically confirmed.

Merchant must always manually choose who to confirm.

## Security Requirements

- organization_id must come from active workspace;
- no client-controlled organization_id;
- require membership;
- no service role in client code;
- preserve RLS.

## Tests Required

Add tests for:

1. opening input validation;
2. eligible client filtering;
3. opted-out clients excluded;
4. needs-consent clients excluded;
5. first responder not auto-confirmed;
6. organization scoping.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If migrations are needed:

```bash
supabase migration list --linked
supabase db push
```

## Manual Test

1. Create service.
2. Create opted-in client.
3. Add client to waitlist.
4. Click “Nouvelle annulation”.
5. Create opening.
6. Confirm eligible client appears.
7. Confirm no SMS is actually sent.
8. Confirm opening appears on dashboard.

## Rollback Strategy

Revert code if no migration.  
If schema changes exist, use forward migration. Do not delete openings unless in disposable local test DB.

## Final Report

Report:

1. Workflow implemented.
2. Routes added/changed.
3. Tables written.
4. Eligibility rules.
5. Tests added.
6. Manual QA result.
7. What remains for SMS phase.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
