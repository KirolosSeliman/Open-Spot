# 03 — Phase Services, Clients, and Waitlist Foundation

## Role

You are a senior full-stack engineer, senior product engineer, senior Supabase/PostgreSQL engineer, senior UX form designer, senior SMS consent analyst, and senior QA lead.

You are working only on **Phase 3: implementing the operational foundation for services, clients, and waitlist entries**.

Do not implement SMS sending yet. Do not implement full cancellation workflow yet.

## Problem Restatement

A cancellation recovery product cannot work without real business data:
- services;
- clients;
- SMS consent;
- waitlist entries.

The merchant needs a safe way to add and manage these before creating a cancellation alert.

## Goal

Implement MVP CRUD foundation for:

1. Services.
2. Clients.
3. Waitlist entries.
4. Consent-aware client status.

The goal is not a full CRM. Keep it simple and operational.

## Files to Read First

Read:

- Supabase migrations defining:
  - `services`
  - `customers`
  - `sms_consents`
  - `waitlist_entries`
- `src/app/dashboard/**`
- existing routes for clients/waitlist/services if any
- `src/lib/customers/phone.ts`
- `src/lib/customers/phone-format.ts` if exists
- `src/components/forms/phone-input.tsx` if exists
- organization/current auth helpers
- tests

## Root Cause Analysis Required

Identify:

1. Which tables already exist.
2. Which RLS policies exist.
3. Which pages already exist and whether they use mock data.
4. Which fields are required.
5. How SMS consent is represented.
6. Whether phone uniqueness is per organization.
7. Whether server actions or route handlers are current project style.

## MVP Requirements

### Services

Merchant can create a service with:
- name;
- duration minutes;
- normal price cents or dollars converted to cents;
- active flag.

### Clients

Merchant can create a client with:
- full name;
- phone number;
- optional email;
- preferred language;
- notes.

Phone input must reuse existing normalization/formatting.

### SMS Consent

Client creation must allow:
- opted in;
- needs consent;
- opted out.

Be conservative:
- do not send SMS to opted-out or needs-consent clients;
- do not imply legal compliance beyond the product’s actual logic.

### Waitlist

Merchant can add a client to waitlist with:
- optional service interest;
- preferred days;
- preferred time windows;
- discount interest;
- notes;
- active/paused status if already modeled.

## Architecture Requirements

Prefer server actions for form submissions if that matches the current codebase.

All writes must:
- require authenticated user;
- require organization membership;
- write organization_id from the active workspace, not from client-controlled input;
- validate input server-side;
- return user-friendly errors.

## Security Requirements

Never:
- accept organization_id from the browser as source of truth;
- use service role from client code;
- allow cross-organization writes;
- bypass RLS casually;
- store fake test data in production paths.

## Tests Required

Add tests for:

1. service input validation;
2. client input validation;
3. phone normalization;
4. consent state behavior;
5. waitlist input validation;
6. organization_id not accepted from client payload.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If migrations are needed:

```bash
supabase migration list --linked
supabase db push
```

## Manual Test

1. Create service.
2. Create client with `5142494425`.
3. Confirm phone stores as `+15142494425`.
4. Mark client opted in.
5. Add client to waitlist.
6. Dashboard counts update.
7. Confirm opted-out client is clearly excluded from future SMS targeting.

## Rollback Strategy

If only code changes, revert commit.  
If migrations are added, do not delete client data; create forward fix migrations.

## Final Report

Report:

1. Tables used.
2. Routes/pages implemented.
3. Server actions created.
4. Validation rules.
5. Consent behavior.
6. Tests added.
7. Manual QA result.
8. Remaining limitations.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
