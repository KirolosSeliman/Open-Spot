# 06 — Phase Real SMS Provider Compliance Prep

## Role

You are a senior SMS systems engineer, senior compliance-aware product engineer, senior backend engineer, senior security reviewer, and senior QA lead.

You are working only on **Phase 6: preparing real SMS provider integration safely**.

Do not send real SMS until configuration, consent, STOP handling, rate limits, and environment separation are ready.

## Problem Restatement

The product eventually needs real SMS, but sending real messages too early is risky and can cause compliance, cost, trust, and deliverability problems.

## Goal

Prepare a safe provider integration layer without accidentally sending real SMS in development or demo mode.

## Files to Read First

Read:

- current SMS simulation code
- `sms_messages` table schema
- `sms_consents` table schema
- environment config files
- server action / route handler patterns
- dashboard cancellation workflow
- tests

## Root Cause Analysis Required

Identify:

1. Where SMS sending should live.
2. How provider credentials are configured.
3. How consent is checked.
4. How STOP/unsubscribe is represented.
5. How daily/monthly limits are modeled, if at all.
6. Whether outbound sends are currently simulated only.
7. What must be true before real sends are allowed.

## Requirements

Build a provider abstraction, for example:

```text
src/lib/sms/provider.ts
src/lib/sms/simulation-provider.ts
src/lib/sms/real-provider.ts
```

Provider behavior:
- simulation mode by default;
- real provider only when env vars are present and explicit flag enables it;
- never send SMS from client components;
- all sends occur server-side;
- every send checks consent;
- every send records `sms_messages`;
- failures are recorded safely.

## Compliance/Safety Requirements

Before sending:
- customer must be opted in;
- phone must be valid E.164;
- message must identify merchant/product if required by local rules;
- STOP/unsubscribe handling must be planned;
- rate/cost limits must exist or be intentionally documented.

Inbound STOP:
- if inbound message body is `STOP`, `ARRET`, `ARRÊT`, `UNSUBSCRIBE`, or equivalent:
  - update consent to opted_out;
  - do not send future messages.

Do not overclaim legal compliance. Build conservative safeguards.

## Tests Required

Add tests for:

1. provider defaults to simulation.
2. real provider cannot run without explicit env flag.
3. opted-out client is blocked.
4. needs-consent client is blocked.
5. invalid phone is blocked.
6. STOP updates consent.
7. send failure records error.
8. no service role is exposed client-side.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If migrations are needed:

```bash
supabase migration list --linked
supabase db push
```

## Manual Test

1. Ensure no real provider env vars -> simulation only.
2. Try sending to opted-in client -> simulated.
3. Try sending to opted-out client -> blocked.
4. Simulate STOP reply -> consent becomes opted_out.
5. Confirm no real SMS leaves the system.

## Rollback Strategy

Keep simulation as fallback. If real provider fails, disable env flag and continue simulation.

## Final Report

Report:

1. Provider architecture.
2. Env vars required.
3. Consent safeguards.
4. STOP handling.
5. Tests added.
6. Why no accidental real SMS can be sent.
7. Remaining real provider setup tasks.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
