# 07 — Phase Final QA and Deployment Audit

## Role

You are a senior release engineer, senior QA lead, senior security reviewer, senior data integrity analyst, senior performance reviewer, and senior production-readiness architect.

You are working only on **Phase 7: final audit and deployment readiness**.

Do not add features. Do not redesign. Do not refactor broadly. Verify that the implemented phases are safe, secure, efficient, and deployable.

## Problem Restatement

The product has moved from demo UI toward a real operational MVP. Before showing it to a real merchant, the whole flow must be audited.

## Audit Scope

Review:

- dashboard routes
- demo/preview route
- onboarding
- services
- clients
- waitlist
- cancellation workflow
- SMS simulation
- manual validation
- Supabase migrations
- RLS assumptions
- tests
- environment variables
- build output

## Required Audit Areas

### Product Behavior

Confirm:
- real `/dashboard` no longer shows fake demo data;
- demo data is only in clearly marked demo/preview route;
- new merchant sees empty state and setup checklist;
- core flow is understandable.

### Data Integrity

Confirm:
- organization_id comes from active workspace;
- no user-controlled organization_id writes;
- data is scoped per organization;
- no manual fake rows are needed;
- recovered booking logic does not duplicate confirmations.

### Security

Confirm:
- service role is never exposed to client;
- auth-required pages are protected;
- RLS is not weakened;
- anon/public cannot read organization data;
- environment variables are safe.

### SMS Safety

Confirm:
- no accidental real SMS sending;
- simulation mode is default unless real provider is explicitly enabled;
- opted-out clients are blocked;
- STOP logic exists if implemented;
- consent status is respected.

### UX

Confirm:
- onboarding works;
- phone input works;
- auth navigation works;
- dashboard empty states work;
- mobile layout is usable.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If Supabase CLI available:

```bash
supabase migration list --linked
supabase db push
```

Optional local-only destructive test:

```bash
supabase db reset
```

Only run `supabase db reset` on disposable local dev database. Never run it on linked production/staging.

## Required Manual QA Script

1. Open `/`.
2. Click `Créer un compte`.
3. Create test user.
4. Confirm email if required.
5. Complete onboarding.
6. Confirm real `/dashboard` shows empty state.
7. Add service.
8. Add client.
9. Add client to waitlist.
10. Create cancellation.
11. Simulate alert.
12. Simulate replies.
13. Manually validate one respondent.
14. Confirm dashboard metrics update.
15. Sign out.
16. Sign in.
17. Confirm dashboard remains correct.
18. Test mobile layout.

## Deployment Checklist

Before deploy:

- migrations pushed;
- env vars configured;
- no service-role key in browser;
- build passes;
- tests pass;
- demo data separated;
- SMS real provider disabled unless intentionally ready;
- rollback plan written.

## Rollback Strategy

If frontend breaks:
- revert frontend commit.

If database migration breaks:
- do not reset production;
- create forward-fix migration.

If SMS provider misbehaves:
- disable real provider env flag;
- fall back to simulation.

## Final Report

Produce:

1. Release readiness verdict.
2. What works.
3. What remains demo/simulation.
4. Security findings.
5. Migration status.
6. Validation results.
7. Manual QA results.
8. Deployment commands.
9. Rollback plan.
10. Remaining risks before real merchant pilot.

## Acceptance Criteria

The work is deployable only if:

- real dashboard is not fake;
- onboarding works;
- services/clients/waitlist work;
- cancellation flow works;
- manual validation works;
- no real SMS is sent accidentally;
- tests pass;
- build passes;
- migration state is known;
- all remaining limitations are documented.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
