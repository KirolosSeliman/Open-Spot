# 01 — Phase Demo/Real Dashboard Separation

## Role

You are a senior product-minded full-stack engineer, senior UX architect, senior data analyst, and senior QA lead.

You are working only on **Phase 1: separating demo/preview dashboard data from the real client dashboard**.

Do not implement new SMS sending. Do not build the full clients/waitlist module yet. This phase is only about separating fake/demo data from real authenticated workspace pages.

## Problem Restatement

The current dashboard looks polished but appears to show example/demo data, such as fake clients, fake responses, fake recovered revenue, fake appointments, and a demo salon.

That is useful for sales preview, but it is unsafe and misleading for a real logged-in client.

A real client dashboard must:
- show real organization data;
- show empty states when no data exists;
- never present fake demo data as if it belongs to the client.

## Goal

Create a clean separation:

- `/dashboard` = real authenticated organization dashboard using real Supabase data or empty states.
- `/demo`, `/preview`, or `/dashboard-preview` = optional demo page using mock data.

## Files to Read First

Read before editing:

- `src/app/dashboard/**`
- `src/components/dashboard/**`
- `src/lib/dashboard/**`
- `src/lib/organization/current.ts`
- `src/lib/supabase/server.ts`
- `src/app/page.tsx`
- `src/components/layout/site-header.tsx`
- all files importing mock dashboard data
- tests related to dashboard, organization, auth, or routing

## Root Cause Analysis Required

Identify:

1. Which dashboard pages currently use mock data.
2. Where mock data is stored.
3. Which routes are protected by auth.
4. Which routes are demo/public preview.
5. Whether fake dashboard data is rendered inside `/dashboard`.
6. What real Supabase tables already exist.
7. What can be safely queried now without inventing data.

## Implementation Requirements

### 1. Separate mock data

Move or keep demo data only in a clearly named demo route/module, for example:

```text
/demo
/dashboard-preview
```

Mock data must not be used by `/dashboard` unless explicitly in a demo-only route.

### 2. Protect real dashboard

`/dashboard` must:
- require authenticated user if Supabase is configured;
- resolve active organization;
- query only organization-scoped data;
- show safe empty states if no rows exist.

### 3. Add clear empty state

For new organizations, show:
- welcome message using real organization name;
- setup checklist:
  - add services;
  - add clients;
  - create waitlist;
  - create first cancellation;
  - simulate SMS alert;
- zero metrics instead of fake metrics.

### 4. Keep demo available

If the preview UI is useful, keep it accessible separately and clearly labelled as demo.

Example labels:
- “Demo data”
- “Preview only”
- “Example dashboard”

### 5. Avoid breaking navigation

Existing dashboard nav should not break. Links can point to real placeholder pages if modules are not implemented yet, but they must not imply fake live data.

## Data Safety Requirements

Never:
- hardcode organization ID;
- show data from another organization;
- show demo clients in a real org dashboard;
- weaken RLS;
- use service role in client code;
- bypass membership checks.

## Tests Required

Add or update tests to ensure:

1. `/dashboard` does not import the mock dashboard data module.
2. Mock data is isolated to a demo/preview route.
3. dashboard data query functions require organization ID.
4. empty state copy exists for zero-data organizations.
5. dashboard route remains protected.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Manual Test

1. Create/login as a new user.
2. Create an organization.
3. Open `/dashboard`.
4. Confirm no fake clients appear.
5. Confirm no fake revenue appears.
6. Confirm setup checklist appears.
7. Confirm organization name is real.
8. Open demo/preview route if created.
9. Confirm demo data is clearly marked as demo.

## Rollback Strategy

Rollback is frontend/server-query only unless migrations are added. Revert dashboard separation commits if needed. Do not touch production data.

## Final Report

Report:

1. Root cause.
2. Routes changed.
3. Files changed.
4. Where demo data now lives.
5. What `/dashboard` now shows.
6. Validation results.
7. Manual QA result.
8. Remaining dashboard limitations.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
