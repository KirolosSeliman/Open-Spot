# 02 — Phase Real Dashboard Supabase Data and Empty States

## Role

You are a senior data analyst, senior backend engineer, senior full-stack engineer, senior Supabase/PostgreSQL engineer, and senior dashboard UX engineer.

You are working only on **Phase 2: connecting the real dashboard to Supabase data and empty states**.

Do not build the full client/waitlist CRUD yet. Do not implement real SMS sending. This phase builds reliable dashboard metrics and empty states from current tables.

## Problem Restatement

After demo data is separated, the real dashboard needs useful real metrics. A new organization may have zero data, and the dashboard must handle that gracefully.

## Goal

Build a real organization dashboard that uses organization-scoped Supabase queries to show:

- organization name;
- customers count;
- waitlist entries count;
- services count;
- openings count;
- pending replies count;
- recovered bookings count;
- recovered revenue estimate;
- SMS sent count;
- setup checklist.

If data is missing or zero, show clear empty states, not errors or fake values.

## Files to Read First

Read:

- `src/app/dashboard/**`
- `src/components/dashboard/**`
- `src/lib/organization/current.ts`
- `src/lib/supabase/server.ts`
- `src/lib/reports/**` if present
- current Supabase migrations defining tables
- dashboard tests

## Root Cause Analysis Required

Identify:

1. Existing tables and columns available.
2. Which metrics can be calculated safely now.
3. Which metrics are not meaningful yet.
4. Whether any table requires RLS policy changes.
5. Whether counts can be queried efficiently.
6. Whether current dashboard uses client or server components.

## Implementation Requirements

Create or update a server-side dashboard data loader, for example:

```text
src/lib/dashboard/real-data.ts
```

It should:

- accept organization ID;
- use Supabase server client;
- query only rows for that organization;
- use count queries where possible;
- avoid loading large row sets unnecessarily;
- return a typed object for dashboard UI.

Example returned shape:

```ts
type DashboardOverview = {
  organizationName: string;
  customersCount: number;
  waitlistEntriesCount: number;
  servicesCount: number;
  openingsCount: number;
  pendingRepliesCount: number;
  recoveredBookingsCount: number;
  recoveredRevenueCents: number;
  smsSentCount: number;
  setup: {
    hasServices: boolean;
    hasCustomers: boolean;
    hasWaitlistEntries: boolean;
    hasOpenings: boolean;
  };
};
```

## UX Requirements

For zero data, show:

- “Votre espace est prêt.”
- “Commencez par ajouter vos services et vos clients.”
- setup checklist with links.

Do not show:
- fake revenue;
- fake clients;
- fake SMS;
- fake recovered appointments.

## Security Requirements

- Do not use service role in client components.
- Do not query data without organization filter.
- Do not show another organization’s data.
- Do not weaken RLS.
- Keep protected route behavior.

## Efficiency Requirements

Use `select(..., { count: "exact", head: true })` where appropriate.  
Do not fetch entire tables to count rows.  
Only fetch recent rows if needed for display.

## Tests Required

Add/update tests for:

1. dashboard metric calculation helper;
2. zero-data state;
3. recovered revenue calculation if implemented;
4. no mock data import in real dashboard;
5. query helper requires organization ID.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Manual Test

1. New organization with no data -> dashboard shows zero metrics + setup checklist.
2. Organization with manually seeded local/dev test rows -> dashboard counts reflect rows.
3. Confirm no demo names appear.
4. Confirm page does not crash if optional tables are empty.

## Rollback Strategy

Revert dashboard data loader and UI changes. No data deletion required.

## Final Report

Report:

1. Data sources used.
2. Metrics implemented.
3. Empty states implemented.
4. Files changed.
5. Tests added.
6. Validation results.
7. Metrics not yet implemented and why.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
