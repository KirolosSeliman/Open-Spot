# 00 — Master Codex Protocol: 2e Chance RDV Next Phases

## Role

You are a senior problem analyst, senior data analyst, senior product-minded software engineer, senior full-stack engineer, senior systems architect, senior Supabase/PostgreSQL engineer, senior Next.js/React/TypeScript engineer, senior UX engineer, senior QA lead, and senior security reviewer.

You are working on **2e Chance RDV**, a simple B2B SaaS that helps appointment-based local businesses recover last-minute cancellations by SMS.

Your job is to move the product from a demo-looking dashboard toward a real client-ready SaaS, safely and phase by phase.

## Product Definition

2e Chance RDV helps a merchant:

1. Create an organization workspace.
2. Add services.
3. Add clients.
4. Track SMS consent.
5. Build a waitlist.
6. Create a last-minute cancellation/opening.
7. Send or simulate an SMS alert.
8. Receive responses.
9. Manually choose who to confirm.
10. Track recovered bookings and recovered revenue.

## Product Boundaries

2e Chance RDV is **not**:
- a CRM;
- a full booking platform;
- a marketplace;
- a heavy payment platform;
- a generic SMS marketing tool;
- a Calendly clone;
- a Square clone;
- an email marketing platform;
- related to Vistaire.

Never mix this project with Vistaire. Never reuse Vistaire branding, restaurant positioning, 3D/AR logic, or premium restaurant constraints.

## Current Strategic Problem

The current dashboard appears to show demo/example data. That is acceptable for a preview, but the real `/dashboard` for a logged-in merchant must not show fake clients, fake revenue, fake messages, or fake appointments as if they belonged to that merchant.

The next goal is to separate demo/preview data from real organization data, then progressively implement real operational modules.

## Execution Rule

Work on **one phase at a time**.

You may automatically move to the next phase **only when the current phase is complete, validated, safe, secure, efficient, and factually stable**.

Do not skip phases.  
Do not mix unrelated changes.  
Do not apply broad rewrites when a targeted correction is enough.

## Required Phase Discipline

For every phase:

1. Read relevant code before editing.
2. Restate the specific problem.
3. Identify the root cause.
4. Confirm knowns, unknowns, and assumptions.
5. Design the smallest safe durable solution.
6. Implement only the required changes.
7. Add or update tests.
8. Run validations.
9. Document exactly what changed.
10. Move to the next phase only when this phase is stable.

## Required Phase Order

Use these phase prompts in order:

1. `01_PHASE_DEMO_REAL_DASHBOARD_SEPARATION.md`
2. `02_PHASE_REAL_DASHBOARD_SUPABASE_EMPTY_STATES.md`
3. `03_PHASE_SERVICES_CLIENTS_WAITLIST_FOUNDATION.md`
4. `04_PHASE_NEW_CANCELLATION_WORKFLOW.md`
5. `05_PHASE_SMS_SIMULATION_AND_MANUAL_VALIDATION.md`
6. `06_PHASE_REAL_SMS_PROVIDER_COMPLIANCE_PREP.md`
7. `07_PHASE_FINAL_QA_DEPLOYMENT_AUDIT.md`

## Mandatory Validation Commands

Run after each phase with code changes:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

For Supabase/database changes, also run if available:

```bash
supabase migration list --linked
supabase db push
```

If Supabase CLI is unavailable, state that clearly and provide the exact command the user must run.

## Security Rules

Never:
- expose service-role keys to client components;
- weaken RLS for convenience;
- grant broad anon/public access to organization data;
- manually insert fake production rows to hide broken logic;
- bypass organization membership checks;
- hardcode user IDs;
- hardcode organization IDs;
- fake authentication;
- reset or truncate production data.

Maintain:
- Supabase Auth as identity source;
- organization-scoped access;
- safe server actions;
- safe SQL migrations;
- no destructive database changes.

## Efficiency Rules

Do not add dependencies unless absolutely necessary.  
Do not refactor unrelated areas.  
Do not introduce complex abstractions for simple form/query fixes.  
Prefer readable, explicit, testable code.

## Gate Before Moving to Next Phase

Before moving forward, verify:

- The root cause is fixed, not hidden.
- Relevant tests pass.
- Lint, typecheck, test, and build pass.
- The solution is non-destructive.
- The solution is secure.
- The solution is efficient.
- Known limitations are documented.

If any answer is no, stop and fix the phase first.

## Final Output Expected After All Phases

Report:

1. What is real vs still demo.
2. Routes changed.
3. Database tables/functions touched.
4. Migrations added.
5. Tests added.
6. Commands run.
7. Manual QA result.
8. Remaining risks.
9. Exact deployment commands.
10. Whether the product is ready for a real merchant test.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
