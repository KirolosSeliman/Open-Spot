# 05 — Phase SMS Simulation and Manual Validation

## Role

You are a senior full-stack engineer, senior SMS workflow architect, senior product safety analyst, senior Supabase engineer, and senior QA lead.

You are working only on **Phase 5: SMS simulation, replies, and manual validation**.

Do not connect a real SMS provider in this phase. This phase builds the safe internal simulation workflow first.

## Problem Restatement

Before paying for or sending real SMS, the app needs a reliable internal simulation that proves the core business logic:

1. merchant sends alert;
2. clients reply;
3. replies are ordered;
4. merchant manually chooses who gets the spot;
5. the system records recovered booking/revenue.

## Goal

Implement a safe simulation path that mirrors the future real SMS flow without sending actual SMS.

## Files to Read First

Read:

- `openings`
- `opening_offers`
- `sms_messages`
- `booking_requests`
- `audit_logs`
- cancellation/opening pages
- dashboard pages
- existing RPC `validate_opening_offer`
- tests

## Root Cause Analysis Required

Identify:

1. How opening offers are created.
2. How replies are represented.
3. Whether response order is stored.
4. Whether booking confirmation is manual.
5. Whether any code auto-confirms first respondent.
6. Whether `validate_opening_offer` is safe and idempotent enough.
7. Whether simulated SMS should write to `sms_messages`.

## MVP Simulation Requirements

Implement:

1. “Simulate sending alert”
   - updates offers from `pending` to `sent`;
   - writes outbound `sms_messages` with provider `simulation`;
   - does not call a real provider.

2. “Simulate reply”
   - merchant/tester can create a reply for a client;
   - writes inbound `sms_messages`;
   - updates offer status to `responded`;
   - stores response text and timestamp;
   - assigns response rank/order.

3. Manual validation
   - merchant selects one respondent;
   - calls or uses safe validation logic;
   - selected offer becomes `selected`;
   - other active offers become `rejected`;
   - opening becomes `filled`;
   - booking_request is created;
   - recovered value/commission estimate stored if modeled;
   - audit log created.

## Critical Rule

Never auto-confirm based only on first reply.

The UI may sort by first response, but final selection must be a merchant action.

## Security Requirements

- require authenticated org member;
- organization-scoped queries only;
- no service role in client code;
- no real SMS provider credentials;
- simulation clearly marked.

## Tests Required

Add tests for:

1. simulate send creates outbound messages.
2. simulate reply creates inbound message.
3. replies are ordered.
4. first reply is not automatically selected.
5. manual validation selects exactly one offer.
6. manual validation rejects other eligible offers.
7. repeated validation does not create duplicate confirmed bookings.
8. organization scoping is enforced.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If migrations are needed:

```bash
supabase migration list --linked
supabase db push
```

## Manual Test

1. Create service/client/waitlist.
2. Create cancellation.
3. Simulate send.
4. Simulate two replies.
5. Confirm reply order.
6. Manually choose one respondent.
7. Confirm opening status is filled.
8. Confirm one booking request exists.
9. Confirm dashboard recovered metrics update.
10. Confirm no real SMS was sent.

## Rollback Strategy

Simulation data can be tested in local/dev. Do not delete production data. If needed, add a forward migration or revert UI/server action code.

## Final Report

Report:

1. Simulation flow.
2. Manual validation behavior.
3. Tables updated.
4. Tests added.
5. Manual QA result.
6. What remains for real SMS provider integration.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
