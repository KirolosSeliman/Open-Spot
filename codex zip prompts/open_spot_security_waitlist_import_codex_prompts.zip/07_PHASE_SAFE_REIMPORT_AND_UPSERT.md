# 07 — Phase: Safe Re-import and Upsert Behavior

## Target problem

Merchants will update their customer spreadsheet over time and re-import it.

Open Spot must update the site safely when a new spreadsheet version is imported, without creating duplicates, corrupting consent, or overwriting protected fields.

A local Excel file cannot automatically update the site by itself. The MVP should support manual re-import. Future automatic sync can be designed later for Google Sheets, Excel Online/OneDrive, or booking platforms.

## Target solution

Implement safe manual re-import behavior:

- match existing customers by organization + normalized phone;
- create new customers;
- update safe fields on existing customers;
- preserve protected consent states;
- record import batch summary if schema supports it;
- report exactly what happened.

## Scope

Implement manual re-import/update behavior.

Do not implement:

- Google Sheets sync;
- Excel Online sync;
- OneDrive integration;
- Square/Fresha/Booksy/GOrendezvous integrations;
- background cron sync.

## Required diagnosis

Inspect existing database schema and server actions for:

- `customers`
- `sms_consents`
- `waitlist_entries`
- `import_batches`
- `import_rows`
- `audit_logs`

If import batch tables do not exist, decide whether to add minimal safe tables now or use existing structures and document missing audit tables.

## Required upsert rules

For each validated row:

1. Normalize phone.
2. Scope lookup by `organization_id`.
3. If no customer exists:
   - create customer;
   - create consent record according to validated consent state;
   - optionally create waitlist entry if the import flow explicitly does that.
4. If customer exists:
   - update safe customer fields such as name/language/source if allowed;
   - do not duplicate the customer;
   - update service interest/waitlist only if explicit and safe.
5. If existing consent is `opted_out`:
   - preserve `opted_out`;
   - do not change to `opted_in` through import unless explicit proof exists and code records a new consent/audit event.
6. If imported row lacks consent proof:
   - use `needs_consent`.
7. If imported row is invalid:
   - do not write it;
   - return row-level error.

## Import report

After import, show:

- created count;
- updated count;
- skipped count;
- invalid count;
- duplicate count;
- consent warnings;
- opted-out preserved count.

## Transaction/data integrity

Use a safe server-side transaction/RPC if available.

Avoid partial updates when import fails midway.

If full transaction is not possible with current architecture, document exactly what is atomic and what is not.

## Security constraints

- Import must be organization-scoped.
- Authenticated user must belong to the organization.
- Role must be allowed to import.
- Do not accept organization ID blindly from the client.
- Do not expose service role client-side.
- Do not import into another organization.
- Do not allow unauthenticated import.

## Testing requirements

Test:

- first import creates records;
- second import updates same phones without duplicates;
- duplicate row in same file is flagged;
- existing `opted_out` remains `opted_out`;
- missing consent proof becomes `needs_consent`;
- user from org A cannot import into org B;
- invalid rows do not write.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

Manual tests:

1. Import `clients_v1.csv`.
2. Re-import `clients_v2.csv` with changed names/languages.
3. Confirm updates occurred.
4. Confirm no duplicate customers.
5. Confirm opted-out is preserved.
6. Confirm report is accurate.

## Definition of done

This phase is complete only if manual re-import updates site data safely and predictably, with no duplicate/customer consent corruption.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
