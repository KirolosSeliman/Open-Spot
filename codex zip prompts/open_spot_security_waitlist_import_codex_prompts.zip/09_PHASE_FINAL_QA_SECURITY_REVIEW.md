# 09 — Phase: Final QA, Security, and Integration Review

## Target problem

After route security, RLS, sidebar, waitlist, import, re-import, and export changes, the product needs a strict senior-level QA/security review.

Do not ship if auth, tenant isolation, import safety, or consent safety are not verified.

## Target solution

Run a full integration review and fix only blockers introduced or exposed by the previous phases.

## Full checklist

### Auth and private routes

Verify unauthenticated users cannot access:

- `/dashboard`
- `/clients`
- `/waitlist` merchant route
- `/services`
- `/messages`
- `/settings`
- `/team`
- `/subscription`

Verify signed-in user without organization goes to `/onboarding`.

Verify signed-in user with organization reaches dashboard.

### Server authorization

Verify every private server action/API route checks:

- auth user;
- organization membership;
- role if needed;
- valid organization scope.

### RLS

Verify:

- RLS enabled on organization-scoped tables;
- no broad anonymous private access;
- user A cannot read user B organization data;
- staff cannot update restricted settings if roles exist.

### Waitlist

Verify:

- waitlist is not just full customer list;
- opted-out customers are not eligible;
- needs-consent customers are not eligible for SMS;
- filters work;
- sidebar active state is correct.

### Import

Verify:

- upload UI is not text input;
- CSV parser handles valid/invalid files;
- mapping works;
- preview works;
- validation summary works;
- confirm import writes only valid rows;
- re-import updates without duplicates;
- opted-out is preserved;
- missing consent becomes needs_consent.

### Export

Verify:

- template export downloads correct CSV;
- client export downloads current org customers only;
- CSV escaping works;
- empty export works.

### Secrets

Verify:

- `.env.local` is ignored;
- no secrets committed;
- service role only appears in server-only code;
- no SMS provider secret exposed.

### Quality

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

Also run any project-specific formatting/migration checks if available.

## Required final verdict

Use one of:

- `READY FOR NEXT PHASE`
- `NOT READY — BLOCKERS REMAIN`

Do not mark ready if:

- private routes leak;
- RLS is missing/weak;
- service role is client-exposed;
- import can corrupt consent;
- re-import creates uncontrolled duplicates;
- user A can access user B data;
- build/typecheck/lint/tests fail due to changes.

## Required final report

Return:

```md
# Final QA Review

## Verdict

## What was verified

## What was fixed

## Validation commands run

## Manual checks performed

## Security results

## Data integrity results

## UX results

## Remaining risks

## Deployment notes

## Rollback plan

## Next recommended phase
```

## Next phase after this pack

Only after this review is clean should the project move to actual SMS simulator/send/reply flow.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
