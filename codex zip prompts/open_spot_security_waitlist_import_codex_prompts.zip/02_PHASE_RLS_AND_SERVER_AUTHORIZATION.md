# 02 — Phase: RLS and Server Authorization Audit

## Target problem

Even if Next.js routes are protected, Open Spot is not secure unless Supabase Row Level Security and server-side authorization prevent cross-organization data access.

A user must never access another organization's customers, waitlist, services, messages, imports, settings, or reports.

## Target solution

Audit and harden RLS policies and server-side authorization for all organization-scoped tables and actions.

## Tables to inspect

Inspect every organization-scoped table, including if present:

- `organizations`
- `profiles`
- `organization_members`
- `organization_settings`
- `services`
- `customers`
- `sms_consents`
- `waitlist_entries`
- `import_batches`
- `import_rows`
- `openings`
- `opening_offers`
- `sms_messages`
- `booking_requests`
- `audit_logs`

If a table does not exist, report it. Do not create unrelated tables in this phase unless needed to fix a security bug.

## Required checks

For each table:

1. Is RLS enabled?
2. Are SELECT policies organization-scoped?
3. Are INSERT policies safe?
4. Are UPDATE policies role-aware?
5. Are DELETE policies either absent or owner/admin-only?
6. Does policy logic use active organization membership?
7. Can anonymous users read or write private data?
8. Can staff update organization settings or roles?
9. Can a user elevate themselves to owner?
10. Can an import change `opted_out` to `opted_in` without explicit proof?

## Required server-side authorization checks

Find all server actions and API routes that read/write private data.

For each sensitive action, verify:

- authenticated user exists;
- active profile exists;
- organization membership exists;
- role is sufficient;
- organization ID is not blindly trusted from the client;
- input validation exists;
- errors do not leak private data.

## Required SQL verification

Add or document SQL checks for:

```sql
select schemaname, tablename, rowsecurity
from pg_tables
where schemaname = 'public'
order by tablename;
```

and:

```sql
select schemaname, tablename, policyname, permissive, roles, cmd
from pg_policies
where schemaname = 'public'
order by tablename, policyname;
```

## Required implementation

Fix only security issues found in RLS or server authorization.

Do not overbuild member management, billing, SMS, or analytics in this phase.

## Security constraints

- Never disable RLS to make code work.
- Never create a policy like `using (true)` on private tables.
- Never grant broad anon access to private tables.
- Never expose `SUPABASE_SERVICE_ROLE_KEY` to client components.
- Never allow role escalation from client input.
- Never allow cross-tenant reads or writes.
- Never make public waitlist routes expose internal data.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

Manual/database tests:

1. Create user A with organization A.
2. Create user B with organization B.
3. Verify user A cannot read user B data.
4. Verify user B cannot read user A data.
5. Verify staff cannot update settings/roles if roles exist.
6. Verify anonymous users cannot query private tables.
7. Verify service-role use is server-only.

## Definition of done

This phase is done only if:

- RLS is enabled on private organization tables;
- policies are least-privilege;
- server actions/API routes verify membership;
- two-user tenant isolation is verified or manual steps are provided;
- route security and database security are both aligned.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
