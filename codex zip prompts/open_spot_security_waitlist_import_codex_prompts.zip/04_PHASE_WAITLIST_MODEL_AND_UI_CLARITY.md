# 04 — Phase: Waitlist Model and UI Clarity

## Target problem

The waitlist screen must be clear and operational.

The waitlist is not just a generic client list. It represents customers who are potentially eligible for last-minute cancellation alerts based on consent, service interest, status, language, availability preferences, source, and optional discount interest.

## Target solution

Clarify and harden the waitlist model, UI labels, filtering, and data rules without implementing SMS sending.

## Required domain definition

In Open Spot:

- `customers` = all contacts belonging to an organization.
- `sms_consents` = proof/status of SMS eligibility.
- `waitlist_entries` = operational interest/eligibility records for last-minute alerts.
- `eligible members` = waitlist entries/customers that match current filters and consent rules.

A customer may exist without being eligible for SMS. A waitlist entry must not bypass consent rules.

## Required diagnosis

Inspect:

- waitlist page;
- waitlist form;
- filters;
- database schema for customers/consents/waitlist;
- server actions/API for adding waitlist entries;
- validation utilities;
- tests.

Determine:

1. Can non-consented customers be added to the operational waitlist?
2. Are `needs_consent` and `opted_out` blocked from SMS eligibility?
3. Are filters wired to real data or only UI?
4. Are service interest, days, windows, source, language, and discount interest represented consistently?
5. Does the UI explain what the waitlist is?

## Required implementation

Improve the UI and logic so that:

- the page title and copy explain the waitlist clearly;
- “Ajouter à la liste” only allows eligible/consented customers, or clearly labels customers requiring consent;
- `opted_out` customers cannot be treated as eligible;
- `needs_consent` customers cannot be treated as eligible for SMS;
- filters work correctly and are not misleading;
- empty states explain what to do next;
- eligible members list clearly shows why each customer is eligible or blocked;
- no SMS is sent in this phase.

## Suggested UI copy

French:

> La liste d'attente regroupe les clients qui ont accepté d'être contactés et qui souhaitent recevoir des alertes lorsqu'un créneau se libère.

English:

> The waitlist contains customers who agreed to be contacted and want alerts when a spot opens up.

## Data integrity constraints

- Do not create duplicate waitlist entries for the same organization/customer/service if the schema should prevent it.
- Do not change consent status from waitlist UI unless that action is explicit and audited.
- Do not silently include opted-out customers.
- Do not expose another organization’s customers.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

Manual tests:

1. Customer with `opted_in` can be eligible.
2. Customer with `needs_consent` is not SMS eligible.
3. Customer with `opted_out` is not SMS eligible.
4. Filters return expected entries.
5. Empty state is clear.
6. No cross-organization entries appear.

## Definition of done

This phase is complete only if the waitlist is conceptually clear, operationally useful, consent-safe, and not confused with the full customer list.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
