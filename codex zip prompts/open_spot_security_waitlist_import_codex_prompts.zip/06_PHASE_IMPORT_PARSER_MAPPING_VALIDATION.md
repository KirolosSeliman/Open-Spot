# 06 — Phase: Import Parser, Column Mapping, and Validation

## Target problem

Different businesses have different CSV/Excel column names. A plug-and-play import cannot assume every merchant has the exact same spreadsheet format.

The app must parse imports safely, let merchants map columns, preview rows, validate data, and show clear errors before writing anything to the database.

## Target solution

Implement a modular import parser and mapping layer for CSV first.

Add `.xlsx` only if the repo already has a safe dependency or if adding one is justified, minimal, and tested. If adding `.xlsx` support adds too much risk, document it as a future connector and implement CSV now.

## Required import flow

1. Merchant selects file.
2. App parses file locally or server-side safely, depending on architecture.
3. App detects headers.
4. App suggests column mapping.
5. Merchant confirms or adjusts mapping.
6. App shows preview.
7. App validates each row.
8. App shows summary:
   - valid rows;
   - invalid rows;
   - duplicates;
   - customers to create;
   - customers to update;
   - consent warnings.
9. No database write occurs until merchant confirms.

## Supported canonical fields

Support mapping to:

- `full_name`
- `phone`
- `preferred_language`
- `service_interest`
- `consent_status`
- `consent_source`
- `consent_date`
- `source`
- `notes` only if the data model already supports it safely

## Header aliases

Support common aliases such as:

- name, full name, client name, customer name, nom, nom client;
- phone, phone number, tel, telephone, téléphone, cell, mobile;
- language, langue;
- service, service interest, service_interest, service demandé;
- consent, consent status, sms consent, permission sms;
- source, origine;
- date, consent date, date consentement.

## Validation rules

For each row:

- name should not be empty unless the product explicitly supports phone-only contacts;
- phone must be normalized or rejected;
- preferred language must be `fr`, `en`, or blank/default;
- consent status must be one of allowed values;
- missing consent proof must become `needs_consent`;
- explicit opt-out must become or remain `opted_out`;
- duplicate phones within the file must be detected;
- dangerous formula-like spreadsheet cells should not be executed.

## Consent safety

Never import as `opted_in` unless the row contains explicit consent proof according to project rules.

Never silently switch `opted_out` to `opted_in`.

If the import file says `opted_in` but proof/source/date is missing, downgrade or flag to `needs_consent` according to the safest existing architecture.

## Data integrity

Do not write to database in parser-only preview steps.

Keep parser pure and testable if possible.

Return structured validation errors.

## Testing requirements

Add tests for:

- valid CSV;
- missing phone;
- invalid phone;
- duplicate phone;
- missing consent proof;
- opted-out preservation logic;
- French/English header aliases;
- unsupported file type;
- empty file;
- malformed CSV.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

Manual tests:

1. Upload valid CSV.
2. Upload CSV with French headers.
3. Upload CSV with invalid phone.
4. Upload CSV with duplicates.
5. Upload CSV with missing consent proof.
6. Confirm preview does not write to DB.

## Definition of done

This phase is complete only if the app can parse, map, preview, and validate imports safely without corrupting database data.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
