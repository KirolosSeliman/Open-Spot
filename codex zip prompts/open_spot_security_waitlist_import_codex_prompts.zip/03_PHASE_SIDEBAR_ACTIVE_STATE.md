# 03 — Phase: Sidebar Active State Fix

## Target problem

The screenshot shows the page title `Liste d'attente`, but the sidebar active item appears to be `Nouvelle annulation`.

This creates UX confusion and makes the dashboard feel unreliable.

## Target solution

Fix the sidebar active navigation state so it reflects the current route/page.

## Required diagnosis

Inspect:

- dashboard sidebar component;
- route definitions;
- layout components;
- navigation item configuration;
- current pathname usage;
- any hardcoded `active` value;
- localization labels.

Determine whether the bug is caused by:

- hardcoded active item;
- wrong pathname matching;
- route alias mismatch;
- stale state;
- server/client rendering mismatch;
- copied component state.

## Required implementation

Implement a clean route-based active state.

Requirements:

- `/dashboard` highlights `Tableau de bord`;
- new cancellation route highlights `Nouvelle annulation`;
- responses route highlights `Réponses`;
- cancellations/openings route highlights `Annulations`;
- clients route highlights `Clients`;
- waitlist route highlights `Liste d'attente`;
- QR/link route highlights `QR / lien`;
- messages route highlights `Messages`;
- services route highlights `Services`;
- statistics route highlights `Statistiques`;
- team route highlights `Équipe`;
- subscription route highlights `Abonnement`;
- settings route highlights `Paramètres`.

Use the actual routes found in the codebase, not guessed routes.

## Constraints

- Do not refactor the whole layout unless necessary.
- Do not break mobile sidebar behavior.
- Do not hardcode one page as active.
- Keep accessibility states if present.
- Preserve existing visual design.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

Manual tests:

1. Visit every sidebar route.
2. Confirm only the correct item is active.
3. Refresh each page.
4. Confirm active state remains correct.
5. Test mobile/responsive sidebar if present.

## Definition of done

This phase is complete only if sidebar active state is correct on every dashboard page and no private route access behavior regressed.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
