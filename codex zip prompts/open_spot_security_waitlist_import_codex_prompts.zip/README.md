# Open Spot — Security, Waitlist, and Modular Import Codex Prompt Pack

This pack contains phase-specific `.md` prompts for Codex.

Use them in this order:

1. `00_MASTER_CODEX_DIRECTOR.md`
2. `01_PHASE_PRIVATE_ROUTE_SECURITY.md`
3. `02_PHASE_RLS_AND_SERVER_AUTHORIZATION.md`
4. `03_PHASE_SIDEBAR_ACTIVE_STATE.md`
5. `04_PHASE_WAITLIST_MODEL_AND_UI_CLARITY.md`
6. `05_PHASE_IMPORT_EXPORT_MODULAR_UI.md`
7. `06_PHASE_IMPORT_PARSER_MAPPING_VALIDATION.md`
8. `07_PHASE_SAFE_REIMPORT_AND_UPSERT.md`
9. `08_PHASE_CLIENT_EXPORT_AND_TEMPLATE_EXPORT.md`
10. `09_PHASE_FINAL_QA_SECURITY_REVIEW.md`

Recommended workflow:

- Give Codex the master prompt first.
- Then give one phase prompt at a time.
- Do not let Codex jump to the next phase if lint/typecheck/test/build or security checks fail.
- Use a clean branch.
- Do not push `.env.local`.
- Review every diff before committing.

This pack is designed to fix:

- private route protection;
- RLS/server authorization;
- sidebar active state;
- waitlist clarity;
- modular import/export UI;
- CSV import mapping/validation;
- safe manual re-import update behavior;
- client/template export;
- final security QA.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
