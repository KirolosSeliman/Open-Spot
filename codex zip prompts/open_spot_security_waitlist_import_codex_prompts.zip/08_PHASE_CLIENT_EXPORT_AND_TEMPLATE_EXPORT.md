# 08 — Phase: Client Export and Template Export

## Target problem

The current `Client export` and `Template export` controls appear like text fields. Merchants will not understand what they do.

These should be clear export actions.

## Target solution

Implement two safe export actions:

1. Client export: downloads current organization customers as CSV.
2. Template export: downloads a clean CSV template with expected columns and optional example rows.

## Client export requirements

Create a CSV export for the current organization only.

Recommended columns:

- `full_name`
- `phone`
- `preferred_language`
- `consent_status`
- `consent_source`
- `consent_date`
- `source`
- `created_at`
- `updated_at`

Use actual available fields in the database. Do not invent unavailable data.

## Client export security

- Auth required.
- Organization membership required.
- Role permission required if roles exist.
- Export only current organization rows.
- Do not expose other organizations.
- Do not export secrets/internal IDs unless there is a clear reason.
- Avoid exporting unnecessary sensitive metadata.
- Ensure proper CSV escaping.

## Template export requirements

Generate a clean CSV template.

Recommended headers:

```csv
full_name,phone,preferred_language,service_interest,consent_status,consent_source,consent_date,source
```

Optional example row:

```csv
Maya Example,+15145550123,fr,Coupe femme,opted_in,qr_waitlist,2026-05-29,manual_template
```

If example rows are included, make it clear they are examples.

## UX requirements

Replace text field controls with buttons:

- `Download client CSV`
- `Download import template`

Show a short explanation for each.

Show loading/error state if export is server-backed.

## Technical requirements

- Use server-side export for private client data.
- Template export may be static/client-side if it contains no private data.
- Use correct content type and filename.
- Handle empty customer list gracefully.
- Keep code modular and testable.

## Testing requirements

Test:

- export with no customers;
- export with customers;
- CSV values escaped correctly;
- export only current organization;
- user from org A cannot export org B;
- template downloads expected headers.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

Manual tests:

1. Click template export.
2. Open downloaded template.
3. Click client export as org A.
4. Verify only org A customers.
5. Sign in as org B.
6. Verify org B does not see org A customers.

## Definition of done

This phase is complete only if client export and template export are understandable, secure, and useful for merchants.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
