# 05 — Phase: Modular Import/Export UI

## Target problem

The current import/export section appears to use text-field-like UI controls for CSV import, client export, and template export.

This is confusing and not professional. Import should be a modular file workflow, not a text input.

## Target solution

Replace the import/export area with a clean, modular, plug-and-play UI:

- file upload for import;
- clear import preview entry point;
- button for client export;
- button for template export;
- clear explanation of what each action does.

## Scope

This phase focuses on UI structure and user flow.

Do not implement heavy parser logic or database upsert in this phase unless the project already has it and the UI simply needs wiring.

Parser/mapping/validation are handled in later phases.

## Required diagnosis

Inspect:

- import/export component/page;
- current form inputs;
- client/export actions;
- template export code;
- database import actions if present;
- styling conventions.

Determine whether “CSV import,” “Client export,” and “Template export” are real features or placeholder inputs.

## Required UI behavior

### CSV import card

Replace text field with:

- file input or drag-and-drop zone;
- accepted file type display;
- clear helper text;
- selected file name;
- next action button: `Preview import` or equivalent;
- error state for unsupported file types.

### Client export card

Replace text field with:

- action button: `Download client CSV`;
- short explanation:
  - exports customers for the current organization only;
  - useful for backup, audit, corrections, or migration.

### Template export card

Replace text field with:

- action button: `Download CSV template`;
- short explanation:
  - gives the correct columns to fill before import;
  - helps merchants avoid malformed files.

## UX requirements

- Simple, clean, mobile-friendly.
- No fake disabled inputs that look like broken forms.
- Use accessible labels and buttons.
- Keep the dashboard visual style consistent.
- Show loading states if actions are async.
- Show safe error messages.
- Do not expose internal implementation details to merchants.

## Security constraints

- Do not parse files with unsafe eval.
- Do not upload files automatically before user confirms.
- Do not expose other organizations’ data.
- Do not leak service role keys in client code.
- Do not use client-only security to export data.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

Manual tests:

1. Import area shows file picker/dropzone, not a text input.
2. Selecting a CSV displays file name.
3. Unsupported file type shows error.
4. Client export appears as a button.
5. Template export appears as a button.
6. UI works on mobile width.
7. No console errors.

## Definition of done

This phase is complete only if the import/export interface is professional, understandable, accessible, and ready to connect to parser/export logic.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
