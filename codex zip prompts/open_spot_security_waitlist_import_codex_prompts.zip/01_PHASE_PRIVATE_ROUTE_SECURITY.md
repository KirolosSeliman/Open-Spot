# 01 — Phase: Private Route Security

## Target problem

The user believes direct dashboard access may be unsafe because visiting a private route may redirect directly into the dashboard.

This must be diagnosed properly. If the user was already authenticated, dashboard access may be expected. If unauthenticated users can access dashboard or private pages, that is a critical security bug.

## Target solution

Verify and harden private route protection across Open Spot.

Private routes must require authentication and valid organization context.

## Routes to classify

### Public routes

These may be public:

- `/`
- `/sign-in`
- `/sign-up`
- `/book-call/questions`
- public waitlist signup route only, if present, such as `/waitlist/[organizationSlug]` or equivalent public signup route

### Private routes

These must be protected:

- `/dashboard`
- `/clients`
- `/waitlist` when it is the merchant dashboard waitlist page
- `/services`
- `/messages`
- `/settings`
- `/team`
- `/subscription`
- `/responses`
- `/cancellations`
- `/new-cancellation`
- every route inside the private dashboard route group

## Required diagnosis

Before coding, determine:

1. Does the app have `middleware.ts`?
2. Does the app have a dashboard route group layout?
3. Are private pages server components or client components?
4. How does the app get Supabase sessions?
5. Are redirects implemented server-side?
6. Can a user without a session access private pages?
7. Can a signed-in user without organization access dashboard?
8. Can a signed-in user from organization A reach organization B data through a route parameter, query, server action, or API route?
9. Are any private checks only happening in client components?

## Required implementation

Implement a layered protection strategy:

1. Middleware may redirect unauthenticated users away from private route prefixes.
2. Every private dashboard layout/page must also verify the user server-side.
3. Signed-in users without an active organization must be redirected to `/onboarding`.
4. Server actions/API routes must verify:
   - authenticated user;
   - active profile;
   - active organization membership;
   - role if the action is sensitive.
5. Never rely only on client-side checks.
6. Never expose service role key client-side.

## Required behavior

Unauthenticated user:

- visiting `/dashboard` redirects to `/sign-in`;
- visiting `/clients` redirects to `/sign-in`;
- visiting `/waitlist` merchant route redirects to `/sign-in`;
- visiting `/services` redirects to `/sign-in`;
- visiting `/messages` redirects to `/sign-in`;
- visiting `/settings` redirects to `/sign-in`;
- visiting `/team` redirects to `/sign-in`;
- visiting `/subscription` redirects to `/sign-in`.

Authenticated user without organization:

- visiting dashboard private routes redirects to `/onboarding`.

Authenticated user with active organization:

- can access private dashboard shell.

## Security constraints

- Do not put secrets in the browser.
- Do not make a fake auth bypass for development.
- Do not weaken RLS.
- Do not expose private data in public routes.
- Do not rely on localStorage as security.
- Do not trust route params as authorization.
- Do not only hide sidebar links; enforce server-side access.

## Validation

Run:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

Manual browser tests:

1. Open incognito window.
2. Visit every private route directly.
3. Confirm redirect to `/sign-in`.
4. Sign in with a user without organization.
5. Confirm redirect to `/onboarding`.
6. Sign in with a user with organization.
7. Confirm dashboard loads.
8. Log out.
9. Confirm private routes are blocked again.

## Definition of done

This phase is done only if:

- all private routes are blocked for unauthenticated users;
- dashboard is protected server-side;
- organization context is enforced;
- service role is server-only;
- build/typecheck/lint/tests pass or failures are unrelated and documented;
- manual test steps are included in the final report.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
