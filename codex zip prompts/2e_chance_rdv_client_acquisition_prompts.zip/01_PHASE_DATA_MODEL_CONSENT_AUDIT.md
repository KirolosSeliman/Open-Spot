
# 01 — Phase Data Model + Consent Audit

## Role

You are a senior Supabase/PostgreSQL engineer, senior data analyst, senior backend engineer, senior SMS consent/compliance-aware engineer, and senior systems architect.

You are working only on **Phase 1: auditing and hardening the data model for clients, consent, waitlist entries, and acquisition sources**.

Do not build UI in this phase except if needed to prevent build errors. Do not implement import or QR yet.

## Problem

Before adding clients through manual entry, Excel, QR, public links, or kiosk mode, the database must support safe, organization-scoped, consent-aware customer acquisition.

The risk is importing or collecting client data without knowing:
- source;
- consent status;
- phone validity;
- organization ownership;
- duplicate handling;
- waitlist relationship.

## Goal

Confirm or add the minimal database/model foundation required for:

- customers;
- SMS consents;
- waitlist entries;
- import batches;
- acquisition source tracking;
- duplicate detection by organization + phone;
- safe consent statuses;
- audit logs if already used in the project.

## Files to Read First

Read:

- all `supabase/migrations/*.sql`
- `src/lib/customers/phone.ts`
- `src/lib/organization/current.ts`
- `src/lib/supabase/server.ts`
- existing customer/waitlist/service modules
- existing tests
- `package.json`

## Root Cause Analysis Required

Before changing anything, identify:

1. Existing tables:
   - customers
   - sms_consents
   - waitlist_entries
   - import_batches
   - services
   - audit_logs
2. Existing unique constraints.
3. Existing RLS policies.
4. Existing consent statuses.
5. Whether source tracking exists.
6. Whether import tracking exists.
7. Whether client phone uniqueness is per organization.
8. Whether any field or table is missing for planned acquisition methods.

## Required Design

The model should support:

### Customer
- organization_id
- full_name
- phone_e164
- email
- preferred_language
- notes
- source if available or via related records
- created_at
- updated_at

### SMS Consent
- organization_id
- customer_id
- phone_e164
- status
- source
- consent_text
- consented_at
- unsubscribed_at

### Waitlist Entry
- organization_id
- customer_id
- status
- optional service_id
- preferred_days
- preferred_time_windows
- discount_interest
- notes
- source if needed

### Import Batch
- organization_id
- file_name
- total_rows
- valid_rows
- invalid_rows
- duplicate_rows
- created_by
- created_at

If fields already exist, do not duplicate them. If missing, add a minimal additive migration.

## Security Requirements

- No broad anon access to private customer lists.
- Public QR signup must use a controlled server route/RPC, not direct table access.
- organization_id must never be trusted from public form input.
- QR/public signup must resolve organization from slug or public token.
- Imported clients without explicit consent must default to `needs_consent`, not `opted_in`.

## Migration Requirements

If a migration is needed:
- create a new additive migration;
- do not modify old applied migrations only;
- do not drop or truncate existing data;
- use safe constraints;
- preserve existing data;
- add indexes for organization-scoped lookup if needed.

## Tests Required

Add/update tests to verify:

1. customer uniqueness per organization by phone.
2. consent status defaults safely.
3. import batch tracking exists or is supported.
4. no direct anon access to customer data.
5. public signup path does not require broad table permissions.
6. all new migrations are non-destructive.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If migration added:

```bash
supabase migration list --linked
supabase db push
```

## Manual Verification

1. Inspect schema.
2. Confirm tables support manual, import, QR, public link, kiosk, and copy-paste sources.
3. Confirm consent states are explicit.
4. Confirm imported clients can be stored without becoming SMS-eligible by default.

## Final Report

Report:

1. Existing model findings.
2. Missing fields/tables.
3. Migration added if any.
4. Consent safety behavior.
5. RLS/security behavior.
6. Tests added.
7. Validation results.
8. Risks before Phase 2.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
