
# 02 — Phase Manual Client Creation

## Role

You are a senior full-stack engineer, senior UX form engineer, senior TypeScript engineer, senior Supabase engineer, and senior QA lead.

You are working only on **Phase 2: manual client creation**.

Do not implement Excel import, QR, kiosk, or copy-paste in this phase.

## Problem

Merchants need a simple way to add clients one by one from the dashboard.

This is essential for:
- phone calls;
- walk-ins;
- in-person consent;
- small businesses without files;
- testing the cancellation workflow.

## Goal

Implement a secure manual client creation flow.

A merchant should be able to create a client with:
- full name;
- phone number;
- optional email;
- preferred language;
- SMS consent status;
- optional service interest;
- optional waitlist entry;
- notes.

## Files to Read First

Read:

- dashboard route structure
- existing clients pages if any
- `src/lib/customers/phone.ts`
- `src/components/forms/phone-input.tsx` if it exists
- organization/current auth helpers
- Supabase table schema for customers, sms_consents, waitlist_entries, services
- tests

## Root Cause Analysis Required

Identify:

1. Whether a clients page already exists.
2. Whether manual client creation already exists.
3. Whether phone input normalization exists.
4. Whether service list can be queried.
5. Whether adding to waitlist should happen in same form or later.
6. How server actions are structured in this repo.

## UX Requirements

Create or update a page such as:

```text
/dashboard/clients/new
```

or a modal if the project already uses modal patterns.

Form fields:
- Full name
- Phone
- Email optional
- Preferred language
- Consent status:
  - Opted in
  - Needs consent
  - Opted out
- Service interest optional
- Add to waitlist checkbox
- Notes

Phone input:
- user can type `5142494425`;
- UI displays `514-249-4425`;
- backend stores normalized `+15142494425`.

## Security Requirements

- Require authenticated user.
- Resolve organization from active workspace.
- Do not accept organization_id from browser as source of truth.
- Server-side validation required.
- Write customer only under active organization.
- Consent must be explicit.

## Duplicate Handling

If a client with the same phone already exists in the organization:
- do not create duplicate;
- update safe fields only if intended;
- show user-friendly message;
- optionally redirect to existing client.

Do not merge across organizations.

## Tests Required

Add/update tests for:

1. manual client input validation.
2. phone normalization.
3. duplicate phone handling.
4. empty/invalid phone handling.
5. consent status handling.
6. organization_id not trusted from input.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Manual Test

1. Go to clients page.
2. Add client `Maya Tremblay`.
3. Phone `5142494425`.
4. Set consent `Opted in`.
5. Add to waitlist.
6. Confirm client appears.
7. Confirm phone is normalized.
8. Try adding same phone again.
9. Confirm no duplicate is created.

## Final Report

Report:

1. Route/page added.
2. Server action added.
3. Tables written.
4. Consent behavior.
5. Duplicate behavior.
6. Tests added.
7. Validation results.
8. Remaining limitations.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
