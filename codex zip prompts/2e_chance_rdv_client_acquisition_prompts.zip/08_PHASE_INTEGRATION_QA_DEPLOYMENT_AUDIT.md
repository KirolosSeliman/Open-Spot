
# 08 — Phase Client Acquisition Integration QA + Deployment Audit

## Role

You are a senior release engineer, senior QA lead, senior security reviewer, senior data integrity analyst, senior performance reviewer, and senior production-readiness architect.

You are working only on **Phase 8: final integration QA and deployment audit for the client acquisition system**.

Do not add new features. Do not redesign. Verify that all client acquisition methods are safe, secure, efficient, and deployable.

## Scope

Audit all implemented acquisition methods:

- manual client creation;
- Excel/CSV import;
- QR code signup;
- public link signup;
- kiosk/tablet mode;
- copy-paste import;
- waitlist filters/segments;
- consent handling;
- dashboard integration.

## Required Audit Areas

### Product Behavior

Confirm:
- merchant can add client manually;
- merchant can import clients;
- merchant can generate QR code;
- customer can join from QR/public link;
- kiosk mode works;
- copy-paste import works;
- waitlist filters work;
- dashboard counts update.

### Data Integrity

Confirm:
- no duplicate client rows for same organization + phone;
- same phone can exist in different organizations if allowed by model;
- import batches record counts;
- source tracking works;
- consent status is correct;
- opted-out clients stay blocked.

### Security

Confirm:
- no service-role key in browser;
- public signup cannot read private data;
- organization_id is never trusted from browser;
- RLS remains safe;
- dashboard pages require auth;
- public pages only write through controlled server logic.

### UX

Confirm:
- phone formatting works;
- user-friendly errors;
- import preview before commit;
- clear success states;
- print/share QR flow understandable;
- mobile usability.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If Supabase migrations were added:

```bash
supabase migration list --linked
supabase db push
```

Optional local-only destructive test:

```bash
supabase db reset
```

Only run `supabase db reset` on a disposable local database. Never on linked production/staging.

## Manual QA Script

1. Create a test merchant organization.
2. Add service.
3. Add manual client with `5142494425`.
4. Import CSV with:
   - valid rows;
   - duplicate phone;
   - invalid phone;
   - missing consent.
5. Generate QR code.
6. Open public QR link logged out.
7. Submit client with consent.
8. Open kiosk mode.
9. Submit another client.
10. Paste raw text list and import.
11. Open waitlist filters.
12. Filter by consent/source/service.
13. Confirm dashboard counts update.
14. Confirm no real SMS is sent.

## Deployment Checklist

Before deploy:

- all validations pass;
- migrations applied;
- no secrets exposed;
- public routes tested;
- import file limits documented;
- no real SMS accidentally enabled;
- rollback plan known.

## Rollback Strategy

If frontend issue:
- revert frontend commit.

If migration issue:
- create forward-fix migration;
- do not reset production.

If public signup abused:
- disable route temporarily or require token/rate limit in forward fix.

## Final Report

Produce:

1. Release readiness verdict.
2. Acquisition methods implemented.
3. Tables/functions used.
4. Security findings.
5. Consent findings.
6. Validation results.
7. Manual QA results.
8. Deployment commands.
9. Rollback plan.
10. Remaining risks before real merchant pilot.

## Acceptance Criteria

The acquisition system is ready only if:

- manual client creation works;
- import preview works;
- QR signup works;
- public link works;
- kiosk mode works if implemented;
- copy-paste import works if implemented;
- waitlist filters work;
- consent is safe;
- data is organization-scoped;
- tests pass;
- build passes;
- no destructive DB changes were used.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
