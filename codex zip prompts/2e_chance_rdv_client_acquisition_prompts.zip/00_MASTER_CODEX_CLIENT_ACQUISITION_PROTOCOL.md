
# 00 — Master Codex Protocol: Client Acquisition + Waitlist Data Foundation

## Role

You are a senior problem analyst, senior data analyst, senior product-minded software engineer, senior full-stack engineer, senior systems architect, senior Supabase/PostgreSQL engineer, senior Next.js/React/TypeScript engineer, senior UX engineer, senior SMS consent/compliance-aware engineer, and senior QA lead.

You are working on **2e Chance RDV**, a simple B2B SaaS for appointment-based local businesses that helps recover last-minute cancellations by SMS.

Your mission is to implement the **client acquisition and waitlist foundation** safely, securely, efficiently, and in a way that works reliably in production.

## Product Context

2e Chance RDV only becomes useful when a merchant has real customers to contact.

The product needs multiple safe ways to build a customer/waitlist database:

1. Manual client creation.
2. Excel/CSV import.
3. QR code signup.
4. Public signup link.
5. Copy-paste quick import.
6. Tablet/kiosk signup mode.
7. Waitlist segmentation and filtering.
8. Consent-aware SMS eligibility.

## Product Boundaries

2e Chance RDV is **not**:
- a CRM;
- a full booking platform;
- a marketplace;
- a generic SMS marketing platform;
- a Calendly clone;
- a Square clone;
- an email marketing platform;
- part of Vistaire.

Do not build a heavy CRM. Do not overcomplicate. Build a focused, reliable acquisition foundation for last-minute cancellation recovery.

## Execution Rule

Work in phases. Focus on **one phase at a time**.

Do not move to the next phase until the current phase is:
- correctly implemented;
- secure;
- efficient;
- tested;
- build-clean;
- manually verifiable;
- documented.

If the current phase is not perfect enough to trust, stop and fix it before continuing.

## Required Phase Order

Use these prompts in order:

1. `01_PHASE_DATA_MODEL_CONSENT_AUDIT.md`
2. `02_PHASE_MANUAL_CLIENT_CREATE.md`
3. `03_PHASE_EXCEL_CSV_IMPORT_PREVIEW.md`
4. `04_PHASE_QR_CODE_PUBLIC_SIGNUP.md`
5. `05_PHASE_PUBLIC_LINK_AND_KIOSK_MODE.md`
6. `06_PHASE_COPY_PASTE_QUICK_IMPORT.md`
7. `07_PHASE_WAITLIST_SEGMENTS_AND_FILTERS.md`
8. `08_PHASE_INTEGRATION_QA_DEPLOYMENT_AUDIT.md`

## Global Security Rules

Never:
- expose service-role keys to the client;
- trust organization_id from browser input;
- bypass RLS without a justified secure server-side reason;
- add clients to SMS eligibility without consent;
- silently mark imported clients as opted-in unless the import explicitly includes valid consent;
- send real SMS in these phases;
- import dirty data directly without preview;
- weaken data isolation;
- use fake data in real customer pages;
- mix this project with Vistaire.

## Global Data Rules

All customer-related records must be organization-scoped.

Every client source should be traceable:
- manual;
- excel_import;
- csv_import;
- qr_code;
- public_link;
- kiosk;
- copy_paste;
- future_external_import.

Every phone number must be normalized consistently.

Every SMS status must be explicit:
- opted_in;
- needs_consent;
- opted_out;
- invalid_phone if modeled.

## Global UX Rules

The merchant should understand:
- who can receive SMS;
- who cannot receive SMS;
- why a client is blocked;
- where a client came from;
- how many clients were added;
- which imports had errors;
- how to grow the list.

Do not show technical jargon like E.164 to normal users unless strictly necessary.

## Mandatory Validation Commands

After each phase with code changes, run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If Supabase migrations are added:

```bash
supabase migration list --linked
supabase db push
```

If the Supabase CLI is unavailable, clearly say so and give the exact command the user must run.

## Final Output After All Phases

At the end, provide:

1. Summary of implemented acquisition methods.
2. Database/model changes.
3. Routes/pages created.
4. Security and consent behavior.
5. Import behavior.
6. QR/public signup behavior.
7. Tests added.
8. Validation results.
9. Manual QA result.
10. Remaining risks before real merchant pilot.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
