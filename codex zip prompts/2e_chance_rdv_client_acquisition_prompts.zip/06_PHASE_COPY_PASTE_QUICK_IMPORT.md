
# 06 — Phase Copy-Paste Quick Import

## Role

You are a senior data analyst, senior UX engineer, senior import workflow engineer, senior TypeScript engineer, and senior QA lead.

You are working only on **Phase 6: copy-paste quick import**.

Do not change Excel import or QR flow unless needed to reuse shared import logic.

## Problem

Some small merchants do not have clean CSV/Excel files. They may have client names and phone numbers in notes, messages, or copied text.

They need a fast way to paste raw text and let the app parse possible clients.

## Goal

Build a safe paste-to-preview import flow.

Example pasted input:

```text
Maya 5145551001
Sarah 514-555-1002
Lina Nguyen (514) 555-1003
```

The app should detect:
- name;
- phone;
- invalid rows;
- duplicates;
- consent status default;
- source as `copy_paste`.

## Files to Read First

Read:

- Excel/CSV import parsing code
- client creation actions
- phone normalization utilities
- import batch model
- tests

## Requirements

Create a page or section such as:

```text
/dashboard/clients/import/paste
```

or integrate into import page.

Flow:

1. Merchant pastes text.
2. App parses lines.
3. App extracts phone numbers.
4. Remaining text becomes name if reasonable.
5. Preview results.
6. Merchant confirms.
7. Valid clients are created/updated safely.

## Consent Rules

Copy-paste imported clients default to `needs_consent` unless merchant explicitly marks that consent was collected.

If allowing a bulk “I confirm these clients gave SMS consent” checkbox:
- make it explicit;
- do not pre-check;
- record source/copy.

## Security Requirements

- organization_id from server workspace only.
- no direct client-side DB writes.
- no service role in client.
- preview before commit.

## Tests Required

Add tests for:

1. simple line parsing.
2. phone extraction.
3. name extraction.
4. invalid line detection.
5. duplicate detection.
6. consent default.
7. import confirmation.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Manual Test

1. Paste 5 lines with mixed phone formats.
2. Confirm preview.
3. Confirm invalid rows are flagged.
4. Confirm duplicates are detected.
5. Import.
6. Confirm clients appear with source `copy_paste`.
7. Confirm consent status is safe.

## Final Report

Report:

1. Parser behavior.
2. Page/route added.
3. Consent behavior.
4. Tests added.
5. Validation results.
6. Limitations of parsing.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
