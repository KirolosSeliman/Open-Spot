
# 03 — Phase Excel/CSV Import with Preview + Deduplication

## Role

You are a senior data analyst, senior import pipeline engineer, senior full-stack engineer, senior TypeScript engineer, senior Supabase engineer, and senior QA lead.

You are working only on **Phase 3: Excel/CSV client import with preview, validation, and deduplication**.

Do not implement QR code, kiosk mode, or real SMS sending in this phase.

## Problem

Merchants may already have clients in Excel or CSV files. They need a safe way to import them.

The app must never import dirty data directly into the real client database without validation and preview.

## Goal

Build a safe import flow:

1. Merchant uploads Excel or CSV.
2. App parses rows.
3. App validates names/phones/emails/consent.
4. App detects duplicates.
5. App shows preview summary.
6. Merchant confirms import.
7. Valid rows are inserted or updated safely.
8. Import batch is recorded.

## Files to Read First

Read:

- current clients/import pages if any
- package.json to see available libraries
- Supabase schema for customers, sms_consents, waitlist_entries, import_batches
- phone normalization utilities
- tests
- current server action patterns

## Supported File Types

At minimum:
- CSV

If Excel `.xlsx` is not supported without adding a dependency, decide carefully:
- If a dependency is needed, justify it.
- Prefer CSV first if it keeps MVP simpler.
- If adding `xlsx` or equivalent, verify bundle/server impact and security.

## Import Columns

Support flexible mapping for common columns:

- name / full_name / nom
- phone / telephone / téléphone
- email / courriel
- language / langue
- service / service_interest
- notes
- consent / sms_consent / consentement

## Preview Requirements

Before writing to database, show:

- total rows;
- valid rows;
- invalid rows;
- duplicate rows;
- missing consent rows;
- invalid phone rows;
- rows that will become `needs_consent`;
- rows that can become `opted_in` only if explicit consent is present.

Do not import until merchant confirms.

## Consent Safety Rules

Imported clients must default to `needs_consent` unless the file explicitly and clearly marks consent as yes/true/opted_in.

Do not infer consent from being in the file.

## Deduplication Rules

Deduplicate by:
- organization_id + normalized phone number.

For duplicates:
- do not create duplicate customer rows;
- either skip or update safe fields;
- record duplicate count in import batch;
- report result to merchant.

## Security Requirements

- Server-side parsing or safe route handler.
- Do not trust organization_id from client.
- Limit file size.
- Avoid storing original uploaded file unless intentionally designed.
- Do not expose customer lists across organizations.

## Tests Required

Add tests for:

1. CSV parsing.
2. column mapping.
3. phone normalization.
4. invalid phone detection.
5. duplicate detection.
6. consent interpretation.
7. preview summary.
8. confirm import behavior.
9. import batch counts.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If migrations needed:

```bash
supabase migration list --linked
supabase db push
```

## Manual Test

1. Upload CSV with 5 valid clients.
2. Upload CSV with invalid phone.
3. Upload CSV with duplicate phone.
4. Upload CSV without consent column.
5. Confirm preview is accurate.
6. Confirm import.
7. Confirm customers and consents are created correctly.
8. Confirm dashboard/client count updates.

## Final Report

Report:

1. Supported file types.
2. Column mapping behavior.
3. Consent handling.
4. Duplicate handling.
5. Import batch tracking.
6. Tests added.
7. Validation results.
8. Limitations.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
