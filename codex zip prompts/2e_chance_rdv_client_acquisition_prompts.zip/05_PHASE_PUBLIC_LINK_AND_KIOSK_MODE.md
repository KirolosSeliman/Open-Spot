
# 05 — Phase Public Link + Tablet/Kiosk Mode

## Role

You are a senior UX engineer, senior full-stack engineer, senior public-form architect, senior mobile-first engineer, and senior QA lead.

You are working only on **Phase 5: public share link and tablet/kiosk signup mode**.

Do not implement Excel import or real SMS sending here. QR public signup should already exist before this phase.

## Problem

A QR code is useful, but merchants also need:
- a copyable signup link for Instagram/Facebook/website;
- a kiosk/tablet mode for in-store signup.

## Goal

Build two acquisition variants:

1. Public share link:
   - same underlying public signup flow;
   - optimized for sharing online.

2. Kiosk/tablet mode:
   - designed for in-store tablet;
   - resets after each submission;
   - minimal merchant/customer friction.

## Files to Read First

Read:

- QR/public signup implementation
- dashboard routes
- organization/current helpers
- public form server action/RPC
- tests

## Public Link Requirements

Dashboard page should provide:
- copyable link;
- suggested placement ideas:
  - Instagram bio;
  - Facebook;
  - website;
  - Google Business Profile;
  - SMS/manual message;
- preview of what customer sees.

## Kiosk Mode Requirements

Create a route such as:

```text
/join/[organizationSlug]/kiosk
```

or dashboard-launched kiosk route.

Kiosk page must:
- show merchant name;
- show simple signup form;
- have large touch-friendly inputs;
- after successful submission, show success screen briefly;
- allow starting next signup;
- avoid exposing dashboard controls;
- not require merchant login for the customer-facing input if using public token/slug.

## Consent Requirements

Consent must remain explicit.

Kiosk mode still needs:
- consent checkbox;
- clear consent copy;
- no pre-checked consent unless legally justified; default should be unchecked.

## Security Requirements

- Kiosk route cannot expose private customer data.
- It can only create/update the submitted customer/waitlist entry.
- It cannot show previous customers.
- It cannot accept organization_id directly.

## Tests Required

Add tests for:

1. public link generation.
2. kiosk form validation.
3. kiosk submission creates customer/waitlist.
4. kiosk does not expose private data.
5. consent behavior.
6. form reset behavior if testable.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Manual Test

1. Copy public signup link.
2. Open it logged out.
3. Submit.
4. Confirm customer appears.
5. Open kiosk route.
6. Submit first customer.
7. Confirm success screen/reset.
8. Submit second customer.
9. Confirm both appear in dashboard.

## Final Report

Report:

1. Public link behavior.
2. Kiosk route behavior.
3. Consent behavior.
4. Security boundaries.
5. Tests added.
6. Validation results.
7. Remaining limitations.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
