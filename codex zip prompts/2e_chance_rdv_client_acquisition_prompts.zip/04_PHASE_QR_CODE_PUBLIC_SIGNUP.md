
# 04 — Phase QR Code + Public Signup Page

## Role

You are a senior product engineer, senior full-stack engineer, senior public-form security engineer, senior QR workflow designer, senior SMS consent-aware engineer, and senior QA lead.

You are working only on **Phase 4: QR code and public signup page**.

Do not implement Excel import or real SMS sending in this phase.

## Problem

Merchants need an easy way to grow their waitlist without manually typing every customer.

A printable QR code should let customers scan and add themselves to the merchant’s waitlist with clear SMS consent.

## Goal

Implement a QR code workflow:

1. Merchant opens QR code page in dashboard.
2. App generates QR code for the merchant’s public signup link.
3. Merchant can print/download the QR code or poster.
4. Customer scans QR.
5. Customer lands on a public signup page.
6. Customer submits name, phone, preferences, and explicit consent.
7. App creates/updates customer, consent, and waitlist entry safely.

## Files to Read First

Read:

- organization/current helpers
- QR-related dependencies if any
- Supabase schema for organizations/customers/sms_consents/waitlist_entries
- existing waitlist signup RPC if any
- public route patterns
- tests

## Public Link Design

Use a route such as:

```text
/join/[organizationSlug]
```

or the existing route if already present.

The public page must resolve organization by slug or safe public token.

Do not expose organization private data.

## Public Signup Form Fields

Required:
- full name
- phone
- SMS consent checkbox

Optional:
- service interest
- preferred days
- preferred time windows
- language
- wants last-minute discount
- notes

## Consent Copy

Include clear consent text, such as:

```text
J’accepte de recevoir des SMS de ce commerce pour être averti des disponibilités ou annulations de dernière minute. Je peux me désinscrire à tout moment.
```

The checkbox must be required before `opted_in`.

If consent is not checked:
- either block submission;
- or create customer with `needs_consent`, but do not mark SMS eligible.
Choose the safest UX and document it.

## QR Dashboard Page

Create or update:

```text
/dashboard/qr-code
```

or equivalent.

It should show:
- public signup link;
- QR code;
- print-friendly QR card/poster;
- instructions for merchant;
- copy link button if possible.

## Security Requirements

- Public form cannot accept organization_id directly.
- Public form resolves organization from slug/token.
- Public form writes only through a controlled server action/RPC.
- No service role in client component.
- Rate limiting should be considered or documented.
- Avoid exposing customer list.

## Tests Required

Add tests for:

1. organization slug resolution.
2. public form validation.
3. phone normalization.
4. consent required for opted_in.
5. duplicate phone update behavior.
6. waitlist entry creation.
7. QR link generation.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

If migrations needed:

```bash
supabase migration list --linked
supabase db push
```

## Manual Test

1. Open merchant dashboard.
2. Open QR code page.
3. Copy public link.
4. Open public link in logged-out/incognito browser.
5. Submit customer with phone `5142494425`.
6. Check consent box.
7. Confirm success page.
8. Confirm customer appears in merchant dashboard.
9. Confirm waitlist entry exists.
10. Confirm client is SMS eligible only because consent was explicit.

## Final Report

Report:

1. QR route/page.
2. Public signup route.
3. Consent behavior.
4. Data written.
5. Security decisions.
6. Tests added.
7. Validation results.
8. Remaining limitations.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
