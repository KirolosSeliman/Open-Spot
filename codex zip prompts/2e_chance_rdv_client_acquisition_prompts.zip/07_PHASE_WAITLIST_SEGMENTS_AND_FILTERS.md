
# 07 — Phase Waitlist Segments and Filters

## Role

You are a senior product engineer, senior data analyst, senior UX engineer, senior Supabase engineer, and senior QA lead.

You are working only on **Phase 7: waitlist segments and filters**.

Do not implement real SMS sending. This phase prepares clean targeting for future cancellation alerts.

## Problem

A merchant may have many clients, but not every client should receive every cancellation alert.

The product needs simple segmentation so the merchant can find eligible clients by service, consent, source, language, availability, and status.

## Goal

Implement practical waitlist filters and segments.

Examples:
- all active waitlist entries;
- by service interest;
- opted-in only;
- needs consent;
- opted out;
- imported from Excel;
- joined by QR;
- language FR/EN;
- wants discount;
- recently added.

## Files to Read First

Read:

- waitlist pages/components
- customers pages/components
- services pages/components
- Supabase tables and indexes
- filtering/search utilities
- tests

## Requirements

Create or update waitlist UI to include filters:

- search by name/phone;
- status;
- service;
- consent;
- source;
- language;
- discount interest.

The list should show:
- client name;
- phone;
- consent status;
- source;
- service interest;
- preferred availability;
- date added.

## Data Requirements

Queries must:
- be organization-scoped;
- be efficient;
- avoid fetching excessive data;
- support empty states.

## SMS Eligibility Label

Clearly label whether a client is eligible for SMS:

- Eligible
- Needs consent
- Opted out
- Invalid phone

Do not allow ineligible clients to be selected for future SMS sends without explicit safe action.

## Tests Required

Add tests for:

1. filtering by service.
2. filtering by consent.
3. filtering by source.
4. search by name/phone.
5. eligibility helper.
6. organization scoping.

## Validation Commands

Run:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Manual Test

1. Add clients from manual, import, QR.
2. Add waitlist entries.
3. Filter by source.
4. Filter by consent.
5. Filter by service.
6. Confirm ineligible clients are clearly marked.

## Final Report

Report:

1. Filters implemented.
2. Eligibility logic.
3. Data queries.
4. Tests added.
5. Validation results.
6. Remaining segmentation limitations.

Are you 100% confident in this strategy? If not, find all possible loopholes, suggest proper fixes, and run this loop until you are factually 100% confident in the new strategy.
